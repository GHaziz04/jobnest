module tn.jobnest.gestioncan {
    // --- Modules JavaFX de base ---
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;
    requires javafx.graphics;
    requires javafx.media;

    // --- Modules Système & SQL ---
    requires java.sql;
    requires java.desktop;
    requires java.net.http;

    // --- Google API & JSON ---
    requires com.google.api.client;
    requires com.google.api.client.auth;
    requires com.google.api.client.extensions.java6.auth;
    requires com.google.api.client.extensions.jetty.auth;
    requires com.google.api.client.json.gson;
    requires com.google.api.services.calendar;
    requires google.api.client;
    requires com.google.gson;

    // --- Modules ITEXT 7 (PDF) & Stripe ---
    requires kernel;
    requires layout;
    requires io;
    requires org.slf4j;
    requires stripe.java;

    // --- OpenHTMLToPDF ---
    requires openhtmltopdf.pdfbox;
    requires openhtmltopdf.slf4j;

    // --- ✅ AJOUT : Module pour l'envoi d'e-mails ---
    requires jakarta.mail;

    // --- CONFIGURATION D'OUVERTURE ---

    // Autorise JavaFX à charger l'application et injecter les @FXML
    opens tn.jobnest.gestioncan to javafx.fxml;
    opens tn.jobnest.gestioncan.controllers to javafx.fxml;

    // Autorise l'accès aux services (nécessaire pour la réflexion et l'injection)
    opens tn.jobnest.gestioncan.services to javafx.fxml, jakarta.mail;

    // Autorise les TableView et le binding à lire tes modèles
    opens tn.jobnest.gestioncan.models to javafx.base;

    // --- EXPORTS ---
    exports tn.jobnest.gestioncan;
    exports tn.jobnest.gestioncan.controllers;
    exports tn.jobnest.gestioncan.models;
    exports tn.jobnest.gestioncan.services;
}