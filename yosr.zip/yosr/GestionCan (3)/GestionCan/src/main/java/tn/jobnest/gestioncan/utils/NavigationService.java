package tn.jobnest.gestioncan.utils;

import javafx.scene.Node;
import tn.jobnest.gestioncan.controllers.MainLayoutController;

public class NavigationService {
    private static MainLayoutController mainController;

    /**
     * Cette méthode permet au MainLayout de s'enregistrer au démarrage
     */
    public static void setMainController(MainLayoutController controller) {
        mainController = controller;
        System.out.println("✅ NavigationService initialisé");
    }

    /**
     * Charge une vue FXML dans le contentArea du MainLayout
     * @param fxml Le chemin du fichier FXML (ex: "/View/OffresView.fxml")
     */
    public static void chargerVue(String fxml) {
        if (mainController != null) {
            mainController.chargerVue(fxml);
        } else {
            System.err.println("❌ Erreur : Le NavigationService n'est pas initialisé !");
        }
    }

    /**
     * Alias de chargerVue() pour compatibilité avec l'ancien code
     * @param fxml Le chemin du fichier FXML
     */
    public static void charger(String fxml) {
        chargerVue(fxml);
    }

    /**
     * Charge directement un Node (déjà chargé) dans le contentArea
     * @param node Le Node JavaFX à afficher
     */
    public static void loadContent(Node node) {
        if (mainController != null) {
            mainController.getContentArea().getChildren().setAll(node);
        } else {
            System.err.println("❌ Erreur : Le NavigationService n'est pas initialisé !");
        }
    }

    /**
     * Retourne le MainLayoutController actuel (pour des accès avancés)
     * @return L'instance du MainLayoutController ou null si non initialisé
     */
    public static MainLayoutController getMainController() {
        return mainController;
    }
}