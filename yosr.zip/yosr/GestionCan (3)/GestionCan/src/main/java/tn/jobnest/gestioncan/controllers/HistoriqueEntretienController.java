package tn.jobnest.gestioncan.controllers;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.shape.Circle;
import tn.jobnest.gestioncan.models.Entretien;
import tn.jobnest.gestioncan.models.Feedback;
import tn.jobnest.gestioncan.services.EntretienCandidatService;
import tn.jobnest.gestioncan.utils.NavigationService;

import java.awt.Desktop;
import java.net.URI;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class HistoriqueEntretienController {

    @FXML private VBox historiqueVBox;
    @FXML private TextField searchField;
    @FXML private ComboBox<String> comboStatut;
    @FXML private Label totalCount;
    @FXML private Label realiseCount;
    @FXML private Label annuleCount;

    private final EntretienCandidatService service = new EntretienCandidatService();
    private List<Entretien> historiqueEntretiens;
    private int idCandidat;

    public void setIdCandidat(int idCandidat) {
        this.idCandidat = idCandidat;
        rafraichirHistorique();
    }

    @FXML
    public void initialize() {
        comboStatut.setItems(FXCollections.observableArrayList(
                "Tous les statuts", "réalisé", "annulé"
        ));
        comboStatut.setValue("Tous les statuts");

        comboStatut.valueProperty().addListener((obs, old, newVal) -> filterAndDisplay());
        searchField.textProperty().addListener((obs, old, newVal) -> filterAndDisplay());
    }

    @FXML
    private void rafraichirHistorique() {
        try {
            historiqueEntretiens = service.getHistoriqueEntretiens(idCandidat);
            updateStats();
            filterAndDisplay();
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Erreur",
                    "Impossible de charger l'historique : " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void retourAuxEntretiens() {
        NavigationService.chargerVue("/View/entretien-candidat-content.fxml");
    }

    private void updateStats() {
        if (historiqueEntretiens == null) return;

        totalCount.setText(String.valueOf(historiqueEntretiens.size()));

        long realises = historiqueEntretiens.stream()
                .filter(e -> "réalisé".equals(e.getStatut()))
                .count();
        realiseCount.setText(String.valueOf(realises));

        long annules = historiqueEntretiens.stream()
                .filter(e -> "annulé".equals(e.getStatut()))
                .count();
        annuleCount.setText(String.valueOf(annules));
    }

    private void filterAndDisplay() {
        if (historiqueEntretiens == null || historiqueEntretiens.isEmpty()) {
            historiqueVBox.getChildren().clear();

            VBox emptyBox = new VBox(15);
            emptyBox.setAlignment(Pos.CENTER);
            emptyBox.setPadding(new Insets(50));

            Label emptyIcon = new Label("📂");
            emptyIcon.setStyle("-fx-font-size: 64px;");

            Label emptyLabel = new Label("Aucun entretien dans l'historique");
            emptyLabel.setStyle("-fx-font-size: 18px; -fx-text-fill: #64748B; -fx-font-weight: bold;");

            Label emptySubLabel = new Label("Vos anciens entretiens apparaîtront ici");
            emptySubLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #94A3B8;");

            emptyBox.getChildren().addAll(emptyIcon, emptyLabel, emptySubLabel);
            historiqueVBox.getChildren().add(emptyBox);
            return;
        }

        String search = searchField.getText().trim().toLowerCase();
        String selStatut = comboStatut.getValue();

        historiqueVBox.getChildren().clear();

        for (Entretien e : historiqueEntretiens) {
            try {
                String titreOffre = service.getOffreTitre(e.getIdOffre()).toLowerCase();
                String recruteurNom = service.getRecruteurNom(e.getIdRecruteur()).toLowerCase();

                boolean matchSearch = search.isEmpty()
                        || titreOffre.contains(search)
                        || recruteurNom.contains(search);
                boolean matchStatut = "Tous les statuts".equals(selStatut)
                        || selStatut.equals(e.getStatut());

                if (matchSearch && matchStatut) {
                    historiqueVBox.getChildren().add(createHistoriqueCard(e));
                }
            } catch (SQLException ex) {
                System.err.println("Erreur chargement données entretien #" + e.getIdEntretien());
            }
        }

        if (historiqueVBox.getChildren().isEmpty()) {
            Label emptyLabel = new Label("🔍 Aucun entretien ne correspond à vos critères");
            emptyLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #64748B; -fx-padding: 50;");
            historiqueVBox.getChildren().add(emptyLabel);
        }
    }

    private Node createHistoriqueCard(Entretien e) {
        HBox card = new HBox(15);
        card.setPrefHeight(160);
        card.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-background-radius: 12; " +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 10, 0, 0, 3);");

        try {
            String statutColor = getStatutColor(e.getStatut());
            Circle avatar = new Circle(30);
            avatar.setStyle("-fx-fill: " + statutColor + ";");

            String statutIcon = getStatutIcon(e.getStatut());
            Label avatarLabel = new Label(statutIcon);
            avatarLabel.setStyle("-fx-font-size: 24px; -fx-text-fill: white;");

            StackPane avatarStack = new StackPane();
            avatarStack.getChildren().addAll(avatar, avatarLabel);

            VBox avatarBox = new VBox(avatarStack);
            avatarBox.setAlignment(Pos.CENTER);
            avatarBox.setPrefWidth(80);

            VBox details = new VBox(8);
            details.setPrefWidth(500);
            HBox.setHgrow(details, Priority.ALWAYS);

            String titreOffre = service.getOffreTitre(e.getIdOffre());
            Label offreLabel = new Label("💼 " + titreOffre);
            offreLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #1E293B;");

            String recruteurNom = service.getRecruteurNom(e.getIdRecruteur());
            Label recruteurLabel = new Label("👨‍💼 " + recruteurNom);
            recruteurLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #475569; -fx-font-weight: 500;");

            String dateStr = (e.getDateEntretien() != null)
                    ? e.getDateEntretien().toLocalDate().format(DateTimeFormatter.ofPattern("EEEE dd MMMM yyyy"))
                    : "Date non définie";
            String heureStr = (e.getHeureDebut() != null && e.getHeureFin() != null)
                    ? e.getHeureDebut().toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm")) +
                    " - " + e.getHeureFin().toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))
                    : "Horaire non défini";
            long duree = calculateDuration(e);
            String dureeTxt = (duree > 0) ? " (" + duree + " min)" : "";

            Label dateTimeLabel = new Label("📅 " + dateStr + " | 🕐 " + heureStr + dureeTxt);
            dateTimeLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: #64748B;");

            Label lieuVisioLabel;
            if ("présentiel".equals(e.getTypeEntretien())) {
                String lieu = (e.getLieu() != null && !e.getLieu().isEmpty())
                        ? e.getLieu() : "Lieu non défini";
                lieuVisioLabel = new Label("📍 " + lieu);
                lieuVisioLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: #1e2a78; -fx-font-weight: 500;");
            } else {
                String lien = (e.getLienVisio() != null && !e.getLienVisio().isEmpty())
                        ? e.getLienVisio() : "Lien non défini";
                if (lien.length() > 40) lien = lien.substring(0, 37) + "...";
                lieuVisioLabel = new Label("🔗 " + lien);
                lieuVisioLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: #3498db; -fx-font-weight: 500;");
            }

            Label statutBadge = new Label(getStatutText(e.getStatut()));
            statutBadge.setStyle("-fx-background-color: " + statutColor + "; " +
                    "-fx-text-fill: white; -fx-padding: 4 12; " +
                    "-fx-background-radius: 12; -fx-font-size: 12px; -fx-font-weight: bold;");

            details.getChildren().addAll(offreLabel, recruteurLabel, dateTimeLabel, lieuVisioLabel, statutBadge);

            VBox actionsBox = new VBox(10);
            actionsBox.setAlignment(Pos.CENTER_RIGHT);
            actionsBox.setPrefWidth(200);

            Button btnDetails = new Button("📋 Détails");
            btnDetails.setStyle("-fx-background-color: #1e2a78; -fx-text-fill: white; " +
                    "-fx-font-weight: bold; -fx-background-radius: 6; " +
                    "-fx-padding: 10 20; -fx-cursor: hand;");
            btnDetails.setPrefWidth(180);
            btnDetails.setOnAction(ev -> afficherDetails(e));

            Button btnFeedback = new Button("📊 Consulter Feedback");
            btnFeedback.setPrefWidth(180);

            if (service.feedbackExists(e.getIdEntretien())) {
                btnFeedback.setStyle("-fx-background-color: #10b981; -fx-text-fill: white; " +
                        "-fx-font-weight: bold; -fx-background-radius: 6; " +
                        "-fx-padding: 10 20; -fx-cursor: hand;");
                btnFeedback.setOnAction(ev -> afficherFeedback(e));
                actionsBox.getChildren().addAll(btnDetails, btnFeedback);
            } else {
                btnFeedback.setText("📊 Pas de feedback");
                btnFeedback.setDisable(true);
                btnFeedback.setStyle("-fx-background-color: #94A3B8; -fx-text-fill: white; " +
                        "-fx-font-weight: bold; -fx-background-radius: 6; " +
                        "-fx-padding: 10 20; -fx-opacity: 0.6;");
                actionsBox.getChildren().addAll(btnDetails, btnFeedback);
            }

            card.getChildren().addAll(avatarBox, details, actionsBox);

        } catch (SQLException ex) {
            System.err.println("Erreur création card: " + ex.getMessage());
            ex.printStackTrace();
        }

        return card;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // MÉTHODE PRINCIPALE : Affiche le feedback du recruteur dans un popup
    // ═══════════════════════════════════════════════════════════════════════
    private void afficherFeedback(Entretien e) {
        try {
            Feedback feedback = service.getFeedbackByEntretien(e.getIdEntretien());

            if (feedback == null) {
                showAlert(Alert.AlertType.WARNING, "Aucun feedback",
                        "Aucun feedback n'a été créé pour cet entretien.");
                return;
            }

            // Calcul de la moyenne sur 10
            double moyenne = (feedback.getCompetenceTechniques() +
                    feedback.getCompetenceCommunication() +
                    feedback.getMotivation() +
                    feedback.getAdequationAuPoste()) / 4.0;

            Dialog<ButtonType> dialog = new Dialog<>();
            dialog.setTitle("📊 Feedback du Recruteur");
            dialog.setHeaderText(null);

            DialogPane dialogPane = dialog.getDialogPane();
            dialogPane.setPrefWidth(750);
            dialogPane.setPrefHeight(700);

            VBox content = new VBox(20);
            content.setPadding(new Insets(25));

            // ═══════════════════════════════════════════════════════
            // ✅ SECTION FÉLICITATIONS (si moyenne >= 8/10)
            // ═══════════════════════════════════════════════════════
            if (moyenne >= 8.0) {
                VBox felicitationsBox = new VBox(12);
                felicitationsBox.setStyle(
                        "-fx-background-color: linear-gradient(to right, #10b981, #059669); " +
                                "-fx-padding: 25; -fx-background-radius: 12;");

                HBox felicHeader = new HBox(15);
                felicHeader.setAlignment(Pos.CENTER_LEFT);

                Label felicIcon = new Label("🎉");
                felicIcon.setStyle("-fx-font-size: 40px;");

                VBox felicTexts = new VBox(8);

                Label felicTitle = new Label("Félicitations !");
                felicTitle.setStyle(
                        "-fx-font-size: 26px; -fx-font-weight: bold; -fx-text-fill: white;");

                Label felicMsg = new Label(
                        "Vous avez brillamment réussi cet entretien avec une note de " +
                                String.format("%.1f", moyenne) + "/10.\n" +
                                "Nous vous contacterons prochainement pour les modalités d'embauche. 🚀");
                felicMsg.setStyle(
                        "-fx-font-size: 15px; -fx-text-fill: white; -fx-line-spacing: 5px;");
                felicMsg.setWrapText(true);

                Label felicSubMsg = new Label("⭐ Votre profil correspond parfaitement au poste !");
                felicSubMsg.setStyle(
                        "-fx-font-size: 13px; -fx-text-fill: #D1FAE5; " +
                                "-fx-font-style: italic;");

                felicTexts.getChildren().addAll(felicTitle, felicMsg, felicSubMsg);
                felicHeader.getChildren().addAll(felicIcon, felicTexts);
                felicitationsBox.getChildren().add(felicHeader);

                content.getChildren().add(felicitationsBox);
            }

            // ═══════════════════════════════════════════════════════
            // SECTION EN-TÊTE
            // ═══════════════════════════════════════════════════════
            VBox headerBox = new VBox(10);
            headerBox.setStyle("-fx-background-color: linear-gradient(to right, #1e2a78, #3b4ea8); " +
                    "-fx-padding: 20; -fx-background-radius: 10;");

            Label titreOffre = new Label(service.getOffreTitre(e.getIdOffre()));
            titreOffre.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; " +
                    "-fx-text-fill: white;");
            titreOffre.setWrapText(true);

            Label recruteurNom = new Label("👨‍💼 " + service.getRecruteurNom(e.getIdRecruteur()));
            recruteurNom.setStyle("-fx-font-size: 16px; -fx-text-fill: #E2E8F0;");

            String dateStr = (e.getDateEntretien() != null)
                    ? e.getDateEntretien().toLocalDate().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
                    : "Date non définie";
            Label dateEntretien = new Label("📅 Entretien du " + dateStr);
            dateEntretien.setStyle("-fx-font-size: 14px; -fx-text-fill: #CBD5E1;");

            headerBox.getChildren().addAll(titreOffre, recruteurNom, dateEntretien);

            // ═══════════════════════════════════════════════════════
            // SECTION NOTE GLOBALE
            // ═══════════════════════════════════════════════════════
            HBox noteGlobaleBox = new HBox(20);
            noteGlobaleBox.setAlignment(Pos.CENTER);
            noteGlobaleBox.setStyle("-fx-background-color: " + getCouleurNote(moyenne) + "; " +
                    "-fx-padding: 20; -fx-background-radius: 10;");

            VBox noteCircle = new VBox(5);
            noteCircle.setAlignment(Pos.CENTER);

            Label noteValeur = new Label(String.format("%.1f", moyenne));
            noteValeur.setStyle("-fx-font-size: 48px; -fx-font-weight: bold; " +
                    "-fx-text-fill: white;");

            Label noteSur = new Label("/ 10");
            noteSur.setStyle("-fx-font-size: 20px; -fx-text-fill: white; " +
                    "-fx-font-weight: 500;");

            noteCircle.getChildren().addAll(noteValeur, noteSur);

            VBox appreciationBox = new VBox(5);
            appreciationBox.setAlignment(Pos.CENTER_LEFT);

            Label appreciationLabel = new Label("Note globale");
            appreciationLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: white; " +
                    "-fx-font-weight: 500;");

            Label appreciationText = new Label(getAppreciationTexte(moyenne));
            appreciationText.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; " +
                    "-fx-text-fill: white;");

            appreciationBox.getChildren().addAll(appreciationLabel, appreciationText);
            noteGlobaleBox.getChildren().addAll(noteCircle, appreciationBox);

            // ═══════════════════════════════════════════════════════
            // SECTION NOTES DÉTAILLÉES
            // ═══════════════════════════════════════════════════════
            VBox notesDetailBox = new VBox(15);
            notesDetailBox.setStyle("-fx-background-color: #F8FAFC; -fx-padding: 20; " +
                    "-fx-background-radius: 10;");

            Label notesTitle = new Label("📊 Évaluation détaillée");
            notesTitle.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; " +
                    "-fx-text-fill: #1E293B;");

            GridPane notesGrid = new GridPane();
            notesGrid.setHgap(20);
            notesGrid.setVgap(15);

            notesGrid.add(createNoteDetail("💻", "Compétences Techniques",
                    feedback.getCompetenceTechniques()), 0, 0);
            notesGrid.add(createNoteDetail("💬", "Communication",
                    feedback.getCompetenceCommunication()), 1, 0);
            notesGrid.add(createNoteDetail("🎯", "Motivation",
                    feedback.getMotivation()), 0, 1);
            notesGrid.add(createNoteDetail("✅", "Adéquation au poste",
                    feedback.getAdequationAuPoste()), 1, 1);

            notesDetailBox.getChildren().addAll(notesTitle, notesGrid);

            // ═══════════════════════════════════════════════════════
            // SECTION COMMENTAIRE
            // ═══════════════════════════════════════════════════════
            VBox commentaireBox = new VBox(10);
            commentaireBox.setStyle("-fx-background-color: #FEF3C7; -fx-padding: 20; " +
                    "-fx-background-radius: 10;");

            Label commentaireTitle = new Label("💬 Commentaire du recruteur");
            commentaireTitle.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; " +
                    "-fx-text-fill: #854D0E;");

            Label commentaireText = new Label(feedback.getCommentaire());
            commentaireText.setStyle("-fx-font-size: 14px; -fx-text-fill: #854D0E; " +
                    "-fx-line-spacing: 5px;");
            commentaireText.setWrapText(true);

            commentaireBox.getChildren().addAll(commentaireTitle, commentaireText);

            // ═══════════════════════════════════════════════════════
            // SECTION COMPÉTENCES MANQUANTES
            // ═══════════════════════════════════════════════════════
            VBox competencesBox = new VBox(10);
            competencesBox.setStyle("-fx-background-color: #FEE2E2; -fx-padding: 20; " +
                    "-fx-background-radius: 10;");

            Label competencesTitle = new Label("⚠️ Compétences à développer");
            competencesTitle.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; " +
                    "-fx-text-fill: #991B1B;");

            Label competencesText = new Label(feedback.getCompetenceManquantes());
            competencesText.setStyle("-fx-font-size: 14px; -fx-text-fill: #991B1B; " +
                    "-fx-line-spacing: 5px;");
            competencesText.setWrapText(true);

            competencesBox.getChildren().addAll(competencesTitle, competencesText);

            // Assembler le contenu principal
            content.getChildren().addAll(
                    headerBox,
                    noteGlobaleBox,
                    notesDetailBox,
                    commentaireBox,
                    competencesBox
            );

            // ═══════════════════════════════════════════════════════
            // SECTION FORMATION (si recommandée)
            // ═══════════════════════════════════════════════════════
            if (feedback.isSuggestionFormation()) {
                VBox formationBox = new VBox(10);
                formationBox.setStyle("-fx-background-color: #DBEAFE; -fx-padding: 20; " +
                        "-fx-background-radius: 10;");

                HBox formationHeader = new HBox(10);
                formationHeader.setAlignment(Pos.CENTER_LEFT);

                Label formationIcon = new Label("🎓");
                formationIcon.setStyle("-fx-font-size: 24px;");

                Label formationTitle = new Label("Formation recommandée");
                formationTitle.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; " +
                        "-fx-text-fill: #1E40AF;");

                formationHeader.getChildren().addAll(formationIcon, formationTitle);

                Label formationText = new Label(
                        "Le recruteur vous recommande de suivre une formation pour renforcer " +
                                "vos compétences dans les domaines mentionnés ci-dessus.");
                formationText.setStyle("-fx-font-size: 14px; -fx-text-fill: #1E40AF; " +
                        "-fx-line-spacing: 5px;");
                formationText.setWrapText(true);

                formationBox.getChildren().addAll(formationHeader, formationText);
                content.getChildren().add(formationBox);
            }

            // ═══════════════════════════════════════════════════════
            // SECTION DATE FEEDBACK
            // ═══════════════════════════════════════════════════════
            Label dateFeedback = new Label("📅 Feedback créé le : " +
                    feedback.getDateFeedback().toLocalDateTime()
                            .format(DateTimeFormatter.ofPattern("dd/MM/yyyy à HH:mm")));
            dateFeedback.setStyle("-fx-font-size: 12px; -fx-text-fill: #64748B; " +
                    "-fx-font-style: italic;");

            content.getChildren().add(dateFeedback);

            ScrollPane scrollPane = new ScrollPane(content);
            scrollPane.setFitToWidth(true);
            scrollPane.setStyle("-fx-background-color: transparent; " +
                    "-fx-background: transparent;");

            dialogPane.setContent(scrollPane);

            ButtonType fermerButton = new ButtonType("Fermer", ButtonBar.ButtonData.CANCEL_CLOSE);
            dialogPane.getButtonTypes().add(fermerButton);

            dialog.showAndWait();

        } catch (SQLException ex) {
            showAlert(Alert.AlertType.ERROR, "Erreur",
                    "Impossible de charger le feedback : " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Crée un détail de note individuelle avec barre de progression
    // ═══════════════════════════════════════════════════════════════════════
    private VBox createNoteDetail(String emoji, String label, int note) {
        VBox box = new VBox(8);
        box.setAlignment(Pos.CENTER);
        box.setStyle("-fx-background-color: white; -fx-padding: 15; " +
                "-fx-background-radius: 8; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.05), 5, 0, 0, 2);");
        box.setPrefWidth(250);

        Label emojiLabel = new Label(emoji);
        emojiLabel.setStyle("-fx-font-size: 28px;");

        Label noteLabel = new Label(note + " / 10");
        noteLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; " +
                "-fx-text-fill: " + getCouleurNote(note) + ";");

        Label labelText = new Label(label);
        labelText.setStyle("-fx-font-size: 13px; -fx-text-fill: #64748B; " +
                "-fx-font-weight: 500;");
        labelText.setWrapText(true);
        labelText.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);

        ProgressBar progressBar = new ProgressBar(note / 10.0);
        progressBar.setPrefWidth(200);
        progressBar.setStyle("-fx-accent: " + getCouleurNote(note) + ";");

        box.getChildren().addAll(emojiLabel, noteLabel, labelText, progressBar);

        return box;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Retourne la couleur selon la note
    // ═══════════════════════════════════════════════════════════════════════
    private String getCouleurNote(double note) {
        if (note >= 8.0) return "#10b981"; // Vert - Excellent
        if (note >= 6.0) return "#3b82f6"; // Bleu - Bien
        if (note >= 4.0) return "#f59e0b"; // Orange - Moyen
        return "#ef4444";                  // Rouge - Faible
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Retourne le texte d'appréciation selon la note
    // ═══════════════════════════════════════════════════════════════════════
    private String getAppreciationTexte(double note) {
        if (note >= 8.0) return "⭐ Excellent";
        if (note >= 6.0) return "👍 Bien";
        if (note >= 4.0) return "📊 Moyen";
        return "📉 À améliorer";
    }

    private long calculateDuration(Entretien e) {
        if (e.getHeureDebut() == null || e.getHeureFin() == null) return 0;
        return TimeUnit.MILLISECONDS.toMinutes(
                e.getHeureFin().getTime() - e.getHeureDebut().getTime()
        );
    }

    private String getStatutColor(String statut) {
        switch (statut) {
            case "réalisé": return "#1e2a78";
            case "annulé":  return "#ef4444";
            default:        return "#64748B";
        }
    }

    private String getStatutIcon(String statut) {
        switch (statut) {
            case "réalisé": return "✔";
            case "annulé":  return "✖";
            default:        return "?";
        }
    }

    private String getStatutText(String statut) {
        switch (statut) {
            case "réalisé": return "✔ Réalisé";
            case "annulé":  return "❌ Annulé";
            default:        return statut;
        }
    }

    private void afficherDetails(Entretien e) {
        try {
            Dialog<ButtonType> dialog = new Dialog<>();
            dialog.setTitle("Détails de l'entretien (Historique)");
            dialog.setHeaderText(null);

            DialogPane dialogPane = dialog.getDialogPane();

            VBox content = new VBox(20);
            content.setPadding(new Insets(20));

            HBox headerBox = new HBox(15);
            headerBox.setAlignment(Pos.CENTER_LEFT);

            Label iconLabel = new Label(getStatutIcon(e.getStatut()));
            iconLabel.setStyle("-fx-font-size: 32px;");

            VBox titleBox = new VBox(5);
            Label offreLabel = new Label(service.getOffreTitre(e.getIdOffre()));
            offreLabel.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: #1E293B;");
            offreLabel.setWrapText(true);

            Label statutLabel = new Label(getStatutText(e.getStatut()));
            statutLabel.setStyle("-fx-background-color: " + getStatutColor(e.getStatut()) + "; " +
                    "-fx-text-fill: white; -fx-padding: 4 12; " +
                    "-fx-background-radius: 12; -fx-font-size: 12px; -fx-font-weight: bold;");

            titleBox.getChildren().addAll(offreLabel, statutLabel);
            headerBox.getChildren().addAll(iconLabel, titleBox);

            VBox infoBox = new VBox(15);
            infoBox.setStyle("-fx-background-color: #F8FAFC; -fx-padding: 20; -fx-background-radius: 8;");

            Label recruteurInfo = new Label("👨‍💼 Recruteur : " + service.getRecruteurNom(e.getIdRecruteur()));
            recruteurInfo.setStyle("-fx-font-size: 14px; -fx-text-fill: #475569;");

            String dateStr = (e.getDateEntretien() != null)
                    ? e.getDateEntretien().toLocalDate().format(DateTimeFormatter.ofPattern("EEEE dd MMMM yyyy"))
                    : "Non définie";
            Label dateInfo = new Label("📅 Date : " + dateStr);
            dateInfo.setStyle("-fx-font-size: 14px; -fx-text-fill: #475569;");

            String heureStr = (e.getHeureDebut() != null && e.getHeureFin() != null)
                    ? e.getHeureDebut().toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm")) +
                    " - " + e.getHeureFin().toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))
                    : "Non défini";
            Label heureInfo = new Label("🕐 Horaire : " + heureStr);
            heureInfo.setStyle("-fx-font-size: 14px; -fx-text-fill: #475569;");

            if ("présentiel".equals(e.getTypeEntretien())) {
                String lieu = (e.getLieu() != null && !e.getLieu().isEmpty())
                        ? e.getLieu() : "Non défini";
                Label lieuInfo = new Label("📍 Lieu : " + lieu);
                lieuInfo.setStyle("-fx-font-size: 14px; -fx-text-fill: #475569;");
                lieuInfo.setWrapText(true);
                infoBox.getChildren().addAll(recruteurInfo, dateInfo, heureInfo, lieuInfo);
            } else {
                String lien = (e.getLienVisio() != null && !e.getLienVisio().isEmpty())
                        ? e.getLienVisio() : "Non défini";
                Hyperlink lienInfo = new Hyperlink("🔗 Lien visio : " + lien);
                lienInfo.setStyle("-fx-font-size: 14px; -fx-text-fill: #3498db;");
                lienInfo.setWrapText(true);
                if (e.getLienVisio() != null && !e.getLienVisio().isEmpty()) {
                    lienInfo.setOnAction(ev -> {
                        try {
                            Desktop.getDesktop().browse(new URI(e.getLienVisio()));
                        } catch (Exception ex) {
                            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible d'ouvrir le lien");
                        }
                    });
                }
                infoBox.getChildren().addAll(recruteurInfo, dateInfo, heureInfo, lienInfo);
            }

            if (e.getNoteRecruteur() != null && !e.getNoteRecruteur().isEmpty()) {
                VBox noteBox = new VBox(10);
                noteBox.setStyle("-fx-background-color: #FEF3C7; -fx-padding: 15; -fx-background-radius: 8;");

                Label noteTitle = new Label("📝 Note du recruteur");
                noteTitle.setStyle("-fx-font-weight: bold; -fx-text-fill: #854D0E;");

                Label noteContent = new Label(e.getNoteRecruteur());
                noteContent.setStyle("-fx-text-fill: #854D0E;");
                noteContent.setWrapText(true);

                noteBox.getChildren().addAll(noteTitle, noteContent);
                infoBox.getChildren().add(noteBox);
            }

            content.getChildren().addAll(headerBox, infoBox);
            dialogPane.setContent(content);

            ButtonType fermerButton = new ButtonType("Fermer", ButtonBar.ButtonData.CANCEL_CLOSE);
            dialogPane.getButtonTypes().add(fermerButton);

            dialog.showAndWait();

        } catch (SQLException ex) {
            showAlert(Alert.AlertType.ERROR, "Erreur",
                    "Impossible de charger les détails : " + ex.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}