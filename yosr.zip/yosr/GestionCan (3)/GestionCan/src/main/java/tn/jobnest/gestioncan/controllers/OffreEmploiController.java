package tn.jobnest.gestioncan.controllers;

import tn.jobnest.gestioncan.models.Offre; // Assure-toi d'avoir ce modèle
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableView;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.io.IOException;

public class OffreEmploiController {

    // On suppose que tu as un tableau affichant les offres
    @FXML private TableView<Offre> tableOffres;

    @FXML
    public void handlePostuler() {
        // 1. Récupérer l'offre sélectionnée par l'utilisateur
        Offre offreSelectionnee = tableOffres.getSelectionModel().getSelectedItem();

        if (offreSelectionnee == null) {
            afficherAlerte("Aucune sélection", "Veuillez sélectionner une offre d'emploi dans la liste.");
            return;
        }

        try {
            // 2. Charger la vue Popup (PostulerModal.fxml)
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/PostulerModal.fxml"));
            Parent root = loader.load();

            // 3. Récupérer le contrôleur de la popup
            PostulerController controller = loader.getController();

            // 4. Passer les VRAIES données (ID et Titre de l'offre cliquée)
            controller.setOffrePourAjout(offreSelectionnee.getIdOffre(), offreSelectionnee.getTitre());

            // 5. Afficher la fenêtre en mode Modal
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL); // Bloque la fenêtre derrière
            stage.setTitle("Postuler à : " + offreSelectionnee.getTitre());
            stage.setScene(new Scene(root));
            stage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
            afficherAlerte("Erreur", "Impossible d'ouvrir la fenêtre de candidature.");
        }
    }

    // Petite méthode utilitaire pour les alertes
    private void afficherAlerte(String titre, String contenu) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(contenu);
        alert.showAndWait();
    }
}