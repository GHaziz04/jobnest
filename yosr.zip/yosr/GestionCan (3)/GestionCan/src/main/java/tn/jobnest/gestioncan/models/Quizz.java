// ✅ DANS tn.jobnest.gestioncan.models.Quizz.java
package tn.jobnest.gestioncan.models;

public class Quizz {
    private int idQuizz;
    private int idRessource;
    private String titre;
    private int scoreReussite;

    public Quizz(int idQuizz, int idRessource, String titre, int scoreReussite) {
        this.idQuizz = idQuizz;
        this.idRessource = idRessource;
        this.titre = titre;
        this.scoreReussite = scoreReussite;
    }

    // Getters
    public int getIdQuizz() { return idQuizz; }
    public String getTitre() { return titre; }
    public int getScoreReussite() { return scoreReussite; }
}