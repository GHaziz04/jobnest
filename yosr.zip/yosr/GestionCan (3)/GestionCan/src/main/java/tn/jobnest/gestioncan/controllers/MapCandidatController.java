package tn.jobnest.gestioncan.controllers;

import javafx.application.Platform;
import javafx.concurrent.Worker;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class MapCandidatController {

    @FXML private WebView webView;
    @FXML private Label   labelAdresse;
    @FXML private Label   labelTitre;
    @FXML private Button  btnFermer;

    private WebEngine webEngine;
    private String adresseCible;
    private String titreCible;
    private boolean pageReady = false;

    @FXML
    public void initialize() {
        webEngine = webView.getEngine();
        webEngine.setJavaScriptEnabled(true);

        webView.setMinSize(0, 0);
        webView.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
        webView.setPrefSize(Double.MAX_VALUE, Double.MAX_VALUE);

        // ✅ HTML embarqué directement — plus de problème de chemin
        webEngine.loadContent(getHtmlContent(), "text/html");

        webEngine.getLoadWorker().stateProperty().addListener((obs, oldState, newState) -> {
            if (newState == Worker.State.SUCCEEDED) {
                pageReady = true;
                Platform.runLater(() -> {
                    if (adresseCible != null) envoyerAdresse();
                    forceInvalidateSize();
                    tenterInjecterPositionGPS();
                });
            }
        });

        webView.widthProperty() .addListener((o, ov, nv) -> { if (pageReady) forceInvalidateSize(); });
        webView.heightProperty().addListener((o, ov, nv) -> { if (pageReady) forceInvalidateSize(); });
    }

    public void setAdresse(String adresse, String titre) {
        this.adresseCible = (adresse != null) ? adresse.trim() : "";
        this.titreCible   = (titre   != null) ? titre.trim()   : "Entretien";
        if (labelAdresse != null) labelAdresse.setText("📍 " + adresseCible);
        if (labelTitre   != null) labelTitre  .setText(titreCible);
        if (pageReady) Platform.runLater(this::envoyerAdresse);
    }

    private void envoyerAdresse() {
        if (adresseCible == null || adresseCible.isEmpty()) return;
        try {
            String escaped = adresseCible
                    .replace("\\", "\\\\").replace("'",  "\\'")
                    .replace("\"", "\\\"").replace("\r", "").replace("\n", " ");
            webEngine.executeScript("afficherAdresse('" + escaped + "')");
        } catch (Exception ex) {
            System.err.println("Erreur envoyerAdresse : " + ex.getMessage());
        }
    }

    private void tenterInjecterPositionGPS() {
        Thread t = new Thread(() -> {
            try {
                java.net.URL api = new java.net.URL("http://ip-api.com/json/?fields=lat,lon,status");
                java.net.HttpURLConnection c = (java.net.HttpURLConnection) api.openConnection();
                c.setRequestMethod("GET");
                c.setConnectTimeout(5000);
                c.setReadTimeout(5000);
                if (c.getResponseCode() == 200) {
                    java.io.BufferedReader r = new java.io.BufferedReader(
                            new java.io.InputStreamReader(c.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line);
                    r.close();
                    String json = sb.toString();
                    if (json.contains("\"status\":\"success\"")) {
                        double lat = extraireDouble(json, "lat");
                        double lon = extraireDouble(json, "lon");
                        if (lat != 0.0 && lon != 0.0) {
                            final double fLat = lat, fLon = lon;
                            Platform.runLater(() -> {
                                try {
                                    webEngine.executeScript("setUserPosition(" + fLat + "," + fLon + ")");
                                } catch (Exception ex) {
                                    System.err.println("Erreur GPS : " + ex.getMessage());
                                }
                            });
                        }
                    }
                }
                c.disconnect();
            } catch (Exception e) {
                System.out.println("GPS IP non disponible : " + e.getMessage());
            }
        });
        t.setDaemon(true);
        t.start();
    }

    private void forceInvalidateSize() {
        String js = "try{if(typeof map!=='undefined'&&map){map.invalidateSize({animate:false,pan:false});}}catch(e){}";
        try { webEngine.executeScript(js); } catch (Exception ignored) {}
        int[] delays = {100, 300, 600, 1200, 2500};
        for (int d : delays) {
            Thread t = new Thread(() -> {
                try { Thread.sleep(d); } catch (InterruptedException ex) { return; }
                Platform.runLater(() -> {
                    try { webEngine.executeScript(js); } catch (Exception ignored) {}
                });
            });
            t.setDaemon(true);
            t.start();
        }
    }

    private double extraireDouble(String json, String key) {
        try {
            String search = "\"" + key + "\":";
            int idx = json.indexOf(search);
            if (idx == -1) return 0.0;
            int start = idx + search.length(), end = start;
            while (end < json.length() && (Character.isDigit(json.charAt(end))
                    || json.charAt(end) == '.' || json.charAt(end) == '-')) end++;
            return Double.parseDouble(json.substring(start, end));
        } catch (Exception e) { return 0.0; }
    }

    @FXML
    private void fermer() {
        Stage stage = (Stage) btnFermer.getScene().getWindow();
        stage.close();
    }

    // ✅ HTML COMPLET EMBARQUÉ DANS LE JAVA — plus de fichier externe nécessaire
    private String getHtmlContent() {
        return "<!DOCTYPE html>\n" +
                "<html lang='fr'>\n" +
                "<head>\n" +
                "<meta charset='UTF-8'/>\n" +
                "<title>JobNest - Carte Candidat</title>\n" +
                "<style>\n" +
                ".leaflet-pane,.leaflet-tile,.leaflet-marker-icon,.leaflet-marker-shadow,.leaflet-tile-container,.leaflet-pane>svg,.leaflet-pane>canvas,.leaflet-zoom-box,.leaflet-image-layer,.leaflet-layer{position:absolute;left:0;top:0}" +
                ".leaflet-container{overflow:hidden}" +
                ".leaflet-tile,.leaflet-marker-icon,.leaflet-marker-shadow{-webkit-user-select:none;-moz-user-select:none;user-select:none;-webkit-user-drag:none}" +
                ".leaflet-tile{filter:inherit;visibility:hidden}.leaflet-tile-loaded{visibility:inherit}" +
                ".leaflet-pane{z-index:400}.leaflet-tile-pane{z-index:200}.leaflet-overlay-pane{z-index:400}" +
                ".leaflet-shadow-pane{z-index:500}.leaflet-marker-pane{z-index:600}.leaflet-tooltip-pane{z-index:650}" +
                ".leaflet-popup-pane{z-index:700}.leaflet-map-pane canvas{z-index:100}.leaflet-map-pane svg{z-index:200}" +
                ".leaflet-control{position:relative;z-index:800;pointer-events:visiblePainted;pointer-events:auto}" +
                ".leaflet-top,.leaflet-bottom{position:absolute;z-index:1000;pointer-events:none}" +
                ".leaflet-top{top:0}.leaflet-right{right:0}.leaflet-bottom{bottom:0}.leaflet-left{left:0}" +
                ".leaflet-control{float:left;clear:both}.leaflet-right .leaflet-control{float:right}" +
                ".leaflet-top .leaflet-control{margin-top:10px}.leaflet-bottom .leaflet-control{margin-bottom:10px}" +
                ".leaflet-left .leaflet-control{margin-left:10px}.leaflet-right .leaflet-control{margin-right:10px}" +
                ".leaflet-fade-anim .leaflet-popup{opacity:0;transition:opacity .2s linear}" +
                ".leaflet-fade-anim .leaflet-map-pane .leaflet-popup{opacity:1}" +
                ".leaflet-zoom-animated{-webkit-transform-origin:0 0;transform-origin:0 0}" +
                ".leaflet-zoom-anim .leaflet-zoom-animated{transition:transform .25s cubic-bezier(0,0,.25,1)}" +
                ".leaflet-interactive{cursor:pointer}.leaflet-grab{cursor:grab}" +
                ".leaflet-dragging .leaflet-grab,.leaflet-dragging .leaflet-grab .leaflet-interactive{cursor:grabbing}" +
                ".leaflet-marker-icon,.leaflet-marker-shadow,.leaflet-image-layer,.leaflet-pane>svg path,.leaflet-tile-container{pointer-events:none}" +
                ".leaflet-marker-icon.leaflet-interactive,.leaflet-image-layer.leaflet-interactive,.leaflet-pane>svg path.leaflet-interactive{pointer-events:visiblePainted;pointer-events:auto}" +
                ".leaflet-popup{position:absolute;text-align:center;margin-bottom:20px}" +
                ".leaflet-popup-content-wrapper,.leaflet-popup-tip{background:#fff;color:#333;box-shadow:0 3px 14px rgba(0,0,0,.4)}" +
                ".leaflet-popup-content-wrapper{padding:1px;text-align:left;border-radius:12px}" +
                ".leaflet-popup-tip-container{width:40px;height:20px;position:absolute;left:50%;margin-left:-20px;overflow:hidden;pointer-events:none;display:none}" +
                ".leaflet-popup-content{margin:13px 24px;line-height:1.3;font-size:13px}" +
                ".leaflet-popup-close-button{position:absolute;top:0;right:0;border:none;width:24px;height:24px;font:16px/24px Tahoma,Verdana,sans-serif;color:#757575;text-decoration:none;background:transparent}" +
                ".leaflet-container{background:#ddd}" +
                ".leaflet-container .leaflet-control-attribution{background:rgba(255,255,255,.8);margin:0}" +
                ".leaflet-control-zoom,.leaflet-control-layers{background:#fff;box-shadow:0 1px 5px rgba(0,0,0,.65);border-radius:4px}" +
                ".leaflet-control-zoom a{width:26px;height:26px;line-height:26px;display:block;text-align:center;text-decoration:none;color:#444;font:bold 18px monospace}" +
                ".leaflet-control-zoom a:hover{background-color:#f4f4f4}.leaflet-control-zoom-in{border-bottom:1px solid #ccc}" +
                ".leaflet-touch .leaflet-control-zoom{border:2px solid rgba(0,0,0,.2)}" +
                ".leaflet-popup-content-wrapper{border-radius:13px!important;box-shadow:0 7px 25px rgba(15,36,68,.15)!important;padding:0!important;overflow:hidden}" +
                ".leaflet-popup-content{margin:0!important;min-width:185px}" +
                ":root{--navy:#0F2444;--blue:#1A6BFF;--blue2:#0E54CC;--green:#00C37A;--green2:#00A566;--red:#FF3B5C;--slate:#64748B;--light:#F0F4FF;--border:#DDE5F4;}" +
                "*{margin:0;padding:0;box-sizing:border-box;}" +
                "html,body{width:100%;height:100%;overflow:hidden;font-family:'Segoe UI',Tahoma,Arial,sans-serif;background:var(--light);display:flex;flex-direction:column;}" +
                "#topbar{flex:0 0 auto;display:flex;align-items:center;gap:8px;padding:10px 14px;background:#fff;border-bottom:1.5px solid var(--border);box-shadow:0 2px 10px rgba(15,36,68,.07);z-index:1000;}" +
                ".tb{display:flex;align-items:center;gap:6px;padding:9px 16px;border:none;border-radius:11px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit;transition:opacity .18s,transform .12s;white-space:nowrap;}" +
                ".tb:hover{opacity:.88;transform:translateY(-1px);}.tb:active{transform:scale(.97);}" +
                ".tbg{background:linear-gradient(135deg,var(--green),var(--green2));color:#fff;box-shadow:0 3px 12px rgba(0,195,122,.3);}" +
                ".tbr{background:linear-gradient(135deg,var(--red),#CC2044);color:#fff;display:none;}" +
                "#dest-info{flex:1;padding:8px 14px;border-radius:11px;background:var(--light);border:1.5px solid var(--border);font-size:13px;color:var(--navy);font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}" +
                "#mw{flex:1 1 auto;position:relative;min-height:0;overflow:hidden;}" +
                "#map{position:absolute!important;top:0!important;left:0!important;right:0!important;bottom:0!important;width:100%!important;height:100%!important;}" +
                "#rp{position:absolute;top:12px;right:12px;width:252px;background:#fff;border-radius:16px;box-shadow:0 8px 30px rgba(15,36,68,.15);z-index:900;overflow:hidden;opacity:0;transform:translateX(28px);pointer-events:none;transition:opacity .3s,transform .3s;}" +
                "#rp.on{opacity:1;transform:translateX(0);pointer-events:all;}" +
                "#rph{background:linear-gradient(135deg,#0F2444,#1a3a6e);padding:14px 16px 12px;}" +
                ".rtag{display:inline-block;background:rgba(26,107,255,.28);color:rgba(255,255,255,.9);font-size:9.5px;font-weight:700;padding:2px 9px;border-radius:20px;margin-bottom:7px;text-transform:uppercase;letter-spacing:.5px;}" +
                ".rtit{color:#fff;font-size:14px;font-weight:800;margin-bottom:2px;}.rsub{color:rgba(255,255,255,.58);font-size:10.5px;}" +
                "#rpb{padding:13px 15px;}" +
                ".rst{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:13px;}" +
                ".rsc{background:var(--light);border-radius:10px;padding:10px 11px;border:1.5px solid var(--border);}" +
                ".rsv{font-size:15px;font-weight:800;color:var(--navy);}.rsl{font-size:9.5px;color:var(--slate);font-weight:600;margin-top:1px;}" +
                ".rml{font-size:9.5px;font-weight:800;color:var(--slate);text-transform:uppercase;letter-spacing:.6px;margin-bottom:6px;}" +
                ".rmr{display:flex;gap:5px;margin-bottom:12px;}" +
                ".mb{flex:1;padding:7px 3px;border:1.5px solid var(--border);border-radius:9px;background:#fff;cursor:pointer;font-size:11px;text-align:center;transition:all .2s;font-family:inherit;font-weight:700;color:var(--slate);line-height:1.4;}" +
                ".mb:hover{border-color:var(--blue);background:var(--light);}.mb.on{border-color:var(--blue);background:linear-gradient(135deg,#EBF2FF,#F0F7FF);color:var(--blue);}" +
                ".sep{height:1px;background:var(--border);margin:2px 0 12px;}" +
                "#rpinf{display:none;align-items:center;gap:7px;background:#F0FFF8;border:1.5px solid #B3F0D8;border-radius:9px;padding:7px 11px;margin-bottom:10px;font-size:10.5px;color:#0A6644;font-weight:600;}" +
                "#rpcl{width:100%;padding:8px;background:#FFF0F3;color:var(--red);border:1.5px solid #FFCCD5;border-radius:9px;font-family:inherit;font-size:11.5px;font-weight:700;cursor:pointer;transition:background .2s;display:flex;align-items:center;justify-content:center;gap:5px;}" +
                "#rpcl:hover{background:#FFE0E6;}" +
                "#gpsbar{display:none;position:absolute;bottom:12px;left:50%;transform:translateX(-50%);background:#FFFBEB;border:1.5px solid #FCD34D;color:#78350F;border-radius:11px;padding:9px 16px;font-size:11.5px;font-weight:600;z-index:900;text-align:center;max-width:360px;}" +
                "#gpsbar.on{display:block;}" +
                "#ov{position:absolute;inset:0;background:rgba(240,244,255,.92);display:flex;align-items:center;justify-content:center;z-index:2000;}" +
                "#ov.h{display:none;}" +
                ".lc{background:#fff;border-radius:14px;box-shadow:0 8px 28px rgba(15,36,68,.13);padding:20px 30px;display:flex;align-items:center;gap:13px;font-size:13px;font-weight:700;color:var(--navy);}" +
                ".sp{width:22px;height:22px;border:3px solid var(--border);border-top-color:var(--blue);border-radius:50%;animation:spin .7s linear infinite;flex-shrink:0;}" +
                "@keyframes spin{to{transform:rotate(360deg);}}" +
                "#toast{position:absolute;bottom:18px;left:50%;transform:translateX(-50%) translateY(65px);background:var(--navy);color:#fff;padding:9px 20px;border-radius:28px;font-size:12.5px;font-weight:600;box-shadow:0 5px 18px rgba(15,36,68,.22);z-index:3000;transition:transform .3s cubic-bezier(.34,1.56,.64,1);pointer-events:none;white-space:nowrap;}" +
                "#toast.on{transform:translateX(-50%) translateY(0);}" +
                "#toast.s{background:linear-gradient(135deg,var(--green),var(--green2));}" +
                "#toast.e{background:linear-gradient(135deg,var(--red),#CC2044);}" +
                ".udot{width:15px;height:15px;background:var(--blue);border-radius:50%;border:3px solid #fff;box-shadow:0 0 0 5px rgba(26,107,255,.25);animation:pu 2s infinite;}" +
                "@keyframes pu{0%,100%{box-shadow:0 0 0 5px rgba(26,107,255,.25);}50%{box-shadow:0 0 0 10px rgba(26,107,255,.06);}}" +
                ".pstrip{height:4px;background:linear-gradient(to right,var(--blue),var(--green));}" +
                ".pin{padding:12px 15px 14px;}.pbadge{display:inline-flex;align-items:center;background:linear-gradient(135deg,var(--blue),var(--blue2));color:#fff;font-size:9px;font-weight:800;padding:2px 8px;border-radius:20px;margin-bottom:6px;text-transform:uppercase;}" +
                ".ptit{font-weight:800;font-size:12.5px;color:var(--navy);margin-bottom:3px;}.padr{font-size:10.5px;color:var(--slate);line-height:1.5;}" +
                ".leaflet-control-zoom a{border-radius:9px!important;border:1.5px solid var(--border)!important;color:var(--navy)!important;font-weight:800!important;}" +
                ".leaflet-control-zoom{border:none!important;}" +
                "</style>\n" +
                "</head>\n" +
                "<body>\n" +
                "<div id='topbar'>\n" +
                "  <div id='dest-info'>\n" +
                "    <svg width='13' height='13' viewBox='0 0 24 24' fill='none' stroke='#1A6BFF' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round' style='vertical-align:middle;margin-right:5px;'><circle cx='12' cy='10' r='3'/><path d='M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z'/></svg>\n" +
                "    <span id='dest-label'>Chargement de l'adresse...</span>\n" +
                "  </div>\n" +
                "  <button class='tb tbg' onclick='doRoute()'>\n" +
                "    <svg width='13' height='13' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'><polygon points='3 11 22 2 13 21 11 13 3 11'/></svg>\n" +
                "    Mon itin&eacute;raire\n" +
                "  </button>\n" +
                "  <button class='tb tbr' id='btn-clear' onclick='doClear()'>\n" +
                "    <svg width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'><line x1='18' y1='6' x2='6' y2='18'/><line x1='6' y1='6' x2='18' y2='18'/></svg>\n" +
                "    Effacer\n" +
                "  </button>\n" +
                "</div>\n" +
                "<div id='mw'>\n" +
                "  <div id='map'></div>\n" +
                "  <div id='rp'>\n" +
                "    <div id='rph'><div class='rtag'>Navigation</div><div class='rtit'>Itin&eacute;raire calcul&eacute;</div><div class='rsub'>Votre position &rarr; Destination</div></div>\n" +
                "    <div id='rpb'>\n" +
                "      <div class='rst'>\n" +
                "        <div class='rsc'><div class='rsv' id='rdist'>--</div><div class='rsl'>Distance</div></div>\n" +
                "        <div class='rsc'><div class='rsv' id='rdur'>--</div><div class='rsl'>Dur&eacute;e</div></div>\n" +
                "      </div>\n" +
                "      <div class='rml'>Mode de transport</div>\n" +
                "      <div class='rmr'>\n" +
                "        <button class='mb on' id='m-driving-car' onclick=\"doMode('driving-car')\">Voiture</button>\n" +
                "        <button class='mb' id='m-foot-walking' onclick=\"doMode('foot-walking')\">A pied</button>\n" +
                "        <button class='mb' id='m-cycling-regular' onclick=\"doMode('cycling-regular')\">Velo</button>\n" +
                "      </div>\n" +
                "      <div class='sep'></div>\n" +
                "      <div id='rpinf'>Route trac&eacute;e sur la carte</div>\n" +
                "      <button id='rpcl' onclick='doClear()'>Fermer l'itin&eacute;raire</button>\n" +
                "    </div>\n" +
                "  </div>\n" +
                "  <div id='gpsbar'>Cliquez sur la carte pour d&eacute;finir votre point de d&eacute;part</div>\n" +
                "  <div id='ov'><div class='lc'><div class='sp'></div><span id='omsg'>Chargement&hellip;</span></div></div>\n" +
                "  <div id='toast'></div>\n" +
                "</div>\n" +
                "<script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script>\n" +
                "<script>\n" +
                "var ORS_KEY='eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6IjEyNGEzYTM3MGJiMzRhYmE5YmYyMmExZDdlYWQ2MGY0IiwiaCI6Im11cm11cjY0In0=';\n" +
                "var map=null,dstMk=null,usMk=null,clMk=null,rLayers=[],\n" +
                "    cLat=36.8189,cLng=10.1658,uLat=null,uLng=null,\n" +
                "    cAddr='',cMode='driving-car',tt=null,clickMode=false,ready=false,pending=null;\n" +
                "var iDst=L.divIcon({className:'',html:'<div style=\"width:38px;height:38px;display:flex;align-items:flex-end;justify-content:center;\"><div style=\"width:32px;height:32px;background:linear-gradient(135deg,#0F2444,#1A6BFF);border-radius:50% 50% 50% 0;transform:rotate(-45deg);border:3px solid #fff;box-shadow:0 5px 16px rgba(26,107,255,.45);display:flex;align-items:center;justify-content:center;\"><svg style=\"transform:rotate(45deg);\" width=\"14\" height=\"14\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"white\" stroke-width=\"2.5\"><circle cx=\"12\" cy=\"10\" r=\"3\"/><path d=\"M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z\"/></svg></div></div>',iconSize:[38,38],iconAnchor:[19,38],popupAnchor:[0,-40]});\n" +
                "var iUsr=L.divIcon({className:'',html:'<div class=\"udot\"></div>',iconSize:[15,15],iconAnchor:[7,7]});\n" +
                "var iSta=L.divIcon({className:'',html:'<div style=\"width:26px;height:26px;background:linear-gradient(135deg,#00C37A,#00A566);border-radius:50%;border:3px solid #fff;box-shadow:0 3px 10px rgba(0,195,122,.4);display:flex;align-items:center;justify-content:center;\"><svg width=\"12\" height=\"12\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"white\" stroke-width=\"2.5\"><polyline points=\"20 6 9 17 4 12\"/></svg></div>',iconSize:[26,26],iconAnchor:[13,13]});\n" +
                "function initMap(){\n" +
                "  map=L.map('map',{zoomControl:true,fadeAnimation:false,zoomAnimation:false,markerZoomAnimation:false}).setView([cLat,cLng],13);\n" +
                "  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'&copy; OpenStreetMap',maxZoom:19}).addTo(map);\n" +
                "  function rs(){map.invalidateSize({animate:false,pan:false});}\n" +
                "  rs();\n" +
                "  [50,100,200,400,700,1000,1500,2500,4000].forEach(function(d){setTimeout(rs,d);});\n" +
                "  window.addEventListener('resize',function(){rs();setTimeout(rs,100);});\n" +
                "  if(window.ResizeObserver){new ResizeObserver(function(){rs();setTimeout(rs,80);}).observe(document.getElementById('mw'));}\n" +
                "  ready=true;\n" +
                "  hideOv();\n" +
                "  map.on('click',function(e){\n" +
                "    if(!clickMode)return;\n" +
                "    uLat=e.latlng.lat;uLng=e.latlng.lng;\n" +
                "    if(clMk)map.removeLayer(clMk);\n" +
                "    clMk=L.marker([uLat,uLng],{icon:iSta}).addTo(map).bindPopup('<div style=\"padding:7px 11px;font-weight:700;color:#0F2444;\">Point de depart</div>').openPopup();\n" +
                "    clickMode=false;map.getContainer().style.cursor='';\n" +
                "    document.getElementById('gpsbar').classList.remove('on');\n" +
                "    calcRoute(uLat,uLng,cLat,cLng,cMode);\n" +
                "  });\n" +
                "  if(pending){setTimeout(function(){geocodeAndCenter(pending);pending=null;},300);}\n" +
                "}\n" +
                "function geocodeAndCenter(addr){\n" +
                "  showOv('Localisation...');\n" +
                "  fetch('https://nominatim.openstreetmap.org/search?q='+encodeURIComponent(addr)+'&format=json&limit=1&accept-language=fr')\n" +
                "    .then(function(r){return r.json();})\n" +
                "    .then(function(d){\n" +
                "      hideOv();\n" +
                "      if(d&&d.length>0){var lat=parseFloat(d[0].lat),lng=parseFloat(d[0].lon);cLat=lat;cLng=lng;map.setView([lat,lng],15);setTimeout(function(){map.invalidateSize({animate:false});},300);placeDst(lat,lng,addr);toast('Lieu localise !','s');}\n" +
                "      else{toast('Adresse introuvable.','e');}\n" +
                "    }).catch(function(){hideOv();toast('Erreur geocodage.','e');});\n" +
                "}\n" +
                "function placeDst(lat,lng,addr){\n" +
                "  if(dstMk){map.removeLayer(dstMk);dstMk=null;}\n" +
                "  dstMk=L.marker([lat,lng],{icon:iDst}).addTo(map).bindPopup('<div class=\"pstrip\"></div><div class=\"pin\"><div class=\"pbadge\">JobNest</div><div class=\"ptit\">Lieu de l entretien</div><div class=\"padr\">'+esc(addr)+'</div></div>').openPopup();\n" +
                "}\n" +
                "function doRoute(){\n" +
                "  if(!cLat||!cLng){toast('Adresse non chargee.','e');return;}\n" +
                "  if(uLat!==null&&uLng!==null){calcRoute(uLat,uLng,cLat,cLng,cMode);return;}\n" +
                "  showOv('Detection de votre position...');\n" +
                "  if(navigator.geolocation){\n" +
                "    navigator.geolocation.getCurrentPosition(\n" +
                "      function(p){hideOv();uLat=p.coords.latitude;uLng=p.coords.longitude;placeUser(uLat,uLng);calcRoute(uLat,uLng,cLat,cLng,cMode);},\n" +
                "      function(){hideOv();tenterPositionIP();},\n" +
                "      {enableHighAccuracy:true,timeout:8000,maximumAge:0});\n" +
                "  }else{hideOv();tenterPositionIP();}\n" +
                "}\n" +
                "function tenterPositionIP(){\n" +
                "  showOv('Localisation par reseau...');\n" +
                "  fetch('http://ip-api.com/json/?fields=lat,lon,status')\n" +
                "    .then(function(r){return r.json();})\n" +
                "    .then(function(d){\n" +
                "      hideOv();\n" +
                "      if(d.status==='success'&&d.lat&&d.lon){uLat=d.lat;uLng=d.lon;placeUser(uLat,uLng);calcRoute(uLat,uLng,cLat,cLng,cMode);toast('Position detectee !','s');}\n" +
                "      else{clickMode=true;map.getContainer().style.cursor='crosshair';document.getElementById('gpsbar').classList.add('on');toast('Cliquez sur la carte pour votre depart','s');}\n" +
                "    }).catch(function(){hideOv();clickMode=true;map.getContainer().style.cursor='crosshair';document.getElementById('gpsbar').classList.add('on');});\n" +
                "}\n" +
                "function placeUser(lat,lng){\n" +
                "  if(usMk)map.removeLayer(usMk);\n" +
                "  usMk=L.marker([lat,lng],{icon:iUsr}).addTo(map).bindPopup('<div style=\"padding:7px 11px;font-weight:700;color:#1A6BFF;\">Votre position</div>');\n" +
                "}\n" +
                "function calcRoute(fLat,fLng,tLat,tLng,prof){\n" +
                "  showOv('Calcul de l itineraire...');\n" +
                "  clearLayers();\n" +
                "  fetch('https://api.openrouteservice.org/v2/directions/'+prof+'/geojson',{\n" +
                "    method:'POST',\n" +
                "    headers:{'Content-Type':'application/json','Authorization':ORS_KEY},\n" +
                "    body:JSON.stringify({coordinates:[[fLng,fLat],[tLng,tLat]],language:'fr',units:'km'})\n" +
                "  }).then(function(r){if(!r.ok)throw new Error('HTTP '+r.status);return r.json();})\n" +
                "    .then(function(d){\n" +
                "      hideOv();\n" +
                "      if(!d.features||!d.features.length){toast('Aucun itineraire trouve.','e');return;}\n" +
                "      var f=d.features[0],s=f.properties.summary;\n" +
                "      drawRoute(f.geometry);setStats(s.distance,s.duration);\n" +
                "      var coords=f.geometry.coordinates.map(function(c){return[c[1],c[0]];});\n" +
                "      map.fitBounds(L.latLngBounds(coords),{padding:[55,55]});\n" +
                "      setTimeout(function(){map.invalidateSize({animate:false});},250);\n" +
                "      document.getElementById('rp').classList.add('on');\n" +
                "      document.getElementById('btn-clear').style.display='flex';\n" +
                "      document.getElementById('rpinf').style.display='flex';\n" +
                "      toast('Itineraire calcule !','s');\n" +
                "    }).catch(function(err){hideOv();toast('Erreur: '+err.message,'e');});\n" +
                "}\n" +
                "function drawRoute(g){\n" +
                "  var ll=g.coordinates.map(function(c){return[c[1],c[0]];});\n" +
                "  rLayers.push(L.polyline(ll,{color:'rgba(26,107,255,.11)',weight:17,lineCap:'round',lineJoin:'round'}).addTo(map));\n" +
                "  rLayers.push(L.polyline(ll,{color:'rgba(15,36,68,.09)',weight:10,lineCap:'round',lineJoin:'round'}).addTo(map));\n" +
                "  rLayers.push(L.polyline(ll,{color:'#1A6BFF',weight:5.5,opacity:.95,lineCap:'round',lineJoin:'round'}).addTo(map));\n" +
                "  rLayers.push(L.polyline(ll,{color:'rgba(255,255,255,.7)',weight:2.5,dashArray:'9,13',lineCap:'round',lineJoin:'round'}).addTo(map));\n" +
                "}\n" +
                "function setStats(dk,ds){\n" +
                "  document.getElementById('rdist').textContent=dk<1?Math.round(dk*1000)+' m':dk.toFixed(1)+' km';\n" +
                "  var m=Math.round(ds/60);\n" +
                "  document.getElementById('rdur').textContent=m>=60?Math.floor(m/60)+'h '+(m%60)+'min':m+' min';\n" +
                "}\n" +
                "function doMode(m){\n" +
                "  cMode=m;\n" +
                "  document.querySelectorAll('.mb').forEach(function(b){b.classList.remove('on');});\n" +
                "  document.getElementById('m-'+m).classList.add('on');\n" +
                "  if(uLat!==null&&uLng!==null)calcRoute(uLat,uLng,cLat,cLng,m);\n" +
                "}\n" +
                "function clearLayers(){\n" +
                "  rLayers.forEach(function(l){if(map&&map.hasLayer(l))map.removeLayer(l);});rLayers=[];\n" +
                "}\n" +
                "function doClear(){\n" +
                "  clearLayers();\n" +
                "  if(usMk){map.removeLayer(usMk);usMk=null;}\n" +
                "  if(clMk){map.removeLayer(clMk);clMk=null;}\n" +
                "  uLat=null;uLng=null;clickMode=false;map.getContainer().style.cursor='';\n" +
                "  document.getElementById('rp').classList.remove('on');\n" +
                "  document.getElementById('btn-clear').style.display='none';\n" +
                "  document.getElementById('gpsbar').classList.remove('on');\n" +
                "  if(cLat&&cLng){placeDst(cLat,cLng,cAddr);map.setView([cLat,cLng],15);}\n" +
                "  toast('Itineraire efface.');\n" +
                "}\n" +
                "function afficherAdresse(addr){\n" +
                "  cAddr=addr;\n" +
                "  document.getElementById('dest-label').textContent=addr;\n" +
                "  if(ready)geocodeAndCenter(addr);\n" +
                "  else pending=addr;\n" +
                "}\n" +
                "function setUserPosition(lat,lng){\n" +
                "  uLat=lat;uLng=lng;\n" +
                "  placeUser(lat,lng);\n" +
                "  if(cLat&&cLng)calcRoute(lat,lng,cLat,cLng,cMode);\n" +
                "}\n" +
                "function showOv(m){document.getElementById('omsg').textContent=m;document.getElementById('ov').classList.remove('h');}\n" +
                "function hideOv(){document.getElementById('ov').classList.add('h');}\n" +
                "function toast(m,t){var el=document.getElementById('toast');el.textContent=m;el.className='on'+(t?' '+t:'');clearTimeout(tt);tt=setTimeout(function(){el.className='';},3500);}\n" +
                "function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\"/g,'&quot;').replace(/'/g,'&#039;');}\n" +
                "window.addEventListener('load',function(){initMap();});\n" +
                "</script>\n" +
                "</body>\n" +
                "</html>";
    }
}