package tn.jobnest.gestioncan.controllers;

import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import tn.jobnest.gestioncan.services.EmailService;
import tn.jobnest.gestioncan.services.ServiceCertificat;
import tn.jobnest.gestioncan.utils.MyDatabase;
import tn.jobnest.gestioncan.utils.SessionManager;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.sql.*;

public class MesCertificatsController {

    @FXML
    private VBox certificatsContainer;

    private final ServiceCertificat serviceCertificat = new ServiceCertificat();
    private final EmailService emailService = new EmailService();
    private final int currentUserId = SessionManager.idCandidatConnecte > 0 ? SessionManager.idCandidatConnecte : 1;

    @FXML
    public void initialize() {
        chargerCertificats();
    }

    private void chargerCertificats() {
        if (certificatsContainer == null) return;
        certificatsContainer.getChildren().clear();

        String sql = "SELECT f.id_formation, f.titre, MAX(cq.date_tentative) as date_obtention, c.nom, c.prenom " +
                "FROM formation f " +
                "JOIN module m ON f.id_formation = m.id_formation " +
                "JOIN ressource r ON m.id_module = r.id_module " +
                "JOIN quizz q ON r.id_ressource = q.id_ressource " +
                "JOIN candidat_quizz cq ON q.id_quizz = cq.id_quizz " +
                "JOIN candidat c ON c.id_user = cq.id_candidat " +
                "WHERE cq.id_candidat = ? GROUP BY f.id_formation, c.nom, c.prenom";

        try {
            Connection cnx = MyDatabase.getInstance().getCnx();
            if (cnx == null || cnx.isClosed()) return;

            try (PreparedStatement ps = cnx.prepareStatement(sql)) {
                ps.setInt(1, currentUserId);
                ResultSet rs = ps.executeQuery();

                boolean aDesCertificats = false;
                while (rs.next()) {
                    aDesCertificats = true;
                    int id = rs.getInt("id_formation");
                    String titre = rs.getString("titre");
                    String date = rs.getString("date_obtention");

                    String nomComplet = (rs.getString("prenom") != null ? rs.getString("prenom") : "")
                            + " " + (rs.getString("nom") != null ? rs.getString("nom") : "");

                    certificatsContainer.getChildren().add(creerLigneCertificat(id, titre, date.trim(), nomComplet.trim()));
                }

                if (!aDesCertificats) {
                    Label lblVide = new Label("Aucun certificat obtenu pour le moment.");
                    lblVide.setStyle("-fx-text-fill: #94A3B8; -fx-font-italic: true;");
                    certificatsContainer.getChildren().add(lblVide);
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur SQL dans MesCertificatsController : " + e.getMessage());
        }
    }

    private HBox creerLigneCertificat(int idFormation, String titre, String dateObtention, String nomComplet) {
        HBox ligne = new HBox(15);
        ligne.setAlignment(Pos.CENTER_LEFT);
        ligne.setPadding(new Insets(15, 25, 15, 25));
        ligne.setPrefHeight(90);

        ligne.setStyle("-fx-background-color: white; -fx-background-radius: 10; " +
                "-fx-border-color: #7C3AED; -fx-border-width: 0 0 0 5; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.05), 5, 0, 0, 2);");

        VBox textBlock = new VBox(5);
        textBlock.setAlignment(Pos.CENTER_LEFT);

        Label lblTitre = new Label(titre);
        lblTitre.setStyle("-fx-font-weight: bold; -fx-font-size: 16px; -fx-text-fill: #1A202C;");

        Label lblDate = new Label("Obtenu le : " + (dateObtention != null ? dateObtention : "N/A"));
        lblDate.setStyle("-fx-font-size: 13px; -fx-text-fill: #64748B;");

        textBlock.getChildren().addAll(lblTitre, lblDate);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // --- BOUTON VISUALISER ---
        Button btnVoir = new Button("👁️");
        btnVoir.setTooltip(new Tooltip("Prévisualiser"));
        btnVoir.setStyle("-fx-background-color: #F7FAFC; -fx-border-color: #E2E8F0; -fx-border-radius: 5;");
        btnVoir.setOnAction(e -> visualiserCertificat(titre, idFormation));

        // --- BOUTON TÉLÉCHARGER ---
        Button btnDownload = new Button("📥");
        btnDownload.setTooltip(new Tooltip("Télécharger sur PC"));
        btnDownload.setStyle("-fx-background-color: #F7FAFC; -fx-border-color: #E2E8F0; -fx-border-radius: 5;");
        btnDownload.setOnAction(e -> {
            FileChooser fc = new FileChooser();
            fc.setInitialFileName("Certificat_" + titre.replaceAll("\\s+", "_") + ".pdf");
            File file = fc.showSaveDialog(btnDownload.getScene().getWindow());
            if (file != null) {
                serviceCertificat.genererPDF(currentUserId, idFormation, titre, file.getAbsolutePath());
            }
        });

        // --- BOUTON ENVOYER PAR EMAIL ---
        Button btnEmail = new Button("Envoyer par Email ✉️");
        btnEmail.setCursor(javafx.scene.Cursor.HAND);
        btnEmail.setStyle("-fx-background-color: #7C3AED; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 5; -fx-padding: 8 15;");

        btnEmail.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog("");
            dialog.setTitle("Partage du certificat");
            dialog.setHeaderText("Où souhaitez-vous envoyer votre certificat ?");
            dialog.setContentText("Veuillez saisir l'adresse e-mail :");

            dialog.showAndWait().ifPresent(emailSaisi -> {
                if (!emailSaisi.trim().isEmpty() && emailSaisi.contains("@")) {
                    try {
                        // 1. Création d'un fichier temporaire robuste
                        File tempFile = File.createTempFile("CertifMail_", ".pdf");
                        tempFile.deleteOnExit(); // Sécurité : supprimé à la fermeture de l'app

                        // 2. Génération du PDF
                        serviceCertificat.genererPDF(currentUserId, idFormation, titre, tempFile.getAbsolutePath());

                        // 3. ✅ PAUSE CRUCIALE : On attend que le fichier soit écrit à 100% sur le disque
                        Thread.sleep(1000);

                        // 4. Envoi via le service Email
                        emailService.envoyerCertificatParEmail(emailSaisi.trim(), nomComplet, titre, tempFile.getAbsolutePath());

                        // 5. Confirmation à l'utilisateur
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Succès");
                        alert.setHeaderText(null);
                        alert.setContentText("L'e-mail a été envoyé avec succès à " + emailSaisi);
                        alert.showAndWait();

                    } catch (IOException | InterruptedException ex) {
                        System.err.println("❌ Erreur Envoi Email : " + ex.getMessage());
                        ex.printStackTrace();
                    }
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Erreur");
                    alert.setContentText("Adresse e-mail invalide.");
                    alert.showAndWait();
                }
            });
        });

        ligne.getChildren().addAll(textBlock, spacer, btnVoir, btnDownload, btnEmail);
        return ligne;
    }

    private void visualiserCertificat(String titre, int idFormation) {
        try {
            // Utilisation d'un préfixe simple pour éviter les problèmes de caractères spéciaux
            File tempFile = File.createTempFile("Preview_", ".pdf");
            tempFile.deleteOnExit();

            serviceCertificat.genererPDF(currentUserId, idFormation, titre, tempFile.getAbsolutePath());

            // ✅ PAUSE : On attend que le PDF soit généré avant d'appeler Edge
            Thread.sleep(800);

            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(tempFile);
            }
        } catch (IOException | InterruptedException e) {
            System.err.println("❌ Erreur visualisation : " + e.getMessage());
        }
    }
}