package tn.jobnest.gestioncan.utils;

public class SessionManager {
    // On fixe l'ID à 1 pour tes tests (assure-toi d'avoir un user avec ID 1 en BDD)
    public static int idCandidatConnecte = 1;
}