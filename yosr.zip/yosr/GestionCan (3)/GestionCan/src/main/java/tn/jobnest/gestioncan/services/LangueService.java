package tn.jobnest.gestioncan.services;

import tn.jobnest.gestioncan.models.Langue;
import tn.jobnest.gestioncan.services.ICrud;
import tn.jobnest.gestioncan.utils.MyDatabase;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LangueService implements ICrud<Langue> {

    private Connection cnx = MyDatabase.getInstance().getCnx();

    @Override
    public void ajouter(Langue l) {
        String req = "INSERT INTO cv_langue (id_candidat, langue, niveau) VALUES (?, ?, ?)";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, l.getIdCandidat());
            ps.setString(2, l.getNom());
            ps.setString(3, l.getNiveau());
            ps.executeUpdate();
            System.out.println("Langue ajoutée !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Langue> getByCandidat(int idCandidat) {
        List<Langue> list = new ArrayList<>();
        String req = "SELECT * FROM cv_langue WHERE id_candidat = ?";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, idCandidat);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Langue(
                        rs.getInt("id"),
                        rs.getInt("id_candidat"),
                        rs.getString("langue"),
                        rs.getString("niveau")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public void supprimer(int id) {
        try {
            String req = "DELETE FROM cv_langue WHERE id = ?";
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override public void modifier(Langue l) {}
    @Override public List<Langue> afficher() { return null; }
    @Override public Map<Integer, Langue> getMap() { return null; }
}