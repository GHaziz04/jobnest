package tn.jobnest.gestioncan.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import tn.jobnest.gestioncan.models.Formations;
import tn.jobnest.gestioncan.models.Module;
import tn.jobnest.gestioncan.models.Ressource;
import tn.jobnest.gestioncan.services.ServiceModule;
import tn.jobnest.gestioncan.services.ServiceQuizz;
import tn.jobnest.gestioncan.services.ServiceRessource;
import tn.jobnest.gestioncan.utils.NavigationService;
import tn.jobnest.gestioncan.utils.SessionManager;
import tn.jobnest.gestioncan.services.ServiceCertificat;

import java.io.File;
import java.io.IOException;
import java.util.Comparator;
import java.util.List;

public class ModulesFormationController {

    @FXML private Label lblNomFormation, lblPourcentage;
    @FXML private VBox containerModules;
    @FXML private ProgressBar progressFormation;

    private final ServiceModule serviceModule = new ServiceModule();
    private final ServiceRessource ressourceService = new ServiceRessource();
    private final ServiceQuizz serviceQuizz = new ServiceQuizz();

    private Formations formationActive;
    private static List<Module> listeModulesSession;
    private static int lastFormationId = -1;
    private boolean modulePrecedentValide = true;

    // ✅ Flag pour n'afficher la pop-up qu'une seule fois
    private boolean isPopupAffichee = false;

    @FXML
    public void initialize() {
        if (progressFormation != null) {
            progressFormation.setStyle("-fx-accent: #38A169;");
        }
    }

    public void chargerModulesPourCandidat(Formations f) {
        if (f == null) return;
        this.formationActive = f;
        isPopupAffichee = false; // Reset pour la nouvelle formation

        if (lblNomFormation != null) {
            lblNomFormation.setText(f.getTitre().toUpperCase());
        }

        if (listeModulesSession == null || lastFormationId != f.getId_formation()) {
            listeModulesSession = serviceModule.getModulesParFormation(f.getId_formation());
            lastFormationId = f.getId_formation();
        }
        refreshUI();
    }

    private void updateProgression() {
        if (listeModulesSession == null || listeModulesSession.isEmpty()) return;

        long modulesComplets = listeModulesSession.stream().filter(Module::isTermine).count();
        double progress = (double) modulesComplets / listeModulesSession.size();

        if (progressFormation != null) {
            progressFormation.setProgress(progress);
        }
        if (lblPourcentage != null) {
            lblPourcentage.setText((int)(progress * 100) + "%");
        }

        // ✅ DÉCLENCHEMENT DE LA POP-UP À 100%
        if (progress >= 1.0 && !isPopupAffichee) {
            isPopupAffichee = true;
            afficherPopupSucces();
        }
    }

    private void afficherPopupSucces() {
        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.initStyle(StageStyle.UTILITY);
        popupStage.setTitle("Félicitations !");

        VBox root = new VBox(20);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(30));
        root.setStyle("-fx-background-color: white;");

        Label icon = new Label("🎉");
        icon.setStyle("-fx-font-size: 50;");

        Label title = new Label("Formation Terminée !");
        title.setStyle("-fx-font-size: 20; -fx-font-weight: bold; -fx-text-fill: #2D3748;");

        Label message = new Label("Bravo ! Vous avez validé tous les modules.\nVotre certificat est désormais disponible.");
        message.setStyle("-fx-text-alignment: center; -fx-text-fill: #718096;");

        Button btnGenerer = new Button("Générer mon Certificat");
        btnGenerer.setStyle("-fx-background-color: #ED8936; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10 20; -fx-background-radius: 5;");

        btnGenerer.setOnAction(e -> {
            popupStage.close();
            handleGenererCertificat(); // Appelle la méthode existante avec le FileChooser
        });

        root.getChildren().addAll(icon, title, message, btnGenerer);

        Scene scene = new Scene(root, 400, 300);
        popupStage.setScene(scene);
        popupStage.show();
    }

    // --- LE RESTE DU CODE (creerCardModule, refreshUI, handleGenererCertificat, etc.) RESTE IDENTIQUE ---

    private void refreshUI() {
        if (containerModules == null) return;
        containerModules.getChildren().clear();
        if (listeModulesSession != null && !listeModulesSession.isEmpty()) {
            listeModulesSession.sort(Comparator.comparingInt(Module::getOrdre));
            modulePrecedentValide = true;
            int idCandidat = SessionManager.idCandidatConnecte;
            for (Module m : listeModulesSession) {
                containerModules.getChildren().add(creerCardModule(m, modulePrecedentValide));
                modulePrecedentValide = serviceQuizz.isModulePrecedentValide(idCandidat, m.getId_module());
            }
            updateProgression();
        }
    }

    private VBox creerCardModule(Module m, boolean estAccessible) {
        VBox card = new VBox(10);
        String color = estAccessible ? (m.isTermine() ? "#38A169" : "#3182CE") : "#CBD5E0";
        String iconeStatus = estAccessible ? (m.isTermine() ? "✅ " : "🔓 ") : "🔒";
        card.setStyle("-fx-background-color: white; -fx-background-radius: 12; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.08), 15, 0, 0, 5); " +
                "-fx-border-color: " + color + "; -fx-border-width: 0 0 0 5; -fx-padding: 15;");
        Label lblTitre = new Label(iconeStatus + m.getOrdre() + ". " + m.getTitre());
        lblTitre.setStyle("-fx-font-weight: bold; -fx-font-size: 16px; -fx-text-fill: " + (estAccessible ? "#1A202C" : "#A0AEC0") + ";");
        Label lblDesc = new Label(m.getDescription() != null ? m.getDescription() : "Consultez les ressources.");
        lblDesc.setStyle("-fx-font-size: 13px; -fx-text-fill: #718096;");
        lblDesc.setWrapText(true);
        FlowPane resourcesFlow = new FlowPane(8, 8);
        resourcesFlow.setPadding(new Insets(10, 0, 0, 0));
        List<Ressource> ressources = ressourceService.getRessourcesParModule(m.getId_module());
        if (ressources != null) {
            for (Ressource r : ressources) {
                resourcesFlow.getChildren().add(creerResourceTag(r, m, estAccessible));
            }
        }
        card.getChildren().addAll(lblTitre, lblDesc, resourcesFlow);
        if (!estAccessible) card.setOpacity(0.6);
        return card;
    }

    private Label creerResourceTag(Ressource r, Module m, boolean estAccessible) {
        String icon = "📄";
        String type = r.getType() != null ? r.getType().toUpperCase() : "DOC";
        if (type.contains("VIDEO")) icon = "▶️";
        else if (type.contains("PDF")) icon = "📕";
        else if (type.contains("QUIZ")) icon = "✨";
        Label tag = new Label(icon + " " + r.getTitre());
        if (estAccessible) {
            tag.setStyle("-fx-background-color: #EDF2F7; -fx-text-fill: #2D3748; -fx-padding: 5 12; -fx-background-radius: 15; -fx-font-size: 11px; -fx-font-weight: bold; -fx-cursor: hand;");
            tag.setOnMouseClicked(e -> ouvrirLecteur(m));
        } else {
            tag.setStyle("-fx-background-color: #F7FAFC; -fx-text-fill: #A0AEC0; -fx-padding: 5 12; -fx-background-radius: 15; -fx-font-size: 11px; -fx-font-weight: bold;");
        }
        return tag;
    }

    private void ouvrirLecteur(Module m) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/details_module.fxml"));
            Parent root = loader.load();
            DetailsModulecontroller controller = loader.getController();
            controller.initData(m);
            NavigationService.getMainController().getContentArea().getChildren().setAll(root);
        } catch (IOException e) { e.printStackTrace(); }
    }

    @FXML
    private void handleRetour() {
        NavigationService.getMainController().chargerVue("/View/Formations.fxml");
    }

    @FXML
    private void handleGenererCertificat() {
        if (formationActive == null) return;
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Enregistrer le certificat");
        fileChooser.setInitialFileName("Certificat_" + formationActive.getTitre().replaceAll("\\s+", "_") + ".pdf");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF", "*.pdf"));
        File file = fileChooser.showSaveDialog(lblNomFormation.getScene().getWindow());
        if (file != null) {
            new ServiceCertificat().genererPDF(SessionManager.idCandidatConnecte, formationActive.getId_formation(), formationActive.getTitre(), file.getAbsolutePath());
        }
    }
}