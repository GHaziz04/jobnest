package tn.jobnest.gestioncan.services;

import java.util.List;
import java.util.Map;

public interface ICrud<T> {

    // CRUD de base
    void ajouter(T t);
    void modifier(T t);
    void supprimer(int id);

    // Lecture avec List (pour les affichages simples)
    List<T> afficher();

    // Lecture avec Map (pour des recherches rapides par ID)
    Map<Integer, T> getMap();
}