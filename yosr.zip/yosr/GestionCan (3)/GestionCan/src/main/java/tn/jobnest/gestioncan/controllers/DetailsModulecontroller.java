package tn.jobnest.gestioncan.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import tn.jobnest.gestioncan.models.Ressource;
import tn.jobnest.gestioncan.models.Module;
import tn.jobnest.gestioncan.models.QuizQuestion;
import tn.jobnest.gestioncan.models.Formations;
import tn.jobnest.gestioncan.services.ServiceRessource;
import tn.jobnest.gestioncan.services.ServiceQuizz;
import tn.jobnest.gestioncan.utils.NavigationService;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DetailsModulecontroller {

    @FXML private VBox sidebarResources;
    @FXML private StackPane viewerContainer;
    @FXML private Label lblTitreModule, lblNomRessource, lblIndex;
    @FXML private Button btnPrecedent, btnSuivant;

    private final ServiceRessource serviceRessource = new ServiceRessource();
    private final ServiceQuizz serviceQuizz = new ServiceQuizz();

    private List<Ressource> listeRessources = new ArrayList<>();
    private List<ToggleGroup> quizGroups = new ArrayList<>();
    private int currentIndex = 0;
    private int idModuleActuel;
    private Module moduleActuel;
    private MediaPlayer mediaPlayer;

    public void initData(Module module) {
        this.moduleActuel = module;
        if (module != null) {
            this.idModuleActuel = module.getId_module();
            if (lblTitreModule != null) {
                lblTitreModule.setText(module.getTitre().toUpperCase());
            }
            System.out.println("✅ Module reçu dans le lecteur : " + module.getTitre());
            chargerDonnees();
        } else {
            System.err.println("❌ Erreur : Le module passé est NULL.");
        }
    }

    private void chargerDonnees() {
        List<Ressource> res = serviceRessource.getRessourcesParModule(idModuleActuel);
        this.listeRessources = (res != null) ? res : new ArrayList<>();

        if (!listeRessources.isEmpty()) {
            currentIndex = 0;
            afficherRessourceActuelle();
        } else {
            if (lblNomRessource != null) lblNomRessource.setText("Aucune ressource");
            viewerContainer.getChildren().setAll(new Label("Ce module ne contient pas encore de ressources."));
            sidebarResources.getChildren().clear();
        }
    }

    private void afficherRessourceActuelle() {
        if (listeRessources.isEmpty()) return;
        stopVideo();

        Ressource res = listeRessources.get(currentIndex);

        if (lblNomRessource != null) {
            lblNomRessource.setText(res.getTitre());
            lblNomRessource.setStyle("-fx-text-fill: #1A202C; -fx-font-size: 22px; -fx-font-weight: bold;");
        }
        if (lblIndex != null) {
            lblIndex.setText("RESSOURCE " + (currentIndex + 1) + " SUR " + listeRessources.size());
            lblIndex.setStyle("-fx-text-fill: #4A5568; -fx-font-weight: bold; -fx-font-size: 13px;");
        }

        viewerContainer.getChildren().clear();

        VBox displayArea = new VBox(25);
        displayArea.setAlignment(Pos.TOP_CENTER);
        displayArea.setPadding(new Insets(40));
        displayArea.setStyle("-fx-background-color: white; -fx-background-radius: 15; -fx-border-color: #E2E8F0; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 10, 0, 0, 5);");
        VBox.setVgrow(displayArea, Priority.ALWAYS);

        String type = (res.getType() != null) ? res.getType().toUpperCase() : "TEXTE";

        if (type.contains("QUIZ")) {
            renderQuizView(displayArea, res);
        } else {
            String contenuStr = res.getValeurContenu();
            if (contenuStr != null && !contenuStr.isEmpty()) {
                String lower = contenuStr.toLowerCase();
                if (lower.endsWith(".mp4") || lower.endsWith(".m4v")) {
                    renderVideoView(displayArea, contenuStr);
                } else if (lower.endsWith(".pdf")) {
                    renderPdfView(displayArea, contenuStr);
                } else {
                    renderTextView(displayArea, res);
                }
            } else {
                Label lblEmpty = new Label("Contenu indisponible.");
                lblEmpty.setStyle("-fx-text-fill: #E53E3E; -fx-font-style: italic;");
                displayArea.getChildren().add(lblEmpty);
            }
        }

        ScrollPane scroll = new ScrollPane(displayArea);
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color: transparent; -fx-background: #F7FAFC;");
        viewerContainer.getChildren().setAll(scroll);

        if (btnPrecedent != null) {
            btnPrecedent.setDisable(currentIndex == 0);
            btnPrecedent.setStyle("-fx-background-color: white; -fx-text-fill: #2D3748; -fx-border-color: #CBD5E0; -fx-background-radius: 8; -fx-font-weight: bold; -fx-cursor: hand;");
        }

        if (btnSuivant != null) {
            boolean isLast = (currentIndex == listeRessources.size() - 1);
            btnSuivant.setText(isLast ? "Terminer" : "Suivant");
            String btnColor = isLast ? "#38A169" : "#3182CE";
            btnSuivant.setStyle("-fx-background-color: " + btnColor + "; -fx-text-fill: white; -fx-background-radius: 8; -fx-font-weight: bold; -fx-cursor: hand;");
        }

        remplirPlanSidebar();
    }

    private void renderQuizView(VBox container, Ressource res) {
        container.getChildren().clear();
        quizGroups.clear();

        List<QuizQuestion> questions = serviceQuizz.getQuizComplet(res.getIdRessource());

        Label headerQuiz = new Label("🎯 Évaluation : " + res.getTitre());
        headerQuiz.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #1A202C; -fx-padding: 0 0 20 0;");
        container.getChildren().add(headerQuiz);

        if (questions == null || questions.isEmpty()) {
            container.getChildren().add(new Label("Aucune question trouvée."));
            return;
        }

        for (int i = 0; i < questions.size(); i++) {
            QuizQuestion q = questions.get(i);
            VBox qBox = new VBox(15);
            qBox.setStyle("-fx-background-color: #F8FAFC; -fx-padding: 20; -fx-background-radius: 10; -fx-border-color: #E2E8F0;");
            VBox.setMargin(qBox, new Insets(0, 0, 15, 0));

            Label lblQuest = new Label((i + 1) + ". " + q.getQuestion());
            lblQuest.setWrapText(true);
            lblQuest.setStyle("-fx-font-weight: bold; -fx-font-size: 16px; -fx-text-fill: #1A202C;");
            qBox.getChildren().add(lblQuest);

            ToggleGroup group = new ToggleGroup();
            quizGroups.add(group);

            if (q.getOptions() != null) {
                for (int j = 0; j < q.getOptions().size(); j++) {
                    RadioButton rb = new RadioButton(q.getOptions().get(j));
                    rb.setToggleGroup(group);
                    // ✅ LA CORRECTION EST ICI : On ajoute l'index pour le score
                    rb.setUserData(String.valueOf(j + 1));
                    rb.setStyle("-fx-text-fill: #2D3748; -fx-font-size: 14px;");
                    qBox.getChildren().add(rb);
                }
            }
            container.getChildren().add(qBox);
        }

        Button btnValider = new Button("Valider mes réponses");
        btnValider.setStyle("-fx-background-color: #3182CE; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 12 30; -fx-background-radius: 8; -fx-cursor: hand;");
        btnValider.setOnAction(e -> calculerEtAfficherScore(questions, container, res.getIdRessource()));
        container.getChildren().add(btnValider);
    }

    private void calculerEtAfficherScore(List<QuizQuestion> questions, VBox container, int idRes) {
        int score = 0;
        int total = questions.size();

        for (int i = 0; i < total; i++) {
            RadioButton selected = (RadioButton) quizGroups.get(i).getSelectedToggle();
            if (selected != null) {
                String indexChoisi = (String) selected.getUserData();
                String indexCorrect = questions.get(i).getReponseCorrecte();
                if (indexChoisi != null && indexChoisi.equals(indexCorrect)) score++;
            }
        }

        double pct = (total > 0) ? ((double) score / total * 100) : 0;
        boolean reussi = pct >= 66.0;

        // ✅ SAUVEGARDE STATIQUE : On utilise SessionManager
        int idCandidat = tn.jobnest.gestioncan.utils.SessionManager.idCandidatConnecte;

        // On appelle la méthode de sauvegarde (on va la créer juste après)
        serviceQuizz.sauvegarderScoreCandidat(idCandidat, idRes, (int) pct);

        // --- Affichage du résultat ---
        container.getChildren().clear();
        VBox resBox = new VBox(20);
        resBox.setAlignment(Pos.CENTER);
        resBox.setPadding(new Insets(50));

        Label lblRes = new Label(reussi ? "🎉 MODULE VALIDÉ !" : "⚠️ SCORE INSUFFISANT");
        lblRes.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: " + (reussi ? "#38A169" : "#E53E3E"));

        Label lblScore = new Label("Votre score : " + (int)pct + "% (Requis: 66%)");
        resBox.getChildren().addAll(lblRes, lblScore);

        if (!reussi) {
            Button btnRetry = new Button("Réessayer");
            btnRetry.setOnAction(e -> afficherRessourceActuelle());
            resBox.getChildren().add(btnRetry);
        } else {
            if (moduleActuel != null) moduleActuel.setTermine(true);
            container.getChildren().add(new Label("Bravo ! Vous pouvez passer à la suite."));
        }
        container.getChildren().add(resBox);
    }

    private void renderVideoView(VBox container, String videoPath) {
        try {
            File file = new File(videoPath);
            if (file.exists()) {
                mediaPlayer = new MediaPlayer(new Media(file.toURI().toString()));
                MediaView mv = new MediaView(mediaPlayer);
                mv.setFitWidth(550);
                Button playBtn = new Button("Lecture / Pause");
                playBtn.setOnAction(e -> {
                    if (mediaPlayer.getStatus() == MediaPlayer.Status.PLAYING) mediaPlayer.pause();
                    else mediaPlayer.play();
                });
                container.getChildren().addAll(mv, playBtn);
            }
        } catch (Exception e) { container.getChildren().add(new Label("Erreur Vidéo")); }
    }

    private void renderPdfView(VBox container, String pdfPath) {
        Button btn = new Button("📄 Ouvrir le PDF");
        btn.setOnAction(e -> {
            try { Desktop.getDesktop().open(new File(pdfPath)); } catch (Exception ex) { ex.printStackTrace(); }
        });
        container.getChildren().add(btn);
    }

    private void renderTextView(VBox container, Ressource res) {
        Label txt = new Label(res.getValeurContenu());
        txt.setWrapText(true);
        container.getChildren().add(txt);
    }

    private void remplirPlanSidebar() {
        sidebarResources.getChildren().clear();
        sidebarResources.setSpacing(5);

        for (int i = 0; i < listeRessources.size(); i++) {
            Ressource r = listeRessources.get(i);
            int idx = i;
            boolean isActive = (i == currentIndex);

            HBox row = new HBox(12);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setPadding(new Insets(15, 20, 15, 20));
            row.setCursor(javafx.scene.Cursor.HAND);

            String icon = "📄";
            if ("QUIZ".equalsIgnoreCase(r.getType())) icon = "🎯";
            else if (r.getValeurContenu().toLowerCase().endsWith(".pdf")) icon = "📕";
            else if (r.getValeurContenu().toLowerCase().endsWith(".mp4")) icon = "▶️";

            Label lblTitre = new Label(icon + "  " + (i + 1) + ". " + r.getTitre());
            lblTitre.setWrapText(true);
            lblTitre.setMaxWidth(220);

            if (isActive) {
                row.setStyle("-fx-background-color: #2D3748; -fx-background-radius: 5; -fx-border-color: #ED8936; -fx-border-width: 0 0 0 5;");
                lblTitre.setStyle("-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 14px;");
            } else {
                row.setStyle("-fx-background-color: transparent;");
                lblTitre.setStyle("-fx-text-fill: #4A5568; -fx-font-weight: 500; -fx-font-size: 14px;");
                row.setOnMouseEntered(e -> row.setStyle("-fx-background-color: #EDF2F7; -fx-background-radius: 5;"));
                row.setOnMouseExited(e -> { if (currentIndex != idx) row.setStyle("-fx-background-color: transparent;"); });
            }

            row.getChildren().add(lblTitre);
            row.setOnMouseClicked(e -> { currentIndex = idx; afficherRessourceActuelle(); });
            sidebarResources.getChildren().add(row);
        }
    }

    private void stopVideo() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.dispose();
            mediaPlayer = null;
        }
    }

    @FXML private void handlePrecedent() {
        if (currentIndex > 0) {
            currentIndex--;
            afficherRessourceActuelle();
        }
    }

    @FXML private void handleSuivant(ActionEvent event) {
        if (currentIndex < listeRessources.size() - 1) {
            currentIndex++;
            afficherRessourceActuelle();
        } else {
            if (moduleActuel != null) {
                moduleActuel.setTermine(true);
                System.out.println("🌟 Module marqué comme terminé localement : " + moduleActuel.getTitre());
            }
            handleRetour(event);
        }
    }

    @FXML private void handleRetour(ActionEvent event) {
        stopVideo();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/ModulesFormation.fxml"));
            Parent root = loader.load();
            ModulesFormationController controller = loader.getController();

            if (moduleActuel != null) {
                Formations f = new Formations();
                f.setId_formation(moduleActuel.getId_formation());
                if (lblTitreModule != null) f.setTitre(lblTitreModule.getText());
                controller.chargerModulesPourCandidat(f);
            }

            NavigationService.getMainController().getContentArea().getChildren().setAll(root);
        } catch (IOException e) {
            System.err.println("❌ Erreur lors du retour : " + e.getMessage());
        }
    }
}