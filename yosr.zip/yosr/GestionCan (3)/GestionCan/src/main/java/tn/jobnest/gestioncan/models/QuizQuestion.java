// ✅ Chemin : src/main/java/tn/jobnest/gestioncan/models/QuizQuestion.java
package tn.jobnest.gestioncan.models;

import java.util.List;

public class QuizQuestion {
    private int idQuestion;
    private String question;
    private List<String> options; // Liste des choix (ex: A, B, C)
    private String reponseCorrecte;

    // Constructeur vide
    public QuizQuestion() {}

    // Constructeur complet (utilisé par le ServiceQuizz)
    public QuizQuestion(int idQuestion, String question, List<String> options, String reponseCorrecte) {
        this.idQuestion = idQuestion;
        this.question = question;
        this.options = options;
        this.reponseCorrecte = reponseCorrecte;
    }

    // --- GETTERS ---
    public int getIdQuestion() { return idQuestion; }
    public String getQuestion() { return question; }
    public List<String> getOptions() { return options; }
    public String getReponseCorrecte() { return reponseCorrecte; }

    // --- SETTERS ---
    public void setIdQuestion(int idQuestion) { this.idQuestion = idQuestion; }
    public void setQuestion(String question) { this.question = question; }
    public void setOptions(List<String> options) { this.options = options; }
    public void setReponseCorrecte(String reponseCorrecte) { this.reponseCorrecte = reponseCorrecte; }
}