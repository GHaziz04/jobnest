package tn.jobnest.gestioncan.models;

import java.sql.Date;

public class Offre {

    private int idOffre;
    private int idRecruteur;
    private String titre;
    private String description;
    private String entreprise;
    private String lieu;
    private String typeContrat;
    private double salaireMin;
    private double salaireMax;
    private String niveauExperience;
    private int nbPostes;
    private int nbPostesRemplis;
    private Date datePublication;
    private Date dateExpiration;
    private String statut;

    // Constructeur
    public Offre() {
    }

    // Getters et Setters
    public int getIdOffre() {
        return idOffre;
    }

    public void setIdOffre(int idOffre) {
        this.idOffre = idOffre;
    }

    public int getIdRecruteur() {
        return idRecruteur;
    }

    public void setIdRecruteur(int idRecruteur) {
        this.idRecruteur = idRecruteur;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEntreprise() {
        return entreprise;
    }

    public void setEntreprise(String entreprise) {
        this.entreprise = entreprise;
    }

    public String getLieu() {
        return lieu;
    }

    public void setLieu(String lieu) {
        this.lieu = lieu;
    }

    public String getTypeContrat() {
        return typeContrat;
    }

    public void setTypeContrat(String typeContrat) {
        this.typeContrat = typeContrat;
    }

    public double getSalaireMin() {
        return salaireMin;
    }

    public void setSalaireMin(double salaireMin) {
        this.salaireMin = salaireMin;
    }

    public double getSalaireMax() {
        return salaireMax;
    }

    public void setSalaireMax(double salaireMax) {
        this.salaireMax = salaireMax;
    }

    public String getNiveauExperience() {
        return niveauExperience;
    }

    public void setNiveauExperience(String niveauExperience) {
        this.niveauExperience = niveauExperience;
    }

    public int getNbPostes() {
        return nbPostes;
    }

    public void setNbPostes(int nbPostes) {
        this.nbPostes = nbPostes;
    }

    public int getNbPostesRemplis() {
        return nbPostesRemplis;
    }

    public void setNbPostesRemplis(int nbPostesRemplis) {
        this.nbPostesRemplis = nbPostesRemplis;
    }

    public Date getDatePublication() {
        return datePublication;
    }

    public void setDatePublication(Date datePublication) {
        this.datePublication = datePublication;
    }

    public Date getDateExpiration() {
        return dateExpiration;
    }

    public void setDateExpiration(Date dateExpiration) {
        this.dateExpiration = dateExpiration;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    // Méthode pour obtenir le salaire formaté
    public String getSalaireFormate() {
        if (salaireMin > 0 && salaireMax > 0) {
            return String.format("%.0f€ - %.0f€", salaireMin, salaireMax);
        } else if (salaireMin > 0) {
            return String.format("À partir de %.0f€", salaireMin);
        } else {
            return "Non communiqué";
        }
    }

    @Override
    public String toString() {
        return "Offre{" +
                "idOffre=" + idOffre +
                ", titre='" + titre + '\'' +
                ", entreprise='" + entreprise + '\'' +
                ", statut='" + statut + '\'' +
                '}';
    }
}
