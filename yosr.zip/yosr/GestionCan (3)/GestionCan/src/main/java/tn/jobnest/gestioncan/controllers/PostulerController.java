package tn.jobnest.gestioncan.controllers;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import tn.jobnest.gestioncan.models.Candidature;
import tn.jobnest.gestioncan.models.DocumentCandidature;
import tn.jobnest.gestioncan.services.CandidatureService;
import tn.jobnest.gestioncan.services.DocumentService;

import java.io.File;

public class PostulerController {

    // --- ÉLÉMENTS FXML ---
    @FXML private Label lblNomOffre;
    @FXML private TextArea txtMessage;
    @FXML private TextField txtNomDocument;
    @FXML private ComboBox<String> comboTypeDocument;
    @FXML private TextField txtCheminFichier;
    @FXML private Button btnValider;

    // --- SERVICES ---
    private final CandidatureService candidatureService = new CandidatureService();
    private final DocumentService documentService = new DocumentService();

    // --- VARIABLES D'ÉTAT ---
    private boolean modeModification = false; // FALSE = Ajout, TRUE = Modif
    private File fichierSelectionne;

    // Données pour l'AJOUT
    private int idOffreCible;
    private final int ID_USER_ACTUEL = 1; // À remplacer par Session.getUser().getId()

    // Données pour la MODIFICATION
    private Candidature candidatureExistante;
    private DocumentCandidature documentExistant;

    @FXML
    public void initialize() {
        // On remplit la liste déroulante au démarrage
        comboTypeDocument.setItems(FXCollections.observableArrayList("CV", "Lettre de motivation", "Diplôme", "Autre"));
        comboTypeDocument.getSelectionModel().select("CV");
    }

    // =========================================================
    // CAS 1 : CONFIGURATION POUR L'AJOUT (Nouvelle candidature)
    // =========================================================
    public void setOffrePourAjout(int idOffre, String titreOffre) {
        this.modeModification = false;
        this.idOffreCible = idOffre;

        // Interface : On vide tout
        lblNomOffre.setText(titreOffre);
        txtMessage.clear();
        txtNomDocument.clear();
        txtCheminFichier.clear();
        btnValider.setText("Envoyer ma candidature");
    }

    // =========================================================
    // CAS 2 : CONFIGURATION POUR LA MODIFICATION (Mise à jour)
    // =========================================================
    public void setCandidaturePourModification(Candidature c) {
        this.modeModification = true;
        this.candidatureExistante = c;

        // Interface : On remplit avec les infos existantes
        lblNomOffre.setText("Modification de candidature");
        txtMessage.setText(c.getMessageComplementaire());
        btnValider.setText("Enregistrer les modifications");

        // On va chercher s'il y a un document lié
        try {
            this.documentExistant = documentService.getByCandidature(c.getIdCandidature());
            if (this.documentExistant != null) {
                txtNomDocument.setText(documentExistant.getNomDocument());
                comboTypeDocument.setValue(documentExistant.getTypeDocument());
                txtCheminFichier.setText(documentExistant.getCheminFichier());
            }
        } catch (Exception e) {
            System.out.println("Pas de document ou erreur de récupération");
        }
    }

    // --- LOGIQUE METIER ---

    @FXML
    private void choisirFichier() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choisir un document");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Fichiers PDF & Images", "*.pdf", "*.jpg", "*.png", "*.docx"));

        Stage stage = (Stage) btnValider.getScene().getWindow();
        this.fichierSelectionne = fileChooser.showOpenDialog(stage);

        if (this.fichierSelectionne != null) {
            txtCheminFichier.setText(this.fichierSelectionne.getAbsolutePath());
            // Si le champ nom est vide, on met le nom du fichier par défaut
            if (txtNomDocument.getText().isEmpty()) {
                txtNomDocument.setText(this.fichierSelectionne.getName());
            }
        }
    }

    @FXML
    private void validerCandidature() {
        // 1. Validation basique
        if (txtMessage.getText().trim().isEmpty()) {
            afficherAlerte(Alert.AlertType.WARNING, "Attention", "Le message au recruteur est obligatoire.");
            return;
        }

        boolean succes = false;

        if (modeModification) {
            // ------------------------------------------------
            // LOGIQUE DE MISE À JOUR (UPDATE)
            // ------------------------------------------------
            candidatureExistante.setMessageComplementaire(txtMessage.getText());
            candidatureService.modifier(candidatureExistante);

            // Gestion du document en modif
            if (documentExistant != null) {
                // On met à jour le document existant
                documentExistant.setNomDocument(txtNomDocument.getText());
                documentExistant.setTypeDocument(comboTypeDocument.getValue());
                if (fichierSelectionne != null) {
                    documentExistant.setCheminFichier(fichierSelectionne.getAbsolutePath());
                }
                documentService.modifier(documentExistant);
            } else if (fichierSelectionne != null) {
                // Pas de doc avant, mais on en ajoute un maintenant
                DocumentCandidature newDoc = new DocumentCandidature();
                newDoc.setIdCandidature(candidatureExistante.getIdCandidature());
                newDoc.setNomDocument(txtNomDocument.getText());
                newDoc.setTypeDocument(comboTypeDocument.getValue());
                newDoc.setCheminFichier(fichierSelectionne.getAbsolutePath());
                documentService.ajouter(newDoc);
            }
            succes = true;

        } else {
            // ------------------------------------------------
            // LOGIQUE DE CRÉATION (INSERT) - C'EST ICI LA CORRECTION
            // ------------------------------------------------
            Candidature nouvelleCandidature = new Candidature();

            // J'utilise les Setters pour être SÛR que l'ID User va au bon endroit
            // Cela évite l'erreur "Foreign Key" si le constructeur inverse les paramètres
            nouvelleCandidature.setIdOffre(idOffreCible);
            nouvelleCandidature.setIdCandidat(1); // Le '1' est bien mis ici
            nouvelleCandidature.setMessageComplementaire(txtMessage.getText());
            nouvelleCandidature.setStatut("En attente");

            // On prépare le document s'il y en a un
            DocumentCandidature doc = null;
            // On vérifie si un fichier est sélectionné OU si le chemin est rempli manuellement
            if (fichierSelectionne != null || !txtCheminFichier.getText().isEmpty()) {
                doc = new DocumentCandidature();
                doc.setNomDocument(txtNomDocument.getText());
                doc.setTypeDocument(comboTypeDocument.getValue());

                // Si fichierSelectionne est null (chemin manuel), on prend le texte
                String chemin = (fichierSelectionne != null) ? fichierSelectionne.getAbsolutePath() : txtCheminFichier.getText();
                doc.setCheminFichier(chemin);
            }

            // Le service s'occupe de créer la candidature ET le document
            succes = candidatureService.postuler(nouvelleCandidature, doc);
        }

        // --- FIN ---
        if (succes) {
            afficherAlerte(Alert.AlertType.INFORMATION, "Succès", "Opération effectuée avec succès !");
            fermer();
        } else {
            afficherAlerte(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors de l'enregistrement.\nVérifiez que vous n'avez pas déjà postulé.");
        }
    }

    @FXML
    private void fermer() {
        Stage stage = (Stage) btnValider.getScene().getWindow();
        stage.close();
    }

    private void afficherAlerte(Alert.AlertType type, String titre, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}