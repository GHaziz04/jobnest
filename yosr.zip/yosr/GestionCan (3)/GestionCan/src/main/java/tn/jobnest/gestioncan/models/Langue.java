package tn.jobnest.gestioncan.models;

public class Langue {
    private int id;
    private int idCandidat;
    private String nom;
    private String niveau;

    // Constructeur complet
    public Langue(int id, int idCandidat, String nom, String niveau) {
        this.id = id;
        this.idCandidat = idCandidat;
        this.nom = nom;
        this.niveau = niveau;
    }

    // Constructeur sans ID
    public Langue(int idCandidat, String nom, String niveau) {
        this.idCandidat = idCandidat;
        this.nom = nom;
        this.niveau = niveau;
    }

    public int getId() { return id; }
    public int getIdCandidat() { return idCandidat; }
    public String getNom() { return nom; }
    public String getNiveau() { return niveau; }

    // IMPORTANT pour la ListView
    @Override
    public String toString() {
        return nom + " (" + niveau + ")";
    }
}