package tn.jobnest.gestioncan.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import tn.jobnest.gestioncan.models.Formations;
import tn.jobnest.gestioncan.services.ServicesFormations;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;

public class FormationsCandidatController {

    @FXML private FlowPane cardsContainer;
    @FXML private TextField txtRecherche;
    @FXML private ComboBox<String> comboTri;

    private final ServicesFormations sf = new ServicesFormations();

    private ObservableList<Formations> masterData = FXCollections.observableArrayList();
    private FilteredList<Formations> filteredData;

    @FXML
    public void initialize() {
        // 1. Initialiser le ComboBox avec les valeurs exactes
        if (comboTri != null) {
            comboTri.setItems(FXCollections.observableArrayList("Prix : Croissant", "Prix : Décroissant", "Par défaut"));
        }

        // 2. Charger les données initiales
        chargerFormationsCandidat();

        // 3. ✅ Configuration de la recherche dynamique AMÉLIORÉE
        if (txtRecherche != null) {
            txtRecherche.textProperty().addListener((observable, oldValue, newValue) -> {
                if (filteredData != null) {
                    filteredData.setPredicate(formation -> {
                        if (newValue == null || newValue.isEmpty()) {
                            return true;
                        }
                        String lowerCaseFilter = newValue.toLowerCase().trim();

                        // Vérification sur titre et niveau (plus fiable que description si elle est longue)
                        boolean matchTitre = formation.getTitre().toLowerCase().contains(lowerCaseFilter);
                        boolean matchNiveau = formation.getNiveau() != null && formation.getNiveau().toLowerCase().contains(lowerCaseFilter);

                        return matchTitre || matchNiveau;
                    });
                    // On force le rendu des cartes filtrées
                    renderCards(filteredData);
                }
            });
        }
    }

    public void chargerFormationsCandidat() {
        if (cardsContainer == null) return;

        List<Formations> listeBDD = sf.afficher();
        masterData.setAll(listeBDD);

        // ✅ Initialisation correcte de la FilteredList
        filteredData = new FilteredList<>(masterData, p -> true);

        System.out.println("📦 [DEBUG] Catalogue : " + masterData.size() + " formations récupérées.");
        renderCards(filteredData);
    }

    @FXML
    private void handleTrier() {
        String choix = comboTri.getValue();
        if (choix == null || masterData.isEmpty()) return;

        // ✅ Le tri doit se faire sur la masterData pour impacter la filteredData
        if (choix.equals("Prix : Croissant")) {
            masterData.sort(Comparator.comparingDouble(Formations::getPrix));
        } else if (choix.equals("Prix : Décroissant")) {
            masterData.sort(Comparator.comparingDouble(Formations::getPrix).reversed());
        } else {
            masterData.sort(Comparator.comparingInt(Formations::getId_formation));
        }

        renderCards(filteredData);
    }

    private void renderCards(List<Formations> listeAAfficher) {
        if (cardsContainer == null) return;

        cardsContainer.getChildren().clear();

        for (Formations f : listeAAfficher) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/card_candidat.fxml"));
                VBox card = loader.load();

                CardCandidatController cardController = loader.getController();
                if (cardController != null) {
                    cardController.setData(f);
                }

                cardsContainer.getChildren().add(card);

            } catch (IOException e) {
                System.err.println("❌ Erreur chargement carte : " + f.getTitre());
            }
        }
    }
}