package tn.jobnest.gestioncan.services;


import tn.jobnest.gestioncan.models.Experience;
import tn.jobnest.gestioncan.services.ICrud;
import tn.jobnest.gestioncan.utils.MyDatabase;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExperienceService implements ICrud<Experience> {

    // Connexion à la base de données
    private Connection cnx = MyDatabase.getInstance().getCnx();

    @Override
    public void ajouter(Experience e) {
        String req = "INSERT INTO cv_experience (id_candidat, poste, entreprise, date_debut, date_fin, description) VALUES (?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, e.getIdCandidat());
            ps.setString(2, e.getPoste());
            ps.setString(3, e.getEntreprise());
            ps.setDate(4, e.getDateDebut()); // Assure-toi que ton modèle utilise java.sql.Date
            ps.setDate(5, e.getDateFin());
            ps.setString(6, e.getDescription());

            ps.executeUpdate();
            System.out.println("Expérience ajoutée avec succès !");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Méthode spécifique pour récupérer les expériences d'un candidat précis
    public List<Experience> getByCandidat(int idCandidat) {
        List<Experience> list = new ArrayList<>();
        String req = "SELECT * FROM cv_experience WHERE id_candidat = ?";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, idCandidat);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                // On crée l'objet Experience à partir des données de la BDD
                Experience e = new Experience(
                        rs.getInt("id"),
                        rs.getInt("id_candidat"),
                        rs.getString("poste"),
                        rs.getString("entreprise"),
                        rs.getDate("date_debut"),
                        rs.getDate("date_fin"),
                        rs.getString("description")
                );
                list.add(e);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }

    @Override
    public void supprimer(int id) {
        String req = "DELETE FROM cv_experience WHERE id = ?";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Expérience supprimée !");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void modifier(Experience e) {
        String req = "UPDATE cv_experience SET poste=?, entreprise=?, date_debut=?, date_fin=?, description=? WHERE id=?";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setString(1, e.getPoste());
            ps.setString(2, e.getEntreprise());
            ps.setDate(3, e.getDateDebut());
            ps.setDate(4, e.getDateFin());
            ps.setString(5, e.getDescription());
            ps.setInt(6, e.getId());

            ps.executeUpdate();
            System.out.println("Expérience modifiée !");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public List<Experience> afficher() {
        // Pas nécessaire pour le CV spécifique, mais utile pour l'admin
        return new ArrayList<>();
    }

    @Override
    public Map<Integer, Experience> getMap() {
        return new HashMap<>();
    }
}