package tn.jobnest.gestioncan.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import tn.jobnest.gestioncan.services.PaymentService;
import tn.jobnest.gestioncan.utils.NavigationService;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.sql.*;
import java.util.Optional;

public class MainLayoutController {

    @FXML private StackPane contentArea;

    // --- BOUTONS MENU ---
    @FXML private Button btnDashboard;
    @FXML private Button btnOffres;
    @FXML private Button btnFormations;
    @FXML private Button btnCandidatures;
    @FXML private Button btnEntretiens;
    @FXML private Button btnCreerCV;
    @FXML private Button btnProfil;
    @FXML private Button btnCertificats; // ✅ AJOUTÉ

    // --- WALLET ---
    @FXML private Label lblSolde;

    // --- PROFILE USER (SIDEBAR - BAS GAUCHE) ---
    @FXML private Label lblUserName;
    @FXML private Label lblUserInitials;
    @FXML private Circle circleAvatar;

    // TODO: À remplacer par la session utilisateur réelle
    private final String USER_EMAIL = "ghribimedaziz007@gmail.com";

    // Config DB
    private final String DB_URL = "jdbc:mysql://localhost:3306/jobnest";
    private final String DB_USER = "root";
    private final String DB_PWD = "";

    // Services
    private final PaymentService paymentService = new PaymentService();

    @FXML
    public void initialize() {
        // 1. Enregistrer ce controller dans NavigationService
        try {
            NavigationService.setMainController(this);
        } catch (Exception e) {
            System.err.println("NavigationService non initialisé ou introuvable : " + e.getMessage());
        }

        // 2. Charger les infos (Nom + Photo)
        updateSidebarUserInfo();

        // 3. Charger le solde (Wallet)
        rafraichirSoldeUI();

        // 4. Afficher la vue par défaut (Dashboard)
        afficherDashboard(null);
    }

    // =================================================================================
    //                                 GESTION WALLET (STRIPE)
    // =================================================================================

    private void rafraichirSoldeUI() {
        String query = "SELECT solde FROM candidat WHERE email = ?";
        try (Connection cnx = DriverManager.getConnection(DB_URL, DB_USER, DB_PWD);
             PreparedStatement pst = cnx.prepareStatement(query)) {

            pst.setString(1, USER_EMAIL);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                double solde = rs.getDouble("solde");
                if (lblSolde != null) {
                    lblSolde.setText(String.format("%.2f TND", solde));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("❌ Erreur chargement solde: " + e.getMessage());
        }
    }

    @FXML
    private void ajouterArgent(ActionEvent event) {
        TextInputDialog dialog = new TextInputDialog("50");
        dialog.setTitle("Recharger le Portefeuille");
        dialog.setHeaderText("Via Stripe (Carte Bancaire)");
        dialog.setContentText("Montant à ajouter (TND):");

        Optional<String> result = dialog.showAndWait();
        if (result.isPresent()) {
            try {
                double montant = Double.parseDouble(result.get());

                if (montant <= 0) {
                    afficherAlerte(Alert.AlertType.WARNING, "Montant invalide",
                            "⚠️ Le montant doit être supérieur à 0.");
                    return;
                }

                String rawData = paymentService.creerSessionPaiement((long)(montant * 100), USER_EMAIL);
                if (rawData == null || !rawData.contains("###")) {
                    throw new Exception("Réponse invalide du service de paiement.");
                }

                String[] parts = rawData.split("###");
                String urlPaiement = parts[0];
                String sessionId = parts[1];

                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().browse(new URI(urlPaiement));
                }

                Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
                confirm.setTitle("Paiement en cours...");
                confirm.setHeaderText("Veuillez valider le paiement dans votre navigateur.");
                confirm.setContentText("Cliquez sur OK une fois le paiement terminé.");

                confirm.showAndWait().ifPresent(response -> {
                    if (response == ButtonType.OK) {
                        boolean isPaid = paymentService.verifierPaiement(sessionId);
                        if (isPaid) {
                            updateSoldeInDB(montant);
                            rafraichirSoldeUI();
                            afficherAlerte(Alert.AlertType.INFORMATION, "Succès",
                                    "✅ Paiement réussi ! Votre solde a été mis à jour.");
                        } else {
                            afficherAlerte(Alert.AlertType.ERROR, "Erreur",
                                    "❌ Le paiement n'a pas été validé par Stripe.");
                        }
                    }
                });

            } catch (NumberFormatException e) {
                afficherAlerte(Alert.AlertType.ERROR, "Erreur",
                        "❌ Veuillez entrer un montant valide.");
            } catch (Exception e) {
                e.printStackTrace();
                afficherAlerte(Alert.AlertType.ERROR, "Erreur",
                        "❌ Erreur lors du processus de paiement: " + e.getMessage());
            }
        }
    }

    private void updateSoldeInDB(double montantAjoute) {
        String req = "UPDATE candidat SET solde = solde + ? WHERE email = ?";
        try (Connection cnx = DriverManager.getConnection(DB_URL, DB_USER, DB_PWD);
             PreparedStatement ps = cnx.prepareStatement(req)) {
            ps.setDouble(1, montantAjoute);
            ps.setString(2, USER_EMAIL);
            ps.executeUpdate();
            System.out.println("✅ Solde mis à jour : +" + montantAjoute + " TND");
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("❌ Erreur mise à jour solde: " + e.getMessage());
        }
    }

    // =================================================================================
    //                                 GESTION USER INFO
    // =================================================================================

    private void updateSidebarUserInfo() {
        String query = "SELECT nom, prenom, image FROM candidat WHERE email = ?";

        try (Connection cnx = DriverManager.getConnection(DB_URL, DB_USER, DB_PWD);
             PreparedStatement pst = cnx.prepareStatement(query)) {

            pst.setString(1, USER_EMAIL);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String nom = rs.getString("nom");
                String prenom = rs.getString("prenom");
                String imagePath = rs.getString("image");

                if (lblUserName != null) {
                    lblUserName.setText(prenom + " " + nom);
                }

                boolean photoChargee = false;
                if (imagePath != null && !imagePath.isEmpty()) {
                    File file = new File(imagePath);
                    if (file.exists()) {
                        Image img = new Image(file.toURI().toString());
                        if (circleAvatar != null) {
                            circleAvatar.setFill(new ImagePattern(img));
                            photoChargee = true;
                        }
                    }
                }

                if (!photoChargee) {
                    String initials = "";
                    if (prenom != null && !prenom.isEmpty()) initials += prenom.charAt(0);
                    if (nom != null && !nom.isEmpty()) initials += nom.charAt(0);

                    if (lblUserInitials != null) {
                        lblUserInitials.setText(initials.toUpperCase());
                    }
                    if (circleAvatar != null) {
                        circleAvatar.setFill(javafx.scene.paint.Color.web("#D69E7D"));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("❌ Erreur chargement infos utilisateur: " + e.getMessage());
        }
    }

    // =================================================================================
    //                                 NAVIGATION
    // =================================================================================

    @FXML
    private void afficherDashboard(ActionEvent event) {
        chargerVue("/View/DashboardCandidat.fxml");
        updateStyle(btnDashboard);
    }

    @FXML
    private void afficherOffres(ActionEvent event) {
        chargerVue("/View/OffresView.fxml");
        updateStyle(btnOffres);
    }

    @FXML
    private void afficherFormations(ActionEvent event) {
        chargerVue("/View/Formations.fxml");
        updateStyle(btnFormations);
    }

    @FXML
    private void afficherCandidatures(ActionEvent event) {
        chargerVue("/View/MesCandidatures.fxml");
        updateStyle(btnCandidatures);
    }

    @FXML
    private void afficherEntretiens(ActionEvent event) {
        chargerVue("/View/entretien-candidat-content.fxml");
        updateStyle(btnEntretiens);
    }

    @FXML
    private void afficherCreerCV(ActionEvent event) {
        chargerVue("/View/CreerCV.fxml");
        updateStyle(btnCreerCV);
    }

    @FXML
    private void afficherProfil(ActionEvent event) {
        chargerVue("/View/profile.fxml");
        updateStyle(btnProfil);
    }

    // ✅ NOUVELLE MÉTHODE : Navigation Certificats
    @FXML
    private void afficherCertificats(ActionEvent event) {
        chargerVue("/View/MesCertificats.fxml");
        updateStyle(btnCertificats);
    }

    // =================================================================================
    //                                 UTILITAIRES
    // =================================================================================

    public void chargerVue(String fxml) {
        try {
            URL location = getClass().getResource(fxml);
            if (location == null) {
                throw new IOException("Fichier FXML introuvable au chemin : " + fxml);
            }
            FXMLLoader loader = new FXMLLoader(location);
            Node node = loader.load();
            contentArea.getChildren().clear();
            contentArea.getChildren().setAll(node);
            System.out.println("✅ Vue chargée: " + fxml);
        } catch (IOException e) {
            System.err.println("❌ Erreur chargement vue: " + fxml);
            e.printStackTrace();
            afficherAlerte(Alert.AlertType.ERROR, "Erreur",
                    "Impossible de charger la vue: " + fxml);
        }
    }

    public StackPane getContentArea() {
        return contentArea;
    }

    private void updateStyle(Button activeBtn) {
        String defaultStyle = "-fx-background-color: transparent; -fx-text-fill: #94A3B8; " +
                "-fx-font-size: 14px; -fx-cursor: hand; -fx-padding: 12 15; " +
                "-fx-alignment: CENTER_LEFT; -fx-background-radius: 8;";

        String activeStyle = "-fx-background-color: #D69E7D; -fx-text-fill: white; " +
                "-fx-font-size: 14px; -fx-font-weight: bold; -fx-background-radius: 8; " +
                "-fx-padding: 12 15; -fx-alignment: CENTER_LEFT;";

        // Liste de tous les boutons pour réinitialiser le style
        Button[] allButtons = {btnDashboard, btnOffres, btnFormations, btnCandidatures,
                btnEntretiens, btnCreerCV, btnProfil, btnCertificats};

        for (Button btn : allButtons) {
            if (btn != null) {
                btn.setStyle(defaultStyle);
            }
        }

        // Appliquer le style actif au bouton sélectionné
        if (activeBtn != null) {
            activeBtn.setStyle(activeStyle);
        }
    }

    private void afficherAlerte(Alert.AlertType type, String titre, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}