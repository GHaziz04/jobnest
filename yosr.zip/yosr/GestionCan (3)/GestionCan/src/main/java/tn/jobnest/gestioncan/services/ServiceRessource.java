package tn.jobnest.gestioncan.services;

import tn.jobnest.gestioncan.models.Ressource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ServiceRessource {

    // Paramètres de connexion directs pour éviter les conflits
    private final String URL = "jdbc:mysql://localhost:3306/jobnest";
    private final String USER = "root";
    private final String PWD = "";

    public List<Ressource> getRessourcesParModule(int idModule) {
        List<Ressource> liste = new ArrayList<>();
        // Requête basée sur tes colonnes SQL
        String sql = "SELECT id_ressource, id_module, titre, type, valeur_contenu, ordre FROM ressource WHERE id_module = ? ORDER BY ordre ASC";

        // ✅ Ouverture d'une connexion isolée
        try (Connection cnx = DriverManager.getConnection(URL, USER, PWD);
             PreparedStatement ps = cnx.prepareStatement(sql)) {

            ps.setInt(1, idModule);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    liste.add(new Ressource(
                            rs.getInt("id_ressource"),
                            rs.getInt("id_module"),
                            rs.getString("titre"),
                            rs.getString("type"),
                            rs.getString("valeur_contenu"),
                            rs.getInt("ordre")
                    ));
                }
            }

            // Log de debug pour voir si les ressources remontent
            System.out.println("📄 Ressources trouvées pour module ID " + idModule + " : " + liste.size());

        } catch (SQLException e) {
            System.err.println("❌ Erreur ServiceRessource : " + e.getMessage());
        }
        return liste;
    }
}