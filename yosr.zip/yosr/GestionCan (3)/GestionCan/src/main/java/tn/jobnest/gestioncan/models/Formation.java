package tn.jobnest.gestioncan.models;

public class Formation {
    private int id;
    private int idCandidat;
    private String diplome;
    private String ecole;
    private int anneeDebut;
    private int anneeFin;

    // Constructeur complet (Lecture BDD)
    public Formation(int id, int idCandidat, String diplome, String ecole, int anneeDebut, int anneeFin) {
        this.id = id;
        this.idCandidat = idCandidat;
        this.diplome = diplome;
        this.ecole = ecole;
        this.anneeDebut = anneeDebut;
        this.anneeFin = anneeFin;
    }

    // Constructeur sans ID (Ajout)
    public Formation(int idCandidat, String diplome, String ecole, int anneeDebut, int anneeFin) {
        this.idCandidat = idCandidat;
        this.diplome = diplome;
        this.ecole = ecole;
        this.anneeDebut = anneeDebut;
        this.anneeFin = anneeFin;
    }

    // Getters
    public int getId() { return id; }
    public int getIdCandidat() { return idCandidat; }
    public String getDiplome() { return diplome; }
    public String getEcole() { return ecole; }
    public int getAnneeDebut() { return anneeDebut; }
    public int getAnneeFin() { return anneeFin; }

    // IMPORTANT : C'est ce qui s'affiche dans la ListView
    @Override
    public String toString() {
        return diplome + " - " + ecole;
    }
}
