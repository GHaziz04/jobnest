package tn.jobnest.gestioncan.services;

import jakarta.mail.*;
import jakarta.mail.internet.*;
import java.io.File;
import java.io.IOException;
import java.util.Properties;

public class EmailService {

    // ✅ CONFIGURATION SMTP (Mise à jour avec vos identifiants)
    private final String myEmail = "yosrlarbech6@gmail.com";
    private final String myPassword = "kpizdyratxottufq"; // Votre code de 16 caractères

    /**
     * Envoie un e-mail avec le certificat en pièce jointe et un design HTML.
     */
    public void envoyerCertificatParEmail(String destinataire, String nomCandidat, String titreFormation, String cheminFichier) {

        // 1. Définition des propriétés du serveur SMTP
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        // 2. Création de la session avec authentification sécurisée
        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(myEmail, myPassword);
            }
        });

        try {
            // 3. Création de l'objet Message
            Message message = new MimeMessage(session);

            // ✅ Identité de l'expéditeur : Votre mail + Nom d'affichage
            message.setFrom(new InternetAddress(myEmail, "JobNest Academy"));

            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinataire));
            message.setSubject("Félicitations ! Votre certificat : " + titreFormation);

            // 4. Création du conteneur Multipart
            Multipart multipart = new MimeMultipart();

            // -- Partie 1 : Le corps du mail en HTML stylisé --
            MimeBodyPart messageBodyPart = new MimeBodyPart();
            String contenuHtml =
                    "<div style='font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #E2E8F0; border-radius: 10px; overflow: hidden;'>" +
                            "<div style='background-color: #7C3AED; padding: 20px; text-align: center;'>" +
                            "<h1 style='color: white; margin: 0; font-size: 24px;'>Félicitations !</h1>" +
                            "</div>" +
                            "<div style='padding: 30px; color: #1A202C; line-height: 1.6;'>" +
                            "<p style='font-size: 18px;'>Bonjour <strong>" + nomCandidat + "</strong>,</p>" +
                            "<p>Vous avez brillamment réussi votre formation : <br>" +
                            "<span style='color: #7C3AED; font-weight: bold; font-size: 20px;'>" + titreFormation + "</span></p>" +
                            "<p>Votre certificat officiel de réussite est disponible en pièce jointe de cet e-mail.</p>" +
                            "<hr style='border: 0; border-top: 1px solid #E2E8F0; margin: 20px 0;'>" +
                            "<p style='font-size: 14px; color: #64748B;'>Ce certificat atteste de vos compétences acquises sur la plateforme <strong>JobNest Academy</strong>.</p>" +
                            "</div>" +
                            "<div style='background-color: #F8FAFC; padding: 15px; text-align: center; color: #94A3B8; font-size: 12px;'>" +
                            "© 2026 JobNest Academy - Tous droits réservés." +
                            "</div>" +
                            "</div>";

            messageBodyPart.setContent(contenuHtml, "text/html; charset=utf-8");
            multipart.addBodyPart(messageBodyPart);

            // -- Partie 2 : La pièce jointe (Le PDF) --
            MimeBodyPart attachmentPart = new MimeBodyPart();
            File sourceFile = new File(cheminFichier);

            if (sourceFile.exists()) {
                attachmentPart.attachFile(sourceFile);
                attachmentPart.setFileName("Certificat_" + titreFormation.replace(" ", "_") + ".pdf");
                multipart.addBodyPart(attachmentPart);
            } else {
                System.err.println("❌ Erreur : Le fichier certificat est introuvable à l'emplacement : " + cheminFichier);
                return;
            }

            // 5. Associer le contenu au message
            message.setContent(multipart);

            // 6. Envoi final
            Transport.send(message);

            System.out.println("✅ E-mail envoyé avec succès de " + myEmail + " vers : " + destinataire);

        } catch (MessagingException | IOException e) {
            System.err.println("❌ Échec de l'envoi de l'e-mail : " + e.getMessage());
            e.printStackTrace();
        }
    }
}