package tn.jobnest.gestioncan.services;

import javafx.application.Platform;
import tn.jobnest.gestioncan.models.Entretien;
import tn.jobnest.gestioncan.models.NotificationCandidat;
import tn.jobnest.gestioncan.utils.MyDatabase;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Service de notifications in-app pour le CANDIDAT.
 * Miroir de NotificationService (côté recruteur).
 *
 * Fonctionnalités :
 *  - Planifier un rappel 24h avant l'entretien
 *  - Planifier un rappel 1h  avant l'entretien
 *  - Détecter et notifier les annulations automatiques
 *  - CRUD notifications en BDD (table notification_candidat)
 */
public class NotificationCandidatService {

    // ── Singleton ────────────────────────────────────────────────────
    private static NotificationCandidatService INSTANCE;

    public static synchronized NotificationCandidatService getInstance() {
        if (INSTANCE == null) INSTANCE = new NotificationCandidatService();
        return INSTANCE;
    }

    // ── Internals ────────────────────────────────────────────────────
    private final ScheduledExecutorService scheduler =
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "jobnest-notif-candidat");
                t.setDaemon(true);
                return t;
            });

    /** IDs d'entretiens déjà planifiés — évite les doublons au rechargement */
    private final Set<String> planifies = new HashSet<>();

    /** Callback appelé sur le JavaFX thread quand une nouvelle notif arrive */
    private Consumer<NotificationCandidat> onNewNotification;

    public void setOnNewNotification(Consumer<NotificationCandidat> callback) {
        this.onNewNotification = callback;
    }

    private Connection conn() {
        return MyDatabase.getInstance().getCnx();
    }

    // ════════════════════════════════════════════════════════════════
    //  PLANIFICATION DES RAPPELS
    // ════════════════════════════════════════════════════════════════

    /**
     * Pour chaque entretien actif du candidat, planifie :
     *  - Un rappel RAPPEL_24H si dans 22h-26h
     *  - Un rappel RAPPEL_1H  si dans 0-2h
     */
    public void planifierRappels(List<Entretien> entretiens) {
        LocalDateTime maintenant = LocalDateTime.now();

        for (Entretien e : entretiens) {
            if (e.getDateEntretien() == null || e.getHeureDebut() == null) continue;

            LocalDateTime debut = LocalDateTime.of(
                    e.getDateEntretien().toLocalDate(),
                    e.getHeureDebut().toLocalTime());

            long secondesAvant = java.time.Duration.between(maintenant, debut).getSeconds();
            if (secondesAvant <= 0) continue; // déjà passé

            // ── Rappel 24h ──
            String key24h = "24h_" + e.getIdEntretien();
            if (!planifies.contains(key24h)) {
                long delai24h = secondesAvant - (24 * 3600); // nb secondes avant = (debut - 24h - maintenant)
                if (delai24h >= 0 && delai24h <= 2 * 3600) {
                    // Dans la fenêtre 22h-26h avant l'entretien → on planifie pour dans `delai24h` secondes
                    planifierRappel(e, NotificationCandidat.Type.RAPPEL_24H, delai24h);
                    planifies.add(key24h);
                } else if (delai24h < 0 && secondesAvant > 0) {
                    // La fenêtre 24h est dépassée mais l'entretien n'est pas encore passé
                    // → on vérifie si la notif existe déjà en BDD
                    planifies.add(key24h); // marqué pour ne pas replanifier
                }
            }

            // ── Rappel 1h ──
            String key1h = "1h_" + e.getIdEntretien();
            if (!planifies.contains(key1h)) {
                long delai1h = secondesAvant - 3600; // nb secondes avant la fenêtre 1h
                if (delai1h >= 0 && delai1h <= 30 * 60) {
                    // Dans la fenêtre 30min-90min avant l'entretien
                    planifierRappel(e, NotificationCandidat.Type.RAPPEL_1H, delai1h);
                    planifies.add(key1h);
                } else if (delai1h < 0 && secondesAvant > 0) {
                    planifies.add(key1h);
                }
            }
        }
    }

    private void planifierRappel(Entretien e, NotificationCandidat.Type type, long delaiSecondes) {
        scheduler.schedule(() -> {
            try {
                // Récupérer le titre de l'offre
                EntretienCandidatService svc = new EntretienCandidatService();
                String titreOffre = svc.getOffreTitre(e.getIdOffre());
                String dateStr = e.getDateEntretien().toLocalDate()
                        .format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String heureStr = e.getHeureDebut().toLocalTime()
                        .format(DateTimeFormatter.ofPattern("HH:mm"));

                String titre, message;
                if (type == NotificationCandidat.Type.RAPPEL_24H) {
                    titre   = "Rappel — Entretien demain";
                    message = "Votre entretien pour le poste \"" + titreOffre + "\" est prévu demain à "
                            + heureStr + ". Pensez à vous préparer !";
                } else {
                    titre   = "⏰ Rappel — Entretien dans 1h";
                    message = "Votre entretien pour le poste \"" + titreOffre + "\" commence dans 1h à "
                            + heureStr + " (" + ("visio".equals(e.getTypeEntretien())
                            ? "visioconférence" : e.getLieu()) + ").";
                }

                NotificationCandidat notif = new NotificationCandidat(
                        getCurrentCandidatId(), e.getIdEntretien(), titre, message, type);

                // Éviter les doublons en BDD
                if (!existeEnBDD(notif.getIdCandidat(), e.getIdEntretien(), type)) {
                    sauvegarder(notif);
                    Platform.runLater(() -> {
                        if (onNewNotification != null) onNewNotification.accept(notif);
                    });
                }

            } catch (Exception ex) {
                System.err.println("[NotifCandidat] Erreur planification rappel : " + ex.getMessage());
            }
        }, delaiSecondes, TimeUnit.SECONDS);
    }

    // ════════════════════════════════════════════════════════════════
    //  DÉTECTION DES ANNULATIONS
    // ════════════════════════════════════════════════════════════════

    /**
     * Parcourt les entretiens du candidat dont la date est passée et le statut
     * vient de passer à "annulé" → crée une notification d'annulation si absente.
     */
    public void detecterEtNotifierAnnulations(int idCandidat,
                                              EntretienCandidatService svc) {
        try {
            List<Entretien> tous = svc.getEntretiensByCandidat(idCandidat);
            for (Entretien e : tous) {
                if (!"annulé".equals(e.getStatut())) continue;
                if (existeEnBDD(idCandidat, e.getIdEntretien(),
                        NotificationCandidat.Type.ANNULATION)) continue;

                String titreOffre = svc.getOffreTitre(e.getIdOffre());
                String dateStr = e.getDateEntretien() != null
                        ? e.getDateEntretien().toLocalDate()
                        .format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
                        : "date inconnue";

                NotificationCandidat notif = new NotificationCandidat(
                        idCandidat,
                        e.getIdEntretien(),
                        "Entretien annulé",
                        "Votre entretien prévu le " + dateStr + " pour le poste \""
                                + titreOffre + "\" a été annulé.",
                        NotificationCandidat.Type.ANNULATION
                );
                sauvegarder(notif);

                Platform.runLater(() -> {
                    if (onNewNotification != null) onNewNotification.accept(notif);
                });
            }
        } catch (SQLException ex) {
            System.err.println("[NotifCandidat] Erreur détection annulations : " + ex.getMessage());
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  CRUD BDD
    // ════════════════════════════════════════════════════════════════

    /** Sauvegarde une notification en BDD */
    public void sauvegarder(NotificationCandidat notif) throws SQLException {
        String sql = "INSERT INTO notification_candidat " +
                "(id_candidat, id_entretien, titre, message, type, lue) " +
                "VALUES (?, ?, ?, ?, ?, 0)";
        try (PreparedStatement ps = conn().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt   (1, notif.getIdCandidat());
            ps.setInt   (2, notif.getIdEntretien());
            ps.setString(3, notif.getTitre());
            ps.setString(4, notif.getMessage());
            ps.setString(5, notif.getType().name());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) notif.setId(keys.getInt(1));
            }
        }
    }

    /** Récupère toutes les notifications d'un candidat (plus récentes en premier) */
    public List<NotificationCandidat> getAll(int idCandidat) throws SQLException {
        List<NotificationCandidat> list = new ArrayList<>();
        String sql = "SELECT * FROM notification_candidat WHERE id_candidat = ? " +
                "ORDER BY date_creation DESC";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, idCandidat);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    /** Compte les notifications non lues d'un candidat */
    public int countNonLues(int idCandidat) throws SQLException {
        String sql = "SELECT COUNT(*) FROM notification_candidat " +
                "WHERE id_candidat = ? AND lue = 0";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, idCandidat);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return 0;
    }

    /** Marque une notification comme lue */
    public void marquerLue(int id) throws SQLException {
        String sql = "UPDATE notification_candidat SET lue = 1 WHERE id = ?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    /** Marque toutes les notifications d'un candidat comme lues */
    public void marquerToutesLues(int idCandidat) throws SQLException {
        String sql = "UPDATE notification_candidat SET lue = 1 WHERE id_candidat = ?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, idCandidat);
            ps.executeUpdate();
        }
    }

    /** Vérifie si une notification de ce type existe déjà pour cet entretien */
    private boolean existeEnBDD(int idCandidat, int idEntretien,
                                NotificationCandidat.Type type) throws SQLException {
        String sql = "SELECT COUNT(*) FROM notification_candidat " +
                "WHERE id_candidat = ? AND id_entretien = ? AND type = ?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt   (1, idCandidat);
            ps.setInt   (2, idEntretien);
            ps.setString(3, type.name());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        }
        return false;
    }

    // ── Mapper ───────────────────────────────────────────────────────
    private NotificationCandidat mapRow(ResultSet rs) throws SQLException {
        NotificationCandidat n = new NotificationCandidat();
        n.setId          (rs.getInt      ("id"));
        n.setIdCandidat  (rs.getInt      ("id_candidat"));
        n.setIdEntretien (rs.getInt      ("id_entretien"));
        n.setTitre       (rs.getString   ("titre"));
        n.setMessage     (rs.getString   ("message"));
        n.setType        (NotificationCandidat.Type.valueOf(rs.getString("type")));
        n.setLue         (rs.getBoolean  ("lue"));
        Timestamp ts = rs.getTimestamp("date_creation");
        if (ts != null) n.setDateCreation(ts.toLocalDateTime());
        return n;
    }

    /**
     * ID du candidat connecté — à remplacer par la vraie session
     * quand vous aurez un système d'authentification.
     */
    private int getCurrentCandidatId() {
        return 1; // ← même valeur que dans EntretienCandidatController
    }
}