package tn.jobnest.gestioncan.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.stage.FileChooser;

import java.io.File;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ProfileController {

    // --- FORMULAIRE (DROITE) ---
    @FXML private TextField txtNom;
    @FXML private TextField txtPrenom;
    @FXML private TextField txtEmail;
    @FXML private TextField txtTel;
    @FXML private TextField txtAdresse;      // Mapped to 'ville'
    @FXML private DatePicker dpDateNaissance; // Mapped to 'DateN'

    // --- CARTE PROFIL (GAUCHE) ---
    @FXML private Label lblNomComplet;
    @FXML private Label lblRole;
    @FXML private Label lblEmailCard;
    @FXML private Label lblTelCard;
    @FXML private Label lblLocCard;
    @FXML private Circle circleAvatar;

    // --- CONNEXION & SESSION ---
    private final String USER_EMAIL = "ghribimedaziz007@gmail.com"; // Email de test
    private Connection cnx;

    // --- CONFIGURATION ---
    // Format de la date dans ta base (ex: 06/04/2004)
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    @FXML
    public void initialize() {
        connecterBase();
        chargerInfosCandidat();
    }

    private void connecterBase() {
        try {
            // Remplace par tes infos si différent
            String url = "jdbc:mysql://localhost:3306/jobnest";
            String user = "root";
            String pwd = "";
            cnx = DriverManager.getConnection(url, user, pwd);
        } catch (SQLException e) {
            afficherAlerte("Erreur", "Impossible de se connecter à la base.");
            e.printStackTrace();
        }
    }

    // ---------------------------------------------------------
    // 1. CHARGEMENT DES DONNÉES
    // ---------------------------------------------------------
    private void chargerInfosCandidat() {
        if (cnx == null) return;

        // Nom de la table: 'candidat' (si c'est 'users', change-le ici)
        String query = "SELECT * FROM candidat WHERE email = ?";

        try {
            PreparedStatement pst = cnx.prepareStatement(query);
            pst.setString(1, USER_EMAIL);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                // Récupération depuis la BDD
                String nom = rs.getString("nom");
                String prenom = rs.getString("prenom");
                String email = rs.getString("email");
                String telephone = rs.getString("telephone");
                String ville = rs.getString("ville"); // Correspond à txtAdresse
                String titrePro = rs.getString("Titre_pro");
                String imagePath = rs.getString("image");
                String dateStr = rs.getString("DateN"); // Varchar dans la BDD

                // Remplissage Champs
                txtNom.setText(nom);
                txtPrenom.setText(prenom);
                txtEmail.setText(email);
                txtTel.setText(telephone);
                txtAdresse.setText(ville);

                // Conversion Date (String -> LocalDate)
                if (dateStr != null && !dateStr.isEmpty()) {
                    try {
                        dpDateNaissance.setValue(LocalDate.parse(dateStr, dateFormatter));
                    } catch (Exception e) {
                        System.out.println("Format date invalide en BDD : " + dateStr);
                    }
                }

                // Mise à jour de la carte (y compris l'image)
                majCarteProfil(prenom, nom, email, telephone, ville, titrePro, imagePath);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ---------------------------------------------------------
    // 2. GESTION DE L'IMAGE (Bouton Caméra)
    // ---------------------------------------------------------
    @FXML
    void importerImage(ActionEvent event) {
        // Choisir le fichier
        FileChooser fc = new FileChooser();
        fc.setTitle("Choisir votre photo de profil");
        fc.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Images", "*.png", "*.jpg", "*.jpeg")
        );

        File selectedFile = fc.showOpenDialog(null);

        if (selectedFile != null) {
            // 1. Mise à jour visuelle immédiate
            Image img = new Image(selectedFile.toURI().toString());
            circleAvatar.setFill(new ImagePattern(img));

            // 2. Sauvegarde du chemin en Base de Données
            sauvegarderCheminImage(selectedFile.getAbsolutePath());
        }
    }

    private void sauvegarderCheminImage(String chemin) {
        if (cnx == null) return;

        String query = "UPDATE candidat SET image = ? WHERE email = ?";
        try {
            PreparedStatement pst = cnx.prepareStatement(query);
            pst.setString(1, chemin);
            pst.setString(2, USER_EMAIL);
            pst.executeUpdate();
            System.out.println("Image sauvegardée : " + chemin);
        } catch (SQLException e) {
            afficherAlerte("Erreur", "Impossible de sauvegarder la photo.");
            e.printStackTrace();
        }
    }

    // ---------------------------------------------------------
    // 3. SAUVEGARDE DU FORMULAIRE (Bouton Sauvegarder)
    // ---------------------------------------------------------
    @FXML
    void sauvegarder(ActionEvent event) {
        if (cnx == null) return;

        String query = "UPDATE candidat SET nom=?, prenom=?, telephone=?, ville=?, DateN=? WHERE email=?";

        try {
            PreparedStatement pst = cnx.prepareStatement(query);
            pst.setString(1, txtNom.getText());
            pst.setString(2, txtPrenom.getText());
            pst.setString(3, txtTel.getText());
            pst.setString(4, txtAdresse.getText());

            // Conversion Date (LocalDate -> String)
            if (dpDateNaissance.getValue() != null) {
                pst.setString(5, dpDateNaissance.getValue().format(dateFormatter));
            } else {
                pst.setString(5, "");
            }

            pst.setString(6, USER_EMAIL);

            int rows = pst.executeUpdate();
            if (rows > 0) {
                afficherAlerte("Succès", "Informations mises à jour !");
                // Rafraîchir l'affichage à gauche
                majCarteProfil(txtPrenom.getText(), txtNom.getText(), txtEmail.getText(),
                        txtTel.getText(), txtAdresse.getText(), lblRole.getText(), null);
            }

        } catch (SQLException e) {
            afficherAlerte("Erreur SQL", e.getMessage());
        }
    }

    // --- MÉTHODE UTILITAIRE D'AFFICHAGE ---
    private void majCarteProfil(String prenom, String nom, String email, String tel, String ville, String role, String imagePath) {
        if(lblNomComplet != null) lblNomComplet.setText(prenom + " " + nom);
        if(lblRole != null) lblRole.setText(role != null ? role : "");
        if(lblEmailCard != null) lblEmailCard.setText(email);
        if(lblTelCard != null) lblTelCard.setText(tel);
        if(lblLocCard != null) lblLocCard.setText(ville);

        // Chargement Image
        if (imagePath != null && !imagePath.isEmpty() && circleAvatar != null) {
            File file = new File(imagePath);
            if (file.exists()) {
                Image img = new Image(file.toURI().toString());
                circleAvatar.setFill(new ImagePattern(img));
            }
        }
    }

    private void afficherAlerte(String titre, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}