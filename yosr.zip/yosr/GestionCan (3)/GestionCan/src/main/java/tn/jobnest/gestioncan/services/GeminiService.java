package tn.jobnest.gestioncan.services;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;

public class GeminiService {

    // ⚠️ Remplace par ta NOUVELLE clé API (celle que tu as régénérée)
    private static final String API_KEY = "AIzaSyBuCN7Nt5RH0Jga6LJ62DTCgsiegTSG9TQ";

    // On utilise le modèle "gemini-1.5-flash" qui est rapide et gratuit
    String API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + API_KEY;
    public String ameliorerBio(String brouillon) {
        try {
            // 1. Nettoyage du texte pour le JSON (Très important pour éviter l'erreur 400)
            String texteNettoye = escapeJsonString(brouillon);

            // 2. Construction du Prompt
            String prompt = "Tu es un expert en recrutement LinkedIn. "
                    + "Améliore cette bio pour qu'elle soit professionnelle et accrocheuse. "
                    + "RÈGLES STRICTES : "
                    + "1. Donne-moi UNE SEULE version (la meilleure possible). "
                    + "2. Ne mets PAS de titre, PAS d'introduction, PAS d'options (ni 'Option 1', ni 'Option 2'). "
                    + "3. Affiche UNIQUEMENT le texte final réécrit. "
                    + "Voici la bio à refaire : '" + texteNettoye + "'";

            // 3. Construction du JSON (Attention aux accolades)
            String jsonBody = "{\n" +
                    "  \"contents\": [{\n" +
                    "    \"parts\": [{\n" +
                    "      \"text\": \"" + prompt + "\"\n" +
                    "    }]\n" +
                    "  }]\n" +
                    "}";

            // 4. Création du client HTTP
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL))
                    .header("Content-Type", "application/json") // OBLIGATOIRE
                    .POST(HttpRequest.BodyPublishers.ofString(jsonBody, StandardCharsets.UTF_8))
                    .build();

            // 5. Envoi
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                return extraireTexteDuJson(response.body());
            } else {
                // Pour le débogage : on affiche l'erreur dans la console
                System.err.println("Erreur API (" + response.statusCode() + "): " + response.body());
                return "Erreur technique (" + response.statusCode() + "). Vérifiez la console.";
            }

        } catch (Exception e) {
            e.printStackTrace();
            return "Erreur de connexion : " + e.getMessage();
        }
    }

    // --- Méthodes Utilitaires ---

    /**
     * Nettoie le texte pour qu'il soit valide dans un JSON.
     * Gère les guillemets, les backslashes et les retours à la ligne.
     */
    private String escapeJsonString(String input) {
        if (input == null) return "";
        return input.replace("\\", "\\\\")  // Échapper les backslashes
                .replace("\"", "\\\"")  // Échapper les guillemets
                .replace("\n", "\\n")  // Échapper les sauts de ligne
                .replace("\r", "");     // Supprimer les retours chariot
    }

    private String extraireTexteDuJson(String jsonResponse) {
        try {
            // Recherche manuelle dans le JSON pour éviter d'ajouter une librairie lourde
            String marker = "\"text\": \"";
            int startIndex = jsonResponse.indexOf(marker);

            if (startIndex != -1) {
                startIndex += marker.length();
                // On cherche la fin de la chaîne, en faisant attention aux guillemets échappés
                int i = startIndex;
                while (i < jsonResponse.length()) {
                    if (jsonResponse.charAt(i) == '"' && jsonResponse.charAt(i - 1) != '\\') {
                        break;
                    }
                    i++;
                }

                String result = jsonResponse.substring(startIndex, i);
                // On nettoie le résultat pour l'affichage (enlève les \n et \")
                return result.replace("\\n", "\n").replace("\\\"", "\"");
            }
        } catch (Exception e) {
            System.err.println("Erreur parsing: " + e.getMessage());
        }
        return jsonResponse; // Retourne le JSON brut si on n'arrive pas à extraire
    }
}