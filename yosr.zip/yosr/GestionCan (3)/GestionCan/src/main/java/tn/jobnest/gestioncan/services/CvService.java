package tn.jobnest.gestioncan.services;

import tn.jobnest.gestioncan.models.CVData;
import tn.jobnest.gestioncan.models.Competence;
import tn.jobnest.gestioncan.models.Experience;
import tn.jobnest.gestioncan.models.Formation;
import tn.jobnest.gestioncan.utils.MyDatabase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CvService {

    private Connection cnx = MyDatabase.getInstance().getCnx();

    // Instanciation de tes services
    private ExperienceService experienceService = new ExperienceService();
    // private FormationService formationService = new FormationService(); // Décommente quand tu auras fait pareil pour Formation

    public CVData recupererDonneesCV(int idCandidat) {
        CVData cv = new CVData();

        // 1. Récupérer les infos personnelles (Table User / Candidat)
        // VERIFIE ICI LE NOM DE TA TABLE (ex: 'utilisateur', 'users', 'candidat')
        String reqUser = "SELECT nom, prenom, email, num_tel, adresse, titre_profil FROM utilisateur WHERE id = ?";

        try {
            PreparedStatement ps = cnx.prepareStatement(reqUser);
            ps.setInt(1, idCandidat);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String nomComplet = rs.getString("nom") + " " + rs.getString("prenom");
                cv.setNomComplet(nomComplet);
                cv.setEmail(rs.getString("email"));
                cv.setTelephone(rs.getString("num_tel"));
                cv.setAdresse(rs.getString("adresse"));
                cv.setTitreProfil(rs.getString("titre_profil"));
            }
        } catch (SQLException e) {
            System.err.println("Erreur récupération User : " + e.getMessage());
        }

        // 2. Récupérer les expériences avec ta méthode 'getByCandidat'
        try {
            List<Experience> mesExperiences = experienceService.getByCandidat(idCandidat);
            cv.setExperiences(mesExperiences);

            // FAIS PAREIL POUR FORMATION :
            // List<Formation> mesFormations = formationService.getByCandidat(idCandidat);
            // cv.setFormations(mesFormations);

            // Pour l'instant, on met des listes vides pour éviter les erreurs null
            cv.setFormations(new ArrayList<>());
            cv.setCompetences(new ArrayList<>());
            cv.setLangues(new ArrayList<>());

        } catch (Exception e) {
            System.err.println("Erreur lors de la récupération des listes : " + e.getMessage());
        }

        return cv;
    }
}