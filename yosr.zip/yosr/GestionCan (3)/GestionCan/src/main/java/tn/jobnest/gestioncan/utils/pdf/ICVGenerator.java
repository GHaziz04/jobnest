package tn.jobnest.gestioncan.utils.pdf;

import tn.jobnest.gestioncan.models.*;
import java.util.List;

public interface ICVGenerator {
    void generer(String dest, Candidat candidat,
                 List<Experience> experiences,
                 List<Formation> formations,
                 List<Competence> competences,
                 List<Langue> langues) throws Exception;
}