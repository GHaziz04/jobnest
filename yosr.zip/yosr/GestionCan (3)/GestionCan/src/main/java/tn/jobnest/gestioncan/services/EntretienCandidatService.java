package tn.jobnest.gestioncan.services;

import tn.jobnest.gestioncan.models.Entretien;
import tn.jobnest.gestioncan.models.Feedback;
import tn.jobnest.gestioncan.utils.MyDatabase;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service de gestion des entretiens du côté candidat
 */
public class EntretienCandidatService {
    private Connection cnx = MyDatabase.getInstance().getCnx();

    // ═══════════════════════════════════════════════════════════════════════
    // MÉTHODES DE RÉCUPÉRATION DES ENTRETIENS
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Récupère tous les entretiens d'un candidat spécifique
     */
    public List<Entretien> getEntretiensByCandidat(int idCandidat) throws SQLException {
        List<Entretien> entretiens = new ArrayList<>();

        String sql = "SELECT e.* FROM entretien e " +
                "INNER JOIN participant_entretien p ON e.id_entretien = p.id_entretien " +
                "WHERE p.id_candidat = ? " +
                "ORDER BY e.date_entretien DESC, e.heure_debut DESC";

        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, idCandidat);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    entretiens.add(mapResultSetToEntretien(rs));
                }
            }
        }
        return entretiens;
    }

    /**
     * Récupère UNIQUEMENT les entretiens ACTIFS (proposés ET date future/aujourd'hui)
     */
    public List<Entretien> getEntretiensActifs(int idCandidat) throws SQLException {
        List<Entretien> tousLesEntretiens = getEntretiensByCandidat(idCandidat);
        LocalDate aujourdhui = LocalDate.now();

        return tousLesEntretiens.stream()
                .filter(e -> "proposé".equals(e.getStatut()))
                .filter(e -> e.getDateEntretien() != null)
                .filter(e -> !e.getDateEntretien().toLocalDate().isBefore(aujourdhui))
                .collect(Collectors.toList());
    }

    /**
     * Récupère l'HISTORIQUE (réalisés, annulés, proposés expirés)
     */
    public List<Entretien> getHistoriqueEntretiens(int idCandidat) throws SQLException {
        List<Entretien> tousLesEntretiens = getEntretiensByCandidat(idCandidat);
        LocalDate aujourdhui = LocalDate.now();

        return tousLesEntretiens.stream()
                .filter(e -> {
                    // Entretiens réalisés ou annulés
                    if ("réalisé".equals(e.getStatut()) || "annulé".equals(e.getStatut())) {
                        return true;
                    }
                    // Entretiens proposés mais date passée
                    if ("proposé".equals(e.getStatut()) && e.getDateEntretien() != null) {
                        return e.getDateEntretien().toLocalDate().isBefore(aujourdhui);
                    }
                    return false;
                })
                .collect(Collectors.toList());
    }

    // ═══════════════════════════════════════════════════════════════════════
    // MÉTHODES DE RÉCUPÉRATION DES INFORMATIONS ASSOCIÉES
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Récupère le titre de l'offre d'emploi
     */
    public String getOffreTitre(int idOffre) throws SQLException {
        String sql = "SELECT titre FROM offre_emploi WHERE id_offre = ?";
        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, idOffre);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String titre = rs.getString("titre");
                    return titre != null && !titre.isEmpty() ? titre : "Offre #" + idOffre;
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur récupération offre #" + idOffre + ": " + e.getMessage());
            throw e;
        }
        return "Offre #" + idOffre + " (introuvable)";
    }

    /**
     * Récupère le nom du recruteur
     */
    public String getRecruteurNom(int idRecruteur) throws SQLException {
        String sql = "SELECT nom_recruteur, prenom_recruteur FROM recruteur WHERE id_user = ?";
        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, idRecruteur);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String nom = rs.getString("nom_recruteur");
                    String prenom = rs.getString("prenom_recruteur");

                    StringBuilder sb = new StringBuilder();
                    if (prenom != null && !prenom.isBlank()) sb.append(prenom).append(" ");
                    if (nom != null && !nom.isBlank()) sb.append(nom);

                    String result = sb.toString().trim();
                    return !result.isEmpty() ? result : "Recruteur #" + idRecruteur;
                }
            }
        }
        return "Recruteur #" + idRecruteur + " (introuvable)";
    }

    /**
     * Récupère les détails complets de l'offre
     */
    public String getOffreDetails(int idOffre) throws SQLException {
        String sql = "SELECT titre, entreprise, type_contrat FROM offre_emploi WHERE id_offre = ?";
        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, idOffre);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String titre = rs.getString("titre");
                    String entreprise = rs.getString("entreprise");
                    String typeContrat = rs.getString("type_contrat");

                    StringBuilder result = new StringBuilder();

                    if (titre != null && !titre.isEmpty()) {
                        result.append(titre);
                    }

                    if (entreprise != null && !entreprise.isEmpty()) {
                        if (result.length() > 0) result.append(" - ");
                        result.append(entreprise);
                    }

                    if (typeContrat != null && !typeContrat.isEmpty()) {
                        if (result.length() > 0) result.append(" (");
                        result.append(typeContrat);
                        if (result.length() > 0) result.append(")");
                    }

                    return result.length() > 0 ? result.toString() : "Offre #" + idOffre;
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur détails offre #" + idOffre + ": " + e.getMessage());
            throw e;
        }
        return "Offre #" + idOffre + " (informations indisponibles)";
    }

    // ═══════════════════════════════════════════════════════════════════════
    // MÉTHODES DE MODIFICATION DES ENTRETIENS
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Met à jour le statut d'un entretien
     */
    public void mettreAJourStatut(int idEntretien, String nouveauStatut) throws SQLException {
        String sql = "UPDATE entretien SET statut = ? WHERE id_entretien = ?";

        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setString(1, nouveauStatut);
            ps.setInt(2, idEntretien);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("✅ Statut entretien #" + idEntretien + " mis à jour: " + nouveauStatut);
            } else {
                System.err.println("❌ Aucune mise à jour pour l'entretien #" + idEntretien);
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur mise à jour statut entretien #" + idEntretien + ": " + e.getMessage());
            throw e;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // ✅ NOUVELLES MÉTHODES - GESTION DES FEEDBACKS
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * ✅ Récupère le feedback pour un entretien donné
     */
    public Feedback getFeedbackByEntretien(int idEntretien) throws SQLException {
        String sql = "SELECT * FROM feedback WHERE id_entretien = ?";

        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, idEntretien);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToFeedback(rs);
                }
            }
        }
        return null;
    }

    /**
     * ✅ Vérifie si un feedback existe pour un entretien
     */
    public boolean feedbackExists(int idEntretien) throws SQLException {
        String sql = "SELECT COUNT(*) FROM feedback WHERE id_entretien = ?";

        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, idEntretien);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    /**
     * ✅ Récupère tous les feedbacks reçus par un candidat
     */
    public List<Feedback> getFeedbacksByCandidat(int idCandidat) throws SQLException {
        List<Feedback> feedbacks = new ArrayList<>();
        String sql = "SELECT f.* FROM feedback f " +
                "INNER JOIN entretien e ON f.id_entretien = e.id_entretien " +
                "INNER JOIN participant_entretien pe ON e.id_entretien = pe.id_entretien " +
                "WHERE pe.id_candidat = ? " +
                "ORDER BY f.date_feedback DESC";

        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, idCandidat);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    feedbacks.add(mapResultSetToFeedback(rs));
                }
            }
        }
        return feedbacks;
    }

    /**
     * ✅ Compte le nombre de feedbacks reçus par un candidat
     */
    public int countFeedbacksByCandidat(int idCandidat) throws SQLException {
        String sql = "SELECT COUNT(*) FROM feedback f " +
                "INNER JOIN entretien e ON f.id_entretien = e.id_entretien " +
                "INNER JOIN participant_entretien pe ON e.id_entretien = pe.id_entretien " +
                "WHERE pe.id_candidat = ?";

        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, idCandidat);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        return 0;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // MÉTHODES DE MAPPING (ResultSet vers Objets)
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Mapper ResultSet vers objet Entretien
     */
    private Entretien mapResultSetToEntretien(ResultSet rs) throws SQLException {
        Entretien e = new Entretien();
        e.setIdEntretien(rs.getInt("id_entretien"));
        e.setDateEntretien(rs.getDate("date_entretien"));
        e.setHeureDebut(rs.getTime("heure_debut"));
        e.setHeureFin(rs.getTime("heure_fin"));
        e.setTypeEntretien(rs.getString("type_entretien"));
        e.setLieu(rs.getString("lieu"));
        e.setLienVisio(rs.getString("lien_visio"));
        e.setStatut(rs.getString("statut"));
        e.setNoteRecruteur(rs.getString("note_recruteur"));
        e.setDateCreation(rs.getTimestamp("date_creation"));
        e.setIdRecruteur(rs.getInt("id_recruteur"));
        e.setIdOffre(rs.getInt("id_offre"));
        return e;
    }

    /**
     * ✅ Mapper ResultSet vers objet Feedback
     */
    private Feedback mapResultSetToFeedback(ResultSet rs) throws SQLException {
        Feedback f = new Feedback();
        f.setIdFeedback(rs.getInt("id_feedback"));
        f.setIdEntretien(rs.getInt("id_entretien"));
        f.setCompetenceTechniques(rs.getInt("competence_techniques"));
        f.setCompetenceCommunication(rs.getInt("competence_communication"));
        f.setMotivation(rs.getInt("motivation"));
        f.setAdequationAuPoste(rs.getInt("adequation_au_poste"));
        f.setCommentaire(rs.getString("commentaire"));
        f.setCompetenceManquantes(rs.getString("competence_manquantes"));
        f.setSuggestionFormation(rs.getBoolean("suggestion_formation"));
        f.setDateFeedback(rs.getTimestamp("date_feedback"));
        return f;
    }
}