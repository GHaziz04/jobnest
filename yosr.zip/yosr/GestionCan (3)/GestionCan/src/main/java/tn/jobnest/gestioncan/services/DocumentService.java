package tn.jobnest.gestioncan.services;

import tn.jobnest.gestioncan.models.DocumentCandidature;
import tn.jobnest.gestioncan.utils.MyDatabase;
import java.sql.*;

public class DocumentService {

    private Connection cnx = MyDatabase.getInstance().getCnx();

    // 1. Ajouter un document (UPLOAD)
    public void ajouter(DocumentCandidature doc) {
        String req = "INSERT INTO document_candidature (id_candidature, nom_document, type_document, chemin_fichier) VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, doc.getIdCandidature());
            ps.setString(2, doc.getNomDocument());
            ps.setString(3, doc.getTypeDocument());
            ps.setString(4, doc.getCheminFichier());

            ps.executeUpdate();
            System.out.println("Document ajouté avec succès !");
        } catch (SQLException e) {
            System.err.println("Erreur ajout document : " + e.getMessage());
        }
    }

    // 2. Récupérer le document d'une candidature
    public DocumentCandidature getByCandidature(int idCandidature) {
        String req = "SELECT * FROM document_candidature WHERE id_candidature = ?";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, idCandidature);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new DocumentCandidature(
                        rs.getInt("id_document"), // ID généré par la BDD
                        rs.getInt("id_candidature"),
                        rs.getString("nom_document"),
                        rs.getString("type_document"),
                        rs.getString("chemin_fichier")
                );
            }
        } catch (SQLException e) {
            System.err.println("Erreur récupération document : " + e.getMessage());
        }
        return null; // Retourne null si aucun document trouvé
    }

    // 3. Mettre à jour un document (Si on change de fichier)
    public void modifier(DocumentCandidature doc) {
        String req = "UPDATE document_candidature SET nom_document=?, chemin_fichier=? WHERE id_document=?";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setString(1, doc.getNomDocument());
            ps.setString(2, doc.getCheminFichier());
            ps.setInt(3, doc.getIdDocument());

            ps.executeUpdate();
            System.out.println("Document mis à jour !");
        } catch (SQLException e) {
            System.err.println("Erreur modif document : " + e.getMessage());
        }
    }

    // 4. Supprimer un document
    public void supprimer(int idDocument) {
        String req = "DELETE FROM document_candidature WHERE id_document=?";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, idDocument);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Erreur suppression document : " + e.getMessage());
        }
    }
}