package tn.jobnest.gestioncan.controllers;

import tn.jobnest.gestioncan.models.Candidature;
import tn.jobnest.gestioncan.services.CandidatureService;
import tn.jobnest.gestioncan.services.ICrud; // On importe l'interface
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class CandidatureController {

    // --- FXML Fields ---
    @FXML private TextField txtNom;
    @FXML private TextArea txtExperiences;
    // ... tes autres champs ...

    // --- APPEL DU SERVICE ---
    // On utilise l'Interface pour déclarer, et le Service pour instancier (Polymorphisme)
    private final ICrud<Candidature> candidatureService = new CandidatureService();

    @FXML
    private void handleGeneratePDF() {
        // 1. Validations
        if (txtNom.getText().isEmpty() || txtExperiences.getText().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Attention", "Champs obligatoires manquants.");
            return;
        }

        try {
            // 2. Préparation des données
            int idOffre = 10; // Exemple
            int idCandidat = 1; // Exemple
            String message = "Candidature de " + txtNom.getText();

            // 3. Création de l'objet Modèle
            Candidature candidature = new Candidature(idCandidat, idOffre, message);

            // 4. Appel du Service pour ajouter en BDD
            candidatureService.ajouter(candidature);

            // 5. Feedback
            showAlert(Alert.AlertType.INFORMATION, "Succès", "Candidature envoyée !");

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Problème technique : " + e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}