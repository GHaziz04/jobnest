package tn.jobnest.gestioncan.services;

import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;
import tn.jobnest.gestioncan.utils.MyDatabase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PaymentService {

    // ⚠️ Remplacez par votre Clé Secrète (commence par sk_test_...)
    private final String API_KEY = "sk_test_51SzKfIPxUy7wR8JF57hsGf56GR8q48gGpzo57HJuWOvsFtw0Zt8DzI1TIBYUmAzcFoaNwmEoGR5WgtGM33QldI2d00rnkVnWSF";

    public PaymentService() {
        Stripe.apiKey = API_KEY;
    }


    public boolean verifierSoldeSuffisant(int userId, double prixFormation) {
        String req = "SELECT solde FROM candidat WHERE id_user = ?";
        try {
            Connection cnx = MyDatabase.getInstance().getCnx();
            try (PreparedStatement ps = cnx.prepareStatement(req)) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        double soldeActuel = rs.getDouble("solde");
                        return soldeActuel >= prixFormation;
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur lors de la vérification du solde : " + e.getMessage());
        }
        return false;
    }

    /**
     * 1. Crée une session de paiement Stripe et retourne l'URL de paiement
     */
    public String creerSessionPaiement(long montantEnCentimes, String emailClient) throws StripeException {
        SessionCreateParams params = SessionCreateParams.builder()
                .setMode(SessionCreateParams.Mode.PAYMENT)
                .setSuccessUrl("https://jobnest.tn/success") // URL fictive, on s'en fiche pour le desktop
                .setCancelUrl("https://jobnest.tn/cancel")
                .setCustomerEmail(emailClient)
                .addLineItem(
                        SessionCreateParams.LineItem.builder()
                                .setQuantity(1L)
                                .setPriceData(
                                        SessionCreateParams.LineItem.PriceData.builder()
                                                .setCurrency("usd") // ou "eur"
                                                .setUnitAmount(montantEnCentimes) // 1000 = 10.00$
                                                .setProductData(
                                                        SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                                                .setName("Recharge Solde JobNest")
                                                                .build())
                                                .build())
                                .build())
                .build();

        Session session = Session.create(params);
        return session.getUrl() + "###" + session.getId(); // On retourne l'URL et l'ID pour vérifier après
    }

    /**
     * 2. Vérifie si le paiement a été validé chez Stripe
     */
    public boolean verifierPaiement(String sessionId) {
        try {
            Session session = Session.retrieve(sessionId);
            return "paid".equals(session.getPaymentStatus());
        } catch (StripeException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 3. Met à jour le solde dans la base de données
     */
    public void ajouterSolde(int userId, double montant) {
        // TODO: Utilisez votre connexion JDBC ici (MyConnection.getInstance()...)
        String req = "UPDATE candidat SET solde = solde + ? WHERE id_user = ?";
        try (Connection cnx = tn.jobnest.gestioncan.utils.MyDatabase.getInstance().getCnx();
             PreparedStatement ps = cnx.prepareStatement(req)) {

            ps.setDouble(1, montant);
            ps.setInt(2, userId);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void appliquerBoost(int userId, int packType) {
        int joursAAjouter = 0;

        switch (packType) {
            case 1: // 50 DT - 3 mois
                joursAAjouter = 90;
                break;
            case 2: // 30 DT - 1,5 mois (env. 45 jours)
                joursAAjouter = 45;
                break;
            case 3: // 20 DT - 4 semaines
                joursAAjouter = 28;
                break;
        }

        String sql = "UPDATE candidat SET boost_expiration = DATE_ADD(NOW(), INTERVAL ? DAY) WHERE id_user = ?";

        try (Connection cnx = MyDatabase.getInstance().getCnx();
             PreparedStatement pst = cnx.prepareStatement(sql)) {
            pst.setInt(1, joursAAjouter);
            pst.setInt(2, userId);
            pst.executeUpdate();
            System.out.println("🚀 Boost activé pour " + joursAAjouter + " jours !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}