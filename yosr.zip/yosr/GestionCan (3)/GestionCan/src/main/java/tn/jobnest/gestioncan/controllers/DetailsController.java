package tn.jobnest.gestioncan.controllers; // ✅ Package respecté

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import tn.jobnest.gestioncan.models.Formations; // ✅ Import du modèle avec S

public class DetailsController {

    @FXML private Label labTitre, labObjectifs, labDates, labLieu, labStatut;
    @FXML private Label labDescription, labPrix, labFormateur, labPlaces, labDuree, labNiveau;

    /**
     * ✅ Correction du type : Utilise l'objet Formations (avec S)
     */
    public void setFormation(Formations f) {
        if (f == null) return;

        // Informations principales
        if (labTitre != null) labTitre.setText(nonVide(f.getTitre()));
        if (labDescription != null) labDescription.setText(nonVide(f.getDescription()));
        if (labObjectifs != null) labObjectifs.setText(nonVide(f.getObjectifs()));

        // Métadonnées
        if (labFormateur != null) labFormateur.setText(nonVide(f.getNomFormateur()));
        if (labPrix != null) labPrix.setText(String.format("%.2f DT", f.getPrix()));
        if (labDuree != null) labDuree.setText(f.getDuree_heures() + " Heures");
        if (labNiveau != null) labNiveau.setText("Niveau " + nonVide(f.getNiveau()));

        if (labPlaces != null) {
            labPlaces.setText(f.getNb_places_occupees() + " / " + f.getNb_places() + " inscrits");
        }

        // Planning et Lieu
        if (labDates != null) {
            labDates.setText("Du " + f.getDate_debut() + " au " + f.getDate_fin());
        }
        if (labLieu != null) {
            labLieu.setText("📍 " + nonVide(f.getLieu()));
        }

        // Style dynamique du Statut
        configurerStatut(f.getStatut());
    }

    private void configurerStatut(String statut) {
        if (labStatut == null) return;

        // --- SÉCURITÉ : GESTION DU NULL ---
        if (statut == null || statut.trim().isEmpty()) {
            statut = "OUVERT"; // Valeur par défaut
        }

        labStatut.setText(statut.toUpperCase());

        // --- COULEURS ---
        String backgroundColor;
        String textColor = "white";

        switch (statut.toLowerCase()) {
            case "terminé":
            case "terminée":
                backgroundColor = "#E53E3E"; // Rouge
                break;
            case "ouvert":
                backgroundColor = "#38A169"; // Vert
                break;
            case "programmée":
            case "en cours":
                backgroundColor = "#3182CE"; // Bleu
                break;
            case "complet":
                backgroundColor = "#DD6B20"; // Orange
                break;
            default:
                backgroundColor = "#718096"; // Gris
                break;
        }

        // Application du style visuel
        labStatut.setStyle("-fx-background-color: " + backgroundColor + "; " +
                "-fx-text-fill: " + textColor + "; " +
                "-fx-padding: 5 12; " +
                "-fx-background-radius: 15; " +
                "-fx-font-size: 11; " +
                "-fx-font-weight: bold;");
    }

    private String nonVide(String str) {
        return (str == null || str.trim().isEmpty()) ? "Information non disponible" : str;
    }

    @FXML
    private void fermer(ActionEvent event) {
        // Ferme la fenêtre actuelle
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }
}