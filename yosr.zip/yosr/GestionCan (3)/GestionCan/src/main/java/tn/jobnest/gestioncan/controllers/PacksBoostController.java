package tn.jobnest.gestioncan.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.Alert;
import tn.jobnest.gestioncan.utils.MyDatabase;
import tn.jobnest.gestioncan.utils.NavigationService;
import java.sql.*;

public class PacksBoostController {

    @FXML private Label lblMonSoldeBoosts;
    @FXML private Label lblSoldeTND;

    private final int ID_CANDIDAT_FIXE = 1;

    @FXML
    public void initialize() {
        rafraichirAffichage();
    }

    private void rafraichirAffichage() {
        Connection cnx = MyDatabase.getInstance().getCnx();
        String sql = "SELECT solde, nb_boosts_restants FROM candidat WHERE id_user = ?";

        try (PreparedStatement pst = cnx.prepareStatement(sql)) {
            pst.setInt(1, ID_CANDIDAT_FIXE);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                double soldeArgent = rs.getDouble("solde"); // Récupère le 45 de ta DB
                int soldeBoosts = rs.getInt("nb_boosts_restants");

                // Mise à jour des labels JavaFX
                if (lblSoldeTND != null) {
                    lblSoldeTND.setText(String.format("%.2f TND", soldeArgent));
                }
                if (lblMonSoldeBoosts != null) {
                    lblMonSoldeBoosts.setText(soldeBoosts + " Boosts");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void traiterAchat(double prix, int quantiteBoost) {
        // Ici vous pouvez réintégrer votre code Stripe si nécessaire
        boolean paiementReussi = true;

        if (paiementReussi) {
            Connection cnx = MyDatabase.getInstance().getCnx();
            // On retire le prix du solde et on ajoute les boosts
            // Condition : AND solde >= ? pour éviter les comptes négatifs
            String sqlUpdate = "UPDATE candidat SET solde = solde - ?, nb_boosts_restants = nb_boosts_restants + ? WHERE id_user = ? AND solde >= ?";

            try (PreparedStatement pst = cnx.prepareStatement(sqlUpdate)) {
                pst.setDouble(1, prix);
                pst.setInt(2, quantiteBoost);
                pst.setInt(3, ID_CANDIDAT_FIXE);
                pst.setDouble(4, prix);

                int rowsUpdated = pst.executeUpdate();
                if (rowsUpdated > 0) {
                    afficherAlerte("Succès", "Félicitations ! Votre pack a été activé.");
                    rafraichirAffichage();
                } else {
                    afficherAlerte("Erreur", "Solde insuffisant dans votre portefeuille pour cet achat.");
                }
            } catch (SQLException e) {
                System.err.println("❌ Erreur SQL durant l'achat : " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    @FXML private void acheterPackBronze() { traiterAchat(5.0, 1); }
    @FXML private void acheterPackSilver() { traiterAchat(10.0, 3); }
    @FXML private void acheterPackGold() { traiterAchat(25.0, 5); } // Corrigé à 5 selon votre FXML

    private void afficherAlerte(String titre, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void retourVersCandidatures() {
        NavigationService.charger("/View/DashboardCandidat.fxml");
    }
}