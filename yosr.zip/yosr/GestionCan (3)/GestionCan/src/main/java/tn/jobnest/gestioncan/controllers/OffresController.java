package tn.jobnest.gestioncan.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import tn.jobnest.gestioncan.models.Offre;
import tn.jobnest.gestioncan.services.OffreService;

import java.io.IOException;
import java.net.URL;
import java.util.*;

public class OffresController implements Initializable {

    @FXML private GridPane gridOffres;
    @FXML private ToggleButton btnFiltreFavoris;

    private OffreService offreService = new OffreService();
    private List<Offre> toutesLesOffres;

    // Liste (sans doublons) pour stocker les offres en favoris
    private Set<Offre> offresFavorites = new HashSet<>();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // 1. Récupération des offres depuis ton service
        toutesLesOffres = offreService.afficherToutesLesOffres(); // Assure-toi que cette méthode existe dans ton service

        // 2. Affichage initial de toutes les offres
        afficherGrilleOffres(toutesLesOffres);
    }

    @FXML
    private void basculerFiltreFavoris() {
        if (btnFiltreFavoris.isSelected()) {
            // Style quand le filtre est ACTIVÉ (Fond jaune clair)
            btnFiltreFavoris.setStyle("-fx-background-color: #FFFBEB; -fx-text-fill: #B45309; -fx-border-color: #F59E0B; -fx-border-radius: 8; -fx-background-radius: 8; -fx-padding: 10 20; -fx-cursor: hand; -fx-font-weight: bold; -fx-font-size: 14px;");

            // On convertit le Set en List pour l'afficher
            List<Offre> listeFavoris = new ArrayList<>(offresFavorites);
            afficherGrilleOffres(listeFavoris);
        } else {
            // Style quand le filtre est DÉSACTIVÉ (Fond blanc)
            btnFiltreFavoris.setStyle("-fx-background-color: white; -fx-text-fill: #F59E0B; -fx-border-color: #F59E0B; -fx-border-radius: 8; -fx-background-radius: 8; -fx-padding: 10 20; -fx-cursor: hand; -fx-font-weight: bold; -fx-font-size: 14px;");

            // On réaffiche tout
            afficherGrilleOffres(toutesLesOffres);
        }
    }

    private void afficherGrilleOffres(List<Offre> offresAAfficher) {
        gridOffres.getChildren().clear(); // On nettoie la grille

        int colonne = 0;
        int ligne = 0;

        for (Offre offre : offresAAfficher) {
            // Création de la carte visuelle pour l'offre
            VBox carte = creerCarteOffre(offre);

            // Ajout à la grille (sur 3 colonnes)
            gridOffres.add(carte, colonne, ligne);

            colonne++;
            if (colonne == 3) {
                colonne = 0;
                ligne++;
            }
        }
    }

    // --- MÉTHODE POUR CRÉER LE DESIGN D'UNE CARTE D'OFFRE ---
    private VBox creerCarteOffre(Offre offre) {
        VBox carte = new VBox(15);
        carte.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-background-radius: 12; -fx-border-radius: 12; -fx-border-color: #E2E8F0; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.03), 10, 0, 0, 4);");

        // 1. En-tête : Type de contrat + Bouton Étoile (Favoris)
        HBox header = new HBox();
        header.setAlignment(Pos.CENTER_LEFT);

        Label lblType = new Label(offre.getTypeContrat() != null ? offre.getTypeContrat() : "CDI");
        lblType.setStyle("-fx-background-color: #EEF2FF; -fx-text-fill: #4338CA; -fx-padding: 5 10; -fx-background-radius: 6; -fx-font-size: 12px; -fx-font-weight: bold;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Bouton Étoile ⭐
        Button btnEtoile = new Button();
        boolean estFavori = offresFavorites.contains(offre);
        btnEtoile.setText(estFavori ? "★" : "☆");
        btnEtoile.setStyle("-fx-background-color: transparent; -fx-text-fill: #F59E0B; -fx-font-size: 20px; -fx-cursor: hand; -fx-padding: 0;");

        btnEtoile.setOnAction(event -> {
            if (offresFavorites.contains(offre)) {
                offresFavorites.remove(offre);
                btnEtoile.setText("☆");
            } else {
                offresFavorites.add(offre);
                btnEtoile.setText("★");
            }

            // Si on est dans l'onglet "Favoris" et qu'on décoche, on rafraîchit immédiatement
            if (btnFiltreFavoris.isSelected()) {
                basculerFiltreFavoris();
            }
        });

        header.getChildren().addAll(lblType, spacer, btnEtoile);

        // 2. Infos principales : Titre + Entreprise
        VBox infos = new VBox(5);
        Label lblTitre = new Label(offre.getTitre());
        lblTitre.setStyle("-fx-font-size: 18px; -fx-font-weight: 800; -fx-text-fill: #0F172A;");
        lblTitre.setWrapText(true);

        Label lblEntreprise = new Label("🏢 " + offre.getEntreprise());
        lblEntreprise.setStyle("-fx-text-fill: #64748B; -fx-font-size: 14px;");

        infos.getChildren().addAll(lblTitre, lblEntreprise);

        // 3. Bouton "Voir détails"
        Button btnDetails = new Button("Voir détails");
        btnDetails.setMaxWidth(Double.MAX_VALUE);
        btnDetails.setStyle("-fx-background-color: white; -fx-border-color: #E2E8F0; -fx-border-radius: 6; -fx-text-fill: #4338CA; -fx-font-weight: bold; -fx-padding: 8; -fx-cursor: hand;");

        btnDetails.setOnAction(event -> ouvrirDetailsOffre(offre));

        // Assemblage de la carte
        carte.getChildren().addAll(header, infos, btnDetails);
        return carte;
    }

    // --- MÉTHODE POUR OUVRIR LA POPUP DES DÉTAILS ---
    private void ouvrirDetailsOffre(Offre offre) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/OffreDetailsModal.fxml")); // Vérifie bien ce chemin !
            Parent root = loader.load();

            OffreDetailsController controller = loader.getController();
            controller.setOffreDetails(offre);

            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Détails de l'offre");
            stage.setScene(new Scene(root));
            stage.showAndWait();

        } catch (IOException e) {
            System.err.println("Erreur lors de l'ouverture des détails : " + e.getMessage());
            e.printStackTrace();
        }
    }
}