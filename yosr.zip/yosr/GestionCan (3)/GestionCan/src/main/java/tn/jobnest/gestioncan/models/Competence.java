package tn.jobnest.gestioncan.models;

public class Competence {
    private int id;
    private int idCandidat;
    private String nom;

    // Constructeur complet
    public Competence(int id, int idCandidat, String nom) {
        this.id = id;
        this.idCandidat = idCandidat;
        this.nom = nom;
    }

    // Constructeur sans ID
    public Competence(int idCandidat, String nom) {
        this.idCandidat = idCandidat;
        this.nom = nom;
    }

    public int getId() { return id; }
    public int getIdCandidat() { return idCandidat; }
    public String getNom() { return nom; }

    // IMPORTANT pour la ListView
    @Override
    public String toString() {
        return nom;
    }
}
