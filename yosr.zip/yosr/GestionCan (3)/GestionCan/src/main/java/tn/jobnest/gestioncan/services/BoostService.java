package tn.jobnest.gestioncan.services;

import tn.jobnest.gestioncan.utils.MyDatabase;
import java.sql.*;

public class BoostService {

    /**
     * AJOUT : Méthode pour créditer des boosts (jetons) au candidat
     * Utilisée lors de l'achat d'un pack (Bronze, Silver, Gold)
     */
    public void acheterPack(int idCandidat, int nbBoostsAchetes) {
        // On utilise la syntaxe nb = nb + ? pour cumuler les boosts
        String sql = "UPDATE candidat SET nb_boosts_restants = nb_boosts_restants + ? WHERE id_user = ?";

        try (Connection cnx = MyDatabase.getInstance().getCnx();
             PreparedStatement pst = cnx.prepareStatement(sql)) {

            pst.setInt(1, nbBoostsAchetes);
            pst.setInt(2, idCandidat);
            pst.executeUpdate();

            System.out.println("✅ Pack de " + nbBoostsAchetes + " boosts ajouté au candidat " + idCandidat);

        } catch (SQLException e) {
            System.err.println("❌ Erreur lors de l'ajout du pack : " + e.getMessage());
        }
    }

    /**
     * Méthode pour consommer 1 boost sur une candidature précise
     */
    public String appliquerBoost(int idCandidat, int idCandidature) {
        Connection cnx = MyDatabase.getInstance().getCnx();
        try {
            cnx.setAutoCommit(false); // Début transaction sécurisée

            // 1. Vérifier si le candidat possède encore des jetons
            String checkSql = "SELECT nb_boosts_restants FROM candidat WHERE id_user = ?";
            PreparedStatement pst1 = cnx.prepareStatement(checkSql);
            pst1.setInt(1, idCandidat);
            ResultSet rs = pst1.executeQuery();

            if (rs.next() && rs.getInt("nb_boosts_restants") > 0) {
                // 2. Soustraire 1 jeton du compte
                String decrSql = "UPDATE candidat SET nb_boosts_restants = nb_boosts_restants - 1 WHERE id_user = ?";
                PreparedStatement pst2 = cnx.prepareStatement(decrSql);
                pst2.setInt(1, idCandidat);
                pst2.executeUpdate();

                // 3. Marquer la candidature comme étant boostée
                String boostSql = "UPDATE candidature SET is_boosted = 1 WHERE id_candidature = ?";
                PreparedStatement pst3 = cnx.prepareStatement(boostSql);
                pst3.setInt(1, idCandidature);
                pst3.executeUpdate();

                cnx.commit(); // Valider les deux opérations
                return "SUCCESS";
            } else {
                return "NO_BOOSTS";
            }
        } catch (SQLException e) {
            try { cnx.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            e.printStackTrace();
            return "ERROR";
        } finally {
            try { cnx.setAutoCommit(true); } catch (SQLException e) { e.printStackTrace(); }
        }
    }
}