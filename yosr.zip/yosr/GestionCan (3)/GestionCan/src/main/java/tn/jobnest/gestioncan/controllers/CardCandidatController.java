package tn.jobnest.gestioncan.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import tn.jobnest.gestioncan.models.Formations;
import tn.jobnest.gestioncan.services.PaymentService;
import tn.jobnest.gestioncan.services.ServicesFormations;
import tn.jobnest.gestioncan.utils.NavigationService;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;

public class CardCandidatController {

    @FXML private VBox rootPane;
    @FXML private ImageView imgFormation;
    @FXML private Label lblStatut, lblTitre, lblNiveau, lblFormateur, lblPlaces, lblPrix, lblDuree;
    @FXML private ProgressBar progressPlaces;

    private Formations formation;
    private final PaymentService paymentService = new PaymentService();
    private final ServicesFormations servicesFormations = new ServicesFormations();

    public void setData(Formations f) {
        this.formation = f;

        if (lblTitre != null) lblTitre.setText(f.getTitre());
        if (lblPrix != null) lblPrix.setText(f.getPrix() + " DT");
        if (lblNiveau != null) lblNiveau.setText("◆ " + f.getNiveau());
        if (lblFormateur != null) lblFormateur.setText("👤 " + f.getNomFormateur());
        if (lblDuree != null) lblDuree.setText("⏱ " + f.getDuree_heures() + "h");

        if (progressPlaces != null) {
            double ratio = (f.getNb_places() > 0) ? (double) f.getNb_places_occupees() / f.getNb_places() : 0;
            progressPlaces.setProgress(ratio);
            progressPlaces.setStyle(ratio >= 0.8 ? "-fx-accent: #ED8936;" : "-fx-accent: #48BB78;");
        }

        if (lblPlaces != null) {
            lblPlaces.setText("👥 Places : " + f.getNb_places_occupees() + " / " + f.getNb_places());
        }

        updateStatutUI(f);

        if (imgFormation != null) {
            try {
                String imagePath = (f.getUrl_image() != null && !f.getUrl_image().isEmpty())
                        ? f.getUrl_image()
                        : "/images/placeholder_formation.png";
                imgFormation.setImage(new Image(imagePath, true));
            } catch (Exception e) {
                System.err.println("⚠️ Erreur image : " + f.getTitre());
            }
        }
    }

    private void updateStatutUI(Formations f) {
        if (lblStatut != null) {
            if (f.getNb_places_occupees() >= f.getNb_places() && f.getNb_places() > 0) {
                lblStatut.setText("COMPLET");
                lblStatut.setStyle("-fx-background-color: #F56565; -fx-text-fill: white; -fx-padding: 3 10; -fx-background-radius: 5; -fx-font-weight: bold;");
            } else {
                lblStatut.setText("OUVERT");
                lblStatut.setStyle("-fx-background-color: #48BB78; -fx-text-fill: white; -fx-padding: 3 10; -fx-background-radius: 5; -fx-font-weight: bold;");
            }
        }
    }

    /**
     * ✅ ACTION CORRIGÉE : Vérification solde + Stripe + Débit Transactionnel
     */
    @FXML
    void sinscrire(ActionEvent event) {
        if (formation == null) return;

        // ⚠️ ID Utilisateur : Remplace '1' par ton système de session
        int idCandidatConnecte = 1;

        // 1. Vérification des places
        if (formation.getNb_places_occupees() >= formation.getNb_places()) {
            afficherAlerte("Erreur", "Cette formation est déjà complète.", Alert.AlertType.WARNING);
            return;
        }

        // 2. Vérification du solde AVANT de lancer Stripe
        if (!paymentService.verifierSoldeSuffisant(idCandidatConnecte, formation.getPrix())) {
            afficherAlerte("Solde Insuffisant", "Votre solde actuel est inférieur au prix de la formation (" + formation.getPrix() + " DT).", Alert.AlertType.ERROR);
            return;
        }

        try {
            // 3. Stripe : Initialisation
            long montantCentimes = (long) (formation.getPrix() * 100);
            String rawResponse = paymentService.creerSessionPaiement(montantCentimes, "candidat@jobnest.tn");

            String[] parts = rawResponse.split("###");
            String url = parts[0];
            String sessionId = parts[1];

            // 4. Ouvrir Stripe
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().browse(new URI(url));
            }

            // 5. Attendre confirmation
            Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
            confirmAlert.setTitle("Paiement Stripe");
            confirmAlert.setHeaderText("Confirmation de l'inscription");
            confirmAlert.setContentText("Avez-vous complété le paiement sur Stripe ?");

            confirmAlert.showAndWait().ifPresent(reponse -> {
                if (reponse == ButtonType.OK) {
                    if (paymentService.verifierPaiement(sessionId)) {

                        // 6. ✅ TRANSACTION : Soustraction solde (Table candidat) ET ajout place
                        if (servicesFormations.confirmerInscription(
                                formation.getId_formation(),
                                idCandidatConnecte,
                                formation.getPrix())) {

                            formation.setNb_places_occupees(formation.getNb_places_occupees() + 1);
                            setData(formation); // Refresh UI

                            afficherAlerte("Succès", "Inscription réussie ! " + formation.getPrix() + " DT ont été déduits de votre solde.", Alert.AlertType.INFORMATION);
                        } else {
                            afficherAlerte("Erreur BDD", "Le paiement Stripe a réussi, mais la mise à jour de votre solde a échoué.", Alert.AlertType.ERROR);
                        }
                    } else {
                        afficherAlerte("Échec", "Le paiement n'a pas été validé par Stripe.", Alert.AlertType.ERROR);
                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            afficherAlerte("Erreur", "Une erreur technique est survenue lors du paiement.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    void onCardClicked(MouseEvent event) {
        if (formation == null) return;
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/ModulesFormation.fxml"));
            Parent root = loader.load();
            ModulesFormationController controller = loader.getController();
            if (controller != null) controller.chargerModulesPourCandidat(this.formation);

            MainLayoutController main = NavigationService.getMainController();
            if (main != null && main.getContentArea() != null) {
                main.getContentArea().getChildren().setAll(root);
            }
        } catch (IOException e) {
            System.err.println("❌ Erreur navigation : " + e.getMessage());
        }
    }

    @FXML
    void voirDetails(ActionEvent event) {
        if (formation == null) return;
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/details-view.fxml"));
            Parent root = loader.load();
            DetailsController controller = loader.getController();
            if (controller != null) controller.setFormation(formation);

            Stage stage = new Stage();
            stage.setTitle("Détails - " + formation.getTitre());
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void afficherAlerte(String titre, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.show();
    }
}