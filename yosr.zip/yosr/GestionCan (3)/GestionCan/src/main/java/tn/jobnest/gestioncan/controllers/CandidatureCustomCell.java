package tn.jobnest.gestioncan.controllers;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import tn.jobnest.gestioncan.models.Candidature;

public class CandidatureCustomCell extends ListCell<Candidature> {
    private final MesCandidaturesController controller;

    public CandidatureCustomCell(MesCandidaturesController controller) {
        this.controller = controller;
    }

    @Override
    protected void updateItem(Candidature item, boolean empty) {
        super.updateItem(item, empty);
        if (empty || item == null) {
            setGraphic(null);
            setStyle("-fx-background-color: transparent;");
        } else {
            // Conteneur de la carte
            HBox card = new HBox(15);
            card.setAlignment(Pos.CENTER_LEFT);
            card.setPadding(new Insets(15, 20, 15, 20));
            card.setStyle("-fx-background-color: white; -fx-background-radius: 12; -fx-border-color: #F1F5F9; -fx-border-radius: 12;");

            // Barre latérale colorée
            Rectangle indicator = new Rectangle(4, 40, Color.web(item.getIsBoosted() == 1 ? "#8B5CF6" : "#6366F1"));
            indicator.setArcHeight(4); indicator.setArcWidth(4);

            // Infos Texte
            VBox textGroup = new VBox(2);
            Label titre = new Label(item.getTitreOffre());
            titre.setStyle("-fx-font-weight: 800; -fx-font-size: 15px; -fx-text-fill: #0F172A;");
            Label entreprise = new Label(item.getNomEntreprise() + " • " + item.getDateCandidature());
            entreprise.setStyle("-fx-text-fill: #64748B; -fx-font-size: 12px;");
            textGroup.getChildren().addAll(titre, entreprise);

            // Badge Statut
            Label badge = new Label(item.getStatut().toUpperCase());
            badge.setPadding(new Insets(4, 10, 4, 10));
            String statusStyle = item.getStatut().equalsIgnoreCase("Acceptée") ? "-fx-background-color: #DCFCE7; -fx-text-fill: #15803D;" : "-fx-background-color: #FEF3C7; -fx-text-fill: #B45309;";
            badge.setStyle("-fx-background-radius: 8; -fx-font-weight: bold; -fx-font-size: 10px; " + statusStyle);

            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);

            // --- SECTION BOUTONS ---

            // Bouton Boost
            Button btnBoost = new Button(item.getIsBoosted() == 1 ? "✅ Prioritaire" : "🚀 Boost");
            btnBoost.setDisable(item.getIsBoosted() == 1);
            btnBoost.setStyle("-fx-background-color: #6366F1; -fx-text-fill: white; -fx-background-radius: 8; -fx-font-weight: bold; -fx-cursor: hand;");
            btnBoost.setOnAction(e -> controller.gererBoost(item));

            // Bouton Modifier (✎)
            Button btnEdit = new Button("✎");
            btnEdit.setStyle("-fx-background-color: #F1F5F9; -fx-text-fill: #475569; -fx-background-radius: 8; -fx-font-size: 14px; -fx-cursor: hand;");
            btnEdit.setTooltip(new Tooltip("Modifier ma candidature"));
            btnEdit.setOnAction(e -> controller.ouvrirFenetreModification(item));

            // Bouton Supprimer (🗑)
            Button btnDelete = new Button("🗑");
            btnDelete.setStyle("-fx-background-color: #FEE2E2; -fx-text-fill: #EF4444; -fx-background-radius: 8; -fx-font-size: 14px; -fx-cursor: hand;");
            btnDelete.setTooltip(new Tooltip("Supprimer ma candidature"));
            btnDelete.setOnAction(e -> controller.supprimerCandidature(item));

            HBox actions = new HBox(10, btnBoost, btnEdit, btnDelete);
            actions.setAlignment(Pos.CENTER_RIGHT);

            card.getChildren().addAll(indicator, textGroup, badge, spacer, actions);

            // Effet de survol
            card.setOnMouseEntered(e -> card.setStyle(card.getStyle() + "-fx-border-color: #6366F1; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.05), 10, 0, 0, 4);"));
            card.setOnMouseExited(e -> card.setStyle(card.getStyle().split("-fx-effect")[0] + "-fx-border-color: #F1F5F9;"));

            setGraphic(card);
            setStyle("-fx-background-color: transparent; -fx-padding: 0 0 12 0;");
        }
    }
}