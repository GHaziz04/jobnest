package tn.jobnest.gestioncan.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import tn.jobnest.gestioncan.models.Candidature;
import tn.jobnest.gestioncan.models.DocumentCandidature;
import tn.jobnest.gestioncan.services.CandidatureService;
import tn.jobnest.gestioncan.services.DocumentService;

import java.io.File;

public class ModifierCandidatureController {

    // --- ÉLÉMENTS FXML ---
    @FXML private TextField fieldFichier;
    @FXML private TextArea txtMessage; // Ajouté pour modifier aussi la lettre de motivation

    // --- DONNÉES ---
    private File fichierSelectionne;
    private Candidature candidatureActuelle;
    private DocumentCandidature documentActuel;

    // --- SERVICES ---
    private final DocumentService docService = new DocumentService();
    private final CandidatureService candidatureService = new CandidatureService();

    /**
     * Méthode appelée par le contrôleur précédent pour passer les infos
     */
    public void setCandidature(Candidature candidature) {
        this.candidatureActuelle = candidature;

        // 1. Remplir le message existant
        if (txtMessage != null) {
            // Attention : vérifiez si votre getter s'appelle getMessageComplementaire() ou getLettreMotivation()
            txtMessage.setText(candidature.getMessageComplementaire());
        }

        // 2. Chercher le document en base de données
        // Assurez-vous que la méthode dans le service est bien getByCandidatureId
        this.documentActuel = docService.getByCandidature(candidature.getIdCandidature());

        // 3. Afficher le nom du fichier si trouvé
        if (this.documentActuel != null) {
            fieldFichier.setText(this.documentActuel.getNomDocument());
        } else {
            fieldFichier.setPromptText("Aucun document joint pour le moment.");
        }
    }

    @FXML
    private void choisirFichier() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Sélectionner un nouveau fichier");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Documents (PDF, Images)", "*.pdf", "*.jpg", "*.png", "*.docx"));

        Stage stage = (Stage) fieldFichier.getScene().getWindow();
        this.fichierSelectionne = fileChooser.showOpenDialog(stage);

        if (this.fichierSelectionne != null) {
            fieldFichier.setText(this.fichierSelectionne.getName());
        }
    }

    @FXML
    private void enregistrerModification() {
        if (candidatureActuelle == null) return;

        try {
            // --- ÉTAPE 1 : Mise à jour de la Candidature (Message) ---
            if (txtMessage != null) {
                candidatureActuelle.setMessageComplementaire(txtMessage.getText());
                candidatureService.modifier(candidatureActuelle);
            }

            // --- ÉTAPE 2 : Gestion du Document ---
            if (fichierSelectionne != null) {
                // L'utilisateur a choisi un NOUVEAU fichier

                if (documentActuel != null) {
                    // CAS A : Un document existait déjà -> UPDATE
                    documentActuel.setNomDocument(fichierSelectionne.getName());
                    documentActuel.setCheminFichier(fichierSelectionne.getAbsolutePath());
                    // On peut aussi mettre à jour le type si besoin
                    // documentActuel.setTypeDocument("CV");

                    docService.modifier(documentActuel);
                } else {
                    // CAS B : Aucun document avant -> INSERT
                    // Constructeur : id (0), idCandidature, nom, type, chemin
                    DocumentCandidature nouveauDoc = new DocumentCandidature(
                            0, // ID 0 car auto-incrémenté
                            candidatureActuelle.getIdCandidature(),
                            fichierSelectionne.getName(),
                            "CV", // Type par défaut ou à récupérer via un ComboBox
                            fichierSelectionne.getAbsolutePath()
                    );
                    docService.ajouter(nouveauDoc);
                }
            }

            afficherAlerte(Alert.AlertType.INFORMATION, "Succès", "Les modifications ont été enregistrées !");
            fermer();

        } catch (Exception e) {
            e.printStackTrace();
            afficherAlerte(Alert.AlertType.ERROR, "Erreur", "Problème lors de l'enregistrement : " + e.getMessage());
        }
    }

    @FXML
    private void fermer() {
        // On récupère la fenêtre via n'importe quel composant de la scène
        Stage stage = (Stage) fieldFichier.getScene().getWindow();
        stage.close();
    }

    private void afficherAlerte(Alert.AlertType type, String titre, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}