package tn.jobnest.gestioncan.utils.pdf;

import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.canvas.draw.SolidLine;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.borders.SolidBorder;
import com.itextpdf.layout.element.*;
import com.itextpdf.layout.properties.HorizontalAlignment;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import com.itextpdf.layout.properties.VerticalAlignment;
import tn.jobnest.gestioncan.models.*;

import java.net.MalformedURLException;
import java.util.List;

public class TemplateModern implements ICVGenerator {

    // Couleurs définies comme constantes pour réutilisation
    private static final DeviceRgb COL_DARK_BLUE = new DeviceRgb(30, 41, 59);
    private static final DeviceRgb COL_ORANGE = new DeviceRgb(214, 158, 125);
    private static final DeviceRgb COL_TEXT_LIGHT = new DeviceRgb(200, 200, 200);

    @Override
    public void generer(String dest, Candidat candidat, List<Experience> experiences,
                        List<Formation> formations, List<Competence> competences, List<Langue> langues) throws Exception {

        // 1. Initialisation du PDF
        PdfWriter writer = new PdfWriter(dest);
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf, PageSize.A4);
        document.setMargins(0, 0, 0, 0); // Pas de marges pour remplir la page

        // 2. Création de la table principale (2 colonnes : 30% gauche, 70% droite)
        Table mainTable = new Table(UnitValue.createPercentArray(new float[]{30, 70}));
        mainTable.useAllAvailableWidth();
        // Force la hauteur de la table à faire toute la page
        mainTable.setHeight(pdf.getDefaultPageSize().getHeight());

        // ==========================================
        // COLONNE GAUCHE (BLEU FONCÉ)
        // ==========================================
        Cell cellLeft = new Cell();
        cellLeft.setBackgroundColor(COL_DARK_BLUE);
        cellLeft.setBorder(Border.NO_BORDER);
        cellLeft.setPadding(20);

        // --- PHOTO DE PROFIL (MODIFICATION ICI) ---
        boolean photoAjoutee = false;
        String imagePath = candidat.getImage();

        if (imagePath != null && !imagePath.isEmpty()) {
            try {
                // Création de l'image
                ImageData imageData = ImageDataFactory.create(imagePath);
                Image img = new Image(imageData);

                // Style de l'image
                img.setAutoScale(true); // S'adapte à la largeur
                img.setWidth(UnitValue.createPercentValue(90)); // Prend 90% de la largeur de la colonne
                img.setHorizontalAlignment(HorizontalAlignment.CENTER);

                // Petite bordure blanche esthétique
                img.setBorder(new SolidBorder(ColorConstants.WHITE, 2));

                // Marge en bas pour séparer du contact
                img.setMarginBottom(30);

                cellLeft.add(img);
                photoAjoutee = true;

            } catch (Exception e) {
                // Si l'image n'est pas trouvée, on ne fait rien ici et on laissera le code des initiales s'exécuter
                System.err.println("Erreur chargement image : " + e.getMessage());
            }
        }

        // SI PAS DE PHOTO : On affiche les initiales (Ton ancien code)
        if (!photoAjoutee) {
            String initials = "";
            if (candidat.getPrenom() != null && !candidat.getPrenom().isEmpty())
                initials += candidat.getPrenom().charAt(0);
            if (candidat.getNom() != null && !candidat.getNom().isEmpty())
                initials += candidat.getNom().charAt(0);

            Paragraph pInitials = new Paragraph(initials.toUpperCase())
                    .setFontSize(30)
                    .setBold()
                    .setFontColor(ColorConstants.WHITE)
                    .setTextAlignment(TextAlignment.CENTER)
                    .setBackgroundColor(COL_ORANGE)
                    .setPadding(15)
                    .setWidth(80)
                    .setHeight(80)
                    .setVerticalAlignment(VerticalAlignment.MIDDLE)
                    .setMarginBottom(40)
                    .setMarginLeft(15);
            cellLeft.add(pInitials);
        }

        // --- Section CONTACT ---
        ajouterTitreSectionGauche(cellLeft, "CONTACT");
        ajouterInfoContact(cellLeft, "Email", candidat.getEmail());
        ajouterInfoContact(cellLeft, "Tél", candidat.getTelephone());
        ajouterInfoContact(cellLeft, "Ville", candidat.getVille());

        // --- Section COMPÉTENCES ---
        cellLeft.add(new Paragraph("\n")); // Espace
        ajouterTitreSectionGauche(cellLeft, "COMPÉTENCES");
        for (Competence c : competences) {
            cellLeft.add(new Paragraph("• " + c.getNom())
                    .setFontColor(ColorConstants.WHITE)
                    .setFontSize(10)
                    .setMarginBottom(3));
        }

        // --- Section LANGUES ---
        if (!langues.isEmpty()) {
            cellLeft.add(new Paragraph("\n"));
            ajouterTitreSectionGauche(cellLeft, "LANGUES");
            for (Langue l : langues) {
                cellLeft.add(new Paragraph(l.getNom() + " (" + l.getNiveau() + ")")
                        .setFontColor(ColorConstants.WHITE)
                        .setFontSize(10)
                        .setMarginBottom(3));
            }
        }

        // ==========================================
        // COLONNE DROITE (BLANC)
        // ==========================================
        Cell cellRight = new Cell();
        cellRight.setBorder(Border.NO_BORDER);
        cellRight.setPadding(30);

        // --- Entête Nom/Prénom ---
        Paragraph pNom = new Paragraph(candidat.getPrenom() + " " + candidat.getNom())
                .setFontSize(28)
                .setBold()
                .setFontColor(COL_DARK_BLUE)
                .setTextAlignment(TextAlignment.LEFT);
        cellRight.add(pNom);

        // --- Bio ---
        if (candidat.getBio() != null && !candidat.getBio().isEmpty()) {
            cellRight.add(new Paragraph(candidat.getBio())
                    .setItalic()
                    .setFontColor(ColorConstants.GRAY)
                    .setMarginBottom(20));
        }

        // --- Section EXPÉRIENCES ---
        ajouterTitreSectionDroite(cellRight, "EXPÉRIENCES PROFESSIONNELLES");
        for (Experience exp : experiences) {
            // Titre du poste
            cellRight.add(new Paragraph(exp.getPoste())
                    .setBold()
                    .setFontSize(12)
                    .setFontColor(COL_DARK_BLUE)
                    .setMarginBottom(0));

            // Entreprise et Dates
            String dates = "";
            if(exp.getDateDebut() != null) dates += exp.getDateDebut().toString();
            if(exp.getDateFin() != null) dates += " - " + exp.getDateFin().toString();
            else dates += " - Présent";

            cellRight.add(new Paragraph(exp.getEntreprise() + " | " + dates)
                    .setFontSize(10)
                    .setItalic()
                    .setFontColor(ColorConstants.GRAY)
                    .setMarginBottom(3));

            // Description
            if (exp.getDescription() != null && !exp.getDescription().isEmpty()) {
                cellRight.add(new Paragraph(exp.getDescription())
                        .setFontSize(10)
                        .setTextAlignment(TextAlignment.JUSTIFIED)
                        .setMarginBottom(10));
            } else {
                cellRight.add(new Paragraph("\n")); // Petit saut si pas de description
            }
        }

        // --- Section FORMATION ---
        cellRight.add(new Paragraph("\n")); // Espace entre sections
        ajouterTitreSectionDroite(cellRight, "FORMATION");
        for (Formation form : formations) {
            cellRight.add(new Paragraph(form.getDiplome())
                    .setBold()
                    .setFontSize(11)
                    .setFontColor(COL_DARK_BLUE)
                    .setMarginBottom(0));

            cellRight.add(new Paragraph(form.getEcole() + " (" + form.getAnneeDebut() + " - " + form.getAnneeFin() + ")")
                    .setFontSize(10)
                    .setFontColor(ColorConstants.GRAY)
                    .setMarginBottom(5));
        }

        // Ajout des cellules à la table et fermeture
        mainTable.addCell(cellLeft);
        mainTable.addCell(cellRight);
        document.add(mainTable);
        document.close();
    }

    // ==========================================
    // MÉTHODES UTILITAIRES PRIVÉES (Helpers)
    // ==========================================

    private void ajouterTitreSectionGauche(Cell cell, String titre) {
        cell.add(new Paragraph(titre)
                .setBold()
                .setFontSize(12)
                .setFontColor(COL_ORANGE)
                .setMarginBottom(5)
                .setBorderBottom(new SolidBorder(COL_ORANGE, 1f)));
    }

    private void ajouterTitreSectionDroite(Cell cell, String titre) {
        cell.add(new Paragraph(titre.toUpperCase())
                .setBold()
                .setFontSize(14)
                .setFontColor(COL_DARK_BLUE)
                .setMarginTop(10));

        // Ligne de séparation
        LineSeparator ls = new LineSeparator(new SolidLine(1f));
        ls.setMarginBottom(10);
        cell.add(ls);
    }

    private void ajouterInfoContact(Cell cell, String label, String value) {
        if (value != null && !value.isEmpty()) {
            // Label en petit gris
            cell.add(new Paragraph(label)
                    .setFontSize(8)
                    .setBold()
                    .setFontColor(COL_ORANGE)
                    .setMarginBottom(0));
            // Valeur en blanc
            cell.add(new Paragraph(value)
                    .setFontSize(10)
                    .setFontColor(ColorConstants.WHITE)
                    .setMarginBottom(8));
        }
    }
}