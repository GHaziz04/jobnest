package tn.jobnest.gestioncan.services;

import tn.jobnest.gestioncan.models.QuizQuestion;
import tn.jobnest.gestioncan.utils.MyDatabase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ServiceQuizz {

    /**
     * Récupère toutes les questions liées à une ressource de type 'QUIZ'
     */
    public List<QuizQuestion> getQuestionsParRessource(int idRessource) {
        List<QuizQuestion> questions = new ArrayList<>();

        String sql = "SELECT qn.* FROM question qn " +
                "JOIN quizz q ON qn.id_quizz = q.id_quizz " +
                "WHERE q.id_ressource = ? " +
                "ORDER BY qn.id_question ASC";

        Connection cnx = MyDatabase.getInstance().getCnx();

        try {
            if (cnx == null || cnx.isClosed()) {
                System.err.println("❌ Erreur : La connexion à la base de données est fermée.");
                return questions;
            }

            try (PreparedStatement ps = cnx.prepareStatement(sql)) {
                ps.setInt(1, idRessource);

                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        List<String> optionsList = new ArrayList<>();

                        String o1 = rs.getString("option1");
                        String o2 = rs.getString("option2");
                        String o3 = rs.getString("option3");

                        if (o1 != null && !o1.isEmpty()) optionsList.add(o1);
                        if (o2 != null && !o2.isEmpty()) optionsList.add(o2);
                        if (o3 != null && !o3.isEmpty()) optionsList.add(o3);

                        questions.add(new QuizQuestion(
                                rs.getInt("id_question"),
                                rs.getString("texte_question"),
                                optionsList,
                                String.valueOf(rs.getInt("reponse_correcte"))
                        ));
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur SQL ServiceQuizz (getQuestions) : " + e.getMessage());
            e.printStackTrace();
        }
        return questions;
    }

    /**
     * Récupère le score de réussite défini pour le quiz
     */
    public int getScoreReussite(int idRessource) {
        String sql = "SELECT score_reussite FROM quizz WHERE id_ressource = ?";
        Connection cnx = MyDatabase.getInstance().getCnx();

        try {
            if (cnx == null || cnx.isClosed()) return 70;

            try (PreparedStatement ps = cnx.prepareStatement(sql)) {
                ps.setInt(1, idRessource);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return rs.getInt("score_reussite");
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur SQL ServiceQuizz (getScore) : " + e.getMessage());
        }
        return 70;
    }

    /**
     * Sauvegarde le score du candidat de manière indépendante
     */
    public void sauvegarderScoreCandidat(int idCandidat, int idRes, int score) {
        String sql = "INSERT INTO candidat_quizz (id_candidat, id_quizz, score, statut) " +
                "VALUES (?, (SELECT id_quizz FROM quizz WHERE id_ressource = ?), ?, ?) " +
                "ON DUPLICATE KEY UPDATE score = VALUES(score), statut = VALUES(statut)";

        Connection cnx = MyDatabase.getInstance().getCnx();

        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, idCandidat);
            ps.setInt(2, idRes);
            ps.setInt(3, score);
            ps.setString(4, (score >= 66) ? "VALIDE" : "ECHEC");

            ps.executeUpdate();
            System.out.println("✅ Score de " + score + "% enregistré pour le candidat " + idCandidat);
        } catch (SQLException e) {
            System.err.println("❌ Erreur sauvegarde score: " + e.getMessage());
        }
    }

    /**
     * ✅ NOUVELLE MÉTHODE : Vérifie si le module précédent est validé (score >= 66)
     * Utile pour le contrôle d'accès aux modules suivants.
     */
    public boolean isModulePrecedentValide(int idCandidat, int idModulePrecedent) {
        // Cette requête vérifie si au moins un quiz du module précédent est validé à >= 66%
        String sql = "SELECT cq.score FROM candidat_quizz cq " +
                "JOIN quizz q ON cq.id_quizz = q.id_quizz " +
                "JOIN ressource r ON q.id_ressource = r.id_ressource " +
                "WHERE cq.id_candidat = ? AND r.id_module = ? AND cq.score >= 66 LIMIT 1";

        Connection cnx = MyDatabase.getInstance().getCnx();

        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, idCandidat);
            ps.setInt(2, idModulePrecedent);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next(); // Retourne true si une ligne (réussite) existe
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur vérification verrouillage : " + e.getMessage());
            return false;
        }
    }

    /**
     * Alias utilisé par le contrôleur
     */
    public List<QuizQuestion> getQuizComplet(int idRessource) {
        return getQuestionsParRessource(idRessource);
    }
}