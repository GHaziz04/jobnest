package tn.jobnest.gestioncan.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import tn.jobnest.gestioncan.models.Candidature;
import tn.jobnest.gestioncan.services.CandidatureService;
import tn.jobnest.gestioncan.services.BoostService;
import tn.jobnest.gestioncan.utils.NavigationService;

import java.io.IOException;
import java.util.Optional;

public class MesCandidaturesController {

    private final CandidatureService service = new CandidatureService();
    private final BoostService boostService = new BoostService();
    private final int ID_USER_CONNECTE = 1;

    private ObservableList<Candidature> masterData = FXCollections.observableArrayList();
    private FilteredList<Candidature> filteredData;

    @FXML private ListView<Candidature> listCandidatures;
    @FXML private TextField txtRecherche;
    @FXML private Label statTotal, statEnCours, statAcceptees;

    @FXML
    public void initialize() {
        // Appliquer le design personnalisé à chaque ligne de la liste
        listCandidatures.setCellFactory(param -> new CandidatureCustomCell(this));

        chargerDonnees();
        setupRecherche();
    }

    @FXML
    public void chargerDonnees() {
        masterData.setAll(service.getHistoriqueCandidat(ID_USER_CONNECTE));
        mettreAJourStats();
    }

    @FXML
    private void rafraichirListe() {
        chargerDonnees();
    }

    @FXML
    private void allerVersOffres() {
        NavigationService.chargerVue("/View/OffresView.fxml");
    }

    private void mettreAJourStats() {
        statTotal.setText(String.format("%02d", masterData.size()));
        long enAttente = masterData.stream()
                .filter(c -> "En attente".equalsIgnoreCase(c.getStatut()) || "TRAITÉ".equalsIgnoreCase(c.getStatut()))
                .count();
        statEnCours.setText(String.format("%02d", enAttente));

        long acceptees = masterData.stream()
                .filter(c -> "Acceptée".equalsIgnoreCase(c.getStatut()))
                .count();
        statAcceptees.setText(String.format("%02d", acceptees));
    }

    private void setupRecherche() {
        filteredData = new FilteredList<>(masterData, p -> true);
        txtRecherche.textProperty().addListener((obs, old, nv) -> {
            filteredData.setPredicate(c -> {
                if (nv == null || nv.isEmpty()) return true;
                String lower = nv.toLowerCase();
                return c.getTitreOffre().toLowerCase().contains(lower) ||
                        c.getNomEntreprise().toLowerCase().contains(lower);
            });
        });
        listCandidatures.setItems(filteredData);
    }

    // --- ACTIONS APPELÉES PAR LES CARTES ---

    public void gererBoost(Candidature c) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Boost");
        confirm.setHeaderText("Propulser votre candidature ?");
        confirm.setContentText("Voulez-vous utiliser 1 crédit boost ?");

        confirm.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                String res = boostService.appliquerBoost(ID_USER_CONNECTE, c.getIdCandidature());
                if ("SUCCESS".equals(res)) {
                    chargerDonnees();
                } else if ("NO_BOOSTS".equals(res)) {
                    NavigationService.chargerVue("/View/PacksBoost.fxml");
                }
            }
        });
    }

    public void ouvrirFenetreModification(Candidature c) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/PostulerModal.fxml"));
            Parent root = loader.load();
            PostulerController pc = loader.getController();
            pc.setCandidaturePourModification(c);

            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.showAndWait();
            chargerDonnees();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void supprimerCandidature(Candidature c) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Supprimer cette candidature ?", ButtonType.YES, ButtonType.NO);
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                service.supprimer(c.getIdCandidature());
                chargerDonnees();
            }
        });
    }
}