package tn.jobnest.gestioncan.models;

import java.util.List;

public class CVData {

    // --- 1. Informations Personnelles ---
    private String nomComplet;
    private String email;
    private String telephone;
    private String adresse;
    private String titreProfil; // Ex: "Ingénieur Logiciel", "Étudiant en Marketing"

    // --- 2. Listes de données (Tables liées) ---
    private List<Experience> experiences;
    private List<Formation> formations;
    private List<Competence> competences;
    private List<String> langues; // J'ai gardé String comme demandé, mais tu peux mettre List<Langue>

    // --- 3. Constructeur Complet ---
    public CVData(String nomComplet, String email, String telephone, String adresse, String titreProfil,
                  List<Experience> experiences, List<Formation> formations,
                  List<Competence> competences, List<String> langues) {
        this.nomComplet = nomComplet;
        this.email = email;
        this.telephone = telephone;
        this.adresse = adresse;
        this.titreProfil = titreProfil;
        this.experiences = experiences;
        this.formations = formations;
        this.competences = competences;
        this.langues = langues;
    }

    // --- 4. Constructeur Vide (Parfois utile pour initialiser petit à petit) ---
    public CVData() {
    }

    // --- 5. Getters (Pour lire les valeurs) ---
    public String getNomComplet() {
        return nomComplet;
    }

    public String getEmail() {
        return email;
    }

    public String getTelephone() {
        return telephone;
    }

    public String getAdresse() {
        return adresse;
    }

    public String getTitreProfil() {
        return titreProfil;
    }

    public List<Experience> getExperiences() {
        return experiences;
    }

    public List<Formation> getFormations() {
        return formations;
    }

    public List<Competence> getCompetences() {
        return competences;
    }

    public List<String> getLangues() {
        return langues;
    }

    // --- 6. Setters (Pour modifier les valeurs si besoin) ---
    public void setNomComplet(String nomComplet) {
        this.nomComplet = nomComplet;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public void setTitreProfil(String titreProfil) {
        this.titreProfil = titreProfil;
    }

    public void setExperiences(List<Experience> experiences) {
        this.experiences = experiences;
    }

    public void setFormations(List<Formation> formations) {
        this.formations = formations;
    }

    public void setCompetences(List<Competence> competences) {
        this.competences = competences;
    }

    public void setLangues(List<String> langues) {
        this.langues = langues;
    }

    // --- 7. Méthode toString (Pour le débuggage : System.out.println(cvData)) ---
    @Override
    public String toString() {
        return "CVData{" +
                "nom='" + nomComplet + '\'' +
                ", email='" + email + '\'' +
                ", titre='" + titreProfil + '\'' +
                ", nb_experiences=" + (experiences != null ? experiences.size() : 0) +
                ", nb_formations=" + (formations != null ? formations.size() : 0) +
                '}';
    }
}