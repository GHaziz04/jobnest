package tn.jobnest.gestioncan.services;


import tn.jobnest.gestioncan.models.Formation;
import tn.jobnest.gestioncan.services.ICrud;
import tn.jobnest.gestioncan.utils.MyDatabase;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FormationService implements ICrud<Formation> {

    private Connection cnx = MyDatabase.getInstance().getCnx();

    @Override
    public void ajouter(Formation f) {
        String req = "INSERT INTO cv_formation (id_candidat, diplome, ecole, annee_debut, annee_fin) VALUES (?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, f.getIdCandidat());
            ps.setString(2, f.getDiplome());
            ps.setString(3, f.getEcole());
            ps.setInt(4, 0); // Tu pourras rajouter les champs années dans ton formulaire plus tard
            ps.setInt(5, 0);
            ps.executeUpdate();
            System.out.println("Formation ajoutée !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Méthode indispensable pour le contrôleur
    public List<Formation> getByCandidat(int idCandidat) {
        List<Formation> list = new ArrayList<>();
        String req = "SELECT * FROM cv_formation WHERE id_candidat = ?";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, idCandidat);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Formation(
                        rs.getInt("id"),
                        rs.getInt("id_candidat"),
                        rs.getString("diplome"),
                        rs.getString("ecole"),
                        rs.getInt("annee_debut"),
                        rs.getInt("annee_fin")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public void modifier(Formation f) {
        // À implémenter si besoin
    }

    @Override
    public void supprimer(int id) {
        try {
            String req = "DELETE FROM cv_formation WHERE id = ?";
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Formation> afficher() {
        return new ArrayList<>(); // Pas utilisé ici
    }

    @Override
    public Map<Integer, Formation> getMap() {
        return new HashMap<>();
    }
}