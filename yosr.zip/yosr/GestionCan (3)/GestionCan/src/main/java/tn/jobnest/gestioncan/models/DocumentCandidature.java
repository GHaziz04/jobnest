package tn.jobnest.gestioncan.models;

public class DocumentCandidature {
    private int idDocument;
    private int idCandidature;
    private String nomDocument;   // ex: "CV_Jean_Dupont.pdf"
    private String typeDocument;  // ex: "CV", "Lettre de motivation"
    private String cheminFichier; // ex: "C:/Uploads/CV_Jean.pdf"

    // 1. Constructeur vide (Indispensable pour certains frameworks)
    public DocumentCandidature() {
    }

    // 2. Constructeur pour l'AJOUT (Sans idDocument, car auto-incrémenté)
    public DocumentCandidature(int idCandidature, String nomDocument, String typeDocument, String cheminFichier) {
        this.idCandidature = idCandidature;
        this.nomDocument = nomDocument;
        this.typeDocument = typeDocument;
        this.cheminFichier = cheminFichier;
    }

    // 3. Constructeur COMPLET (Pour la lecture depuis la BDD avec SELECT)
    public DocumentCandidature(int idDocument, int idCandidature, String nomDocument, String typeDocument, String cheminFichier) {
        this.idDocument = idDocument;
        this.idCandidature = idCandidature;
        this.nomDocument = nomDocument;
        this.typeDocument = typeDocument;
        this.cheminFichier = cheminFichier;
    }

    // --- GETTERS ET SETTERS (Indispensables pour modifier les infos) ---

    public int getIdDocument() { return idDocument; }
    public void setIdDocument(int idDocument) { this.idDocument = idDocument; }

    public int getIdCandidature() { return idCandidature; }
    public void setIdCandidature(int idCandidature) { this.idCandidature = idCandidature; }

    public String getNomDocument() { return nomDocument; }
    public void setNomDocument(String nomDocument) { this.nomDocument = nomDocument; }

    public String getTypeDocument() { return typeDocument; }
    public void setTypeDocument(String typeDocument) { this.typeDocument = typeDocument; }

    public String getCheminFichier() { return cheminFichier; }
    public void setCheminFichier(String cheminFichier) { this.cheminFichier = cheminFichier; }

    // Pour le debug (affichage dans la console)
    @Override
    public String toString() {
        return "Doc [ID=" + idDocument + ", Nom=" + nomDocument + "]";
    }
}