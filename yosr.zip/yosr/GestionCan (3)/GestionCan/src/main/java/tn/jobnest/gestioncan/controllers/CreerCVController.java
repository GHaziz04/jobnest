package tn.jobnest.gestioncan.controllers;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import tn.jobnest.gestioncan.models.*;
import tn.jobnest.gestioncan.services.*;
import tn.jobnest.gestioncan.utils.pdf.*;

import java.io.File;
import java.sql.Date;
import java.util.List;

public class CreerCVController {

    // --- SERVICES ---
    private final CandidatService candidatService = new CandidatService();
    private final ExperienceService experienceService = new ExperienceService();
    private final FormationService formationService = new FormationService();
    private final CompetenceService competenceService = new CompetenceService();
    private final LangueService langueService = new LangueService();

    // NOUVEAU : Le service IA
    private final GeminiService aiService = new GeminiService();

    // ID codé en dur pour l'exemple
    private final int ID_CANDIDAT = 1;

    // --- COMPOSANTS FXML ---
    @FXML private StackPane stackPaneContent;
    @FXML private VBox paneInfo, paneExp, paneForm, paneComp, paneLang, paneTemplates;

    // Pour l'animation de sélection du template
    @FXML private VBox cardClassic, cardModern;
    @FXML private Label lblTemplateActuel;

    // Champs de saisie
    @FXML private TextField txtNom, txtPrenom, txtEmail, txtTel, txtVille;
    @FXML private TextArea txtBio;

    // NOUVEAU : Bouton pour l'IA (pensez à ajouter fx:id="btnSmartBio" dans le FXML)
    @FXML private Button btnSmartBio;
    // Optionnel : un indicateur de chargement (fx:id="loaderBio")
    @FXML private ProgressIndicator loaderBio;

    // Listes d'affichage
    @FXML private ListView<String> listExperiences, listFormations, listCompetences, listLangues;

    // --- VARIABLE D'ÉTAT ---
    private String templateSelectionne = "Moderne";

    @FXML
    public void initialize() {
        chargerInfoUtilisateur();
        chargerToutesLesListes();
        afficherInfo();
        updateTemplateUI();

        // Initialisation de l'état du loader si présent
        if(loaderBio != null) loaderBio.setVisible(false);
    }

    // --- NAVIGATION ---
    private void switchPane(VBox paneToShow) {
        paneInfo.setVisible(false);
        paneExp.setVisible(false);
        paneForm.setVisible(false);
        paneComp.setVisible(false);
        paneLang.setVisible(false);
        paneTemplates.setVisible(false);

        if(paneToShow != null) paneToShow.setVisible(true);
    }

    @FXML void afficherInfo() { switchPane(paneInfo); }
    @FXML void afficherExp() { switchPane(paneExp); }
    @FXML void afficherForm() { switchPane(paneForm); }
    @FXML void afficherComp() { switchPane(paneComp); }
    @FXML void afficherLang() { switchPane(paneLang); }
    @FXML void afficherTemplates() { switchPane(paneTemplates); }

    // --- INTELLIGENCE ARTIFICIELLE (SMART BIO) ---
    @FXML
    void actionAmeliorerBio(ActionEvent event) {
        String brouillon = txtBio.getText();

        if (brouillon == null || brouillon.trim().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Attention");
            alert.setContentText("Veuillez écrire quelques mots clés ou une phrase simple d'abord.");
            alert.show();
            return;
        }

        // 1. Feedback visuel (chargement)
        if (btnSmartBio != null) {
            btnSmartBio.setDisable(true);
            btnSmartBio.setText("L'IA réfléchit...");
        }
        if (loaderBio != null) loaderBio.setVisible(true);

        // 2. Exécution dans un Thread séparé (pour ne pas bloquer l'interface)
        new Thread(() -> {
            // Appel au service (c'est ici que ça prend du temps)
            String bioAmelioree = aiService.ameliorerBio(brouillon);

            // 3. Mise à jour de l'interface graphique (doit se faire dans Platform.runLater)
            Platform.runLater(() -> {
                txtBio.setText(bioAmelioree);

                // Rétablir les boutons
                if (btnSmartBio != null) {
                    btnSmartBio.setDisable(false);
                    btnSmartBio.setText("✨ Améliorer avec l'IA");
                }
                if (loaderBio != null) loaderBio.setVisible(false);
            });
        }).start();
    }

    // --- LOGIQUE DE SELECTION DU TEMPLATE ---
    @FXML
    void choisirClassique() {
        templateSelectionne = "Classique";
        updateTemplateUI();
    }

    @FXML
    void choisirModerne() {
        templateSelectionne = "Moderne";
        updateTemplateUI();
    }

    private void updateTemplateUI() {
        lblTemplateActuel.setText("Modèle : " + templateSelectionne);
        String styleNormal = "-fx-background-color: white; -fx-padding: 20; -fx-background-radius: 12; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 10, 0, 0, 5); -fx-cursor: hand;";
        String styleSelected = styleNormal + " -fx-border-color: #2563EB; -fx-border-width: 3;";

        if (templateSelectionne.equals("Classique")) {
            cardClassic.setStyle(styleSelected);
            cardModern.setStyle(styleNormal);
        } else {
            cardClassic.setStyle(styleNormal);
            cardModern.setStyle(styleSelected);
        }
    }

    // --- GENERATION PDF ---
    @FXML
    void genererPDF(ActionEvent event) {
        try {
            FileChooser fc = new FileChooser();
            fc.setTitle("Exporter mon CV");
            String defaultName = "CV_" + txtNom.getText().trim() + "_" + txtPrenom.getText().trim() + ".pdf";
            fc.setInitialFileName(defaultName);
            fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Document PDF", "*.pdf"));

            Stage stage = (Stage) stackPaneContent.getScene().getWindow();
            File file = fc.showSaveDialog(stage);

            if (file != null) {
                Candidat candidat = candidatService.getById(ID_CANDIDAT);

                // Mise à jour temporaire de l'objet avec les données des champs
                candidat.setNom(txtNom.getText());
                candidat.setPrenom(txtPrenom.getText());
                candidat.setEmail(txtEmail.getText());
                candidat.setTelephone(txtTel.getText());
                candidat.setVille(txtVille.getText());
                candidat.setBio(txtBio.getText());

                List<Experience> exps = experienceService.getByCandidat(ID_CANDIDAT);
                List<Formation> forms = formationService.getByCandidat(ID_CANDIDAT);
                List<Competence> comps = competenceService.getByCandidat(ID_CANDIDAT);
                List<Langue> langs = langueService.getByCandidat(ID_CANDIDAT);

                ICVGenerator generator;
                if ("Classique".equals(templateSelectionne)) {
                    generator = new TemplateClassic();
                } else {
                    generator = new TemplateModern();
                }

                generator.generer(file.getAbsolutePath(), candidat, exps, forms, comps, langs);

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Succès");
                alert.setHeaderText(null);
                alert.setContentText("CV généré avec succès !\n" + file.getAbsolutePath());
                alert.showAndWait();
            }

        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setContentText("Erreur lors de la génération : " + e.getMessage());
            alert.show();
        }
    }

    // --- GESTION DES DONNEES (SAUVEGARDE & AJOUTS) ---

    @FXML
    void sauvegarderInfo() {
        // 1. Récupération de l'image existante
        Candidat oldC = candidatService.getById(ID_CANDIDAT);
        String currentImage = (oldC != null) ? oldC.getImage() : null;

        // 2. Création de l'objet avec le constructeur complet (8 paramètres)
        Candidat c = new Candidat(
                ID_CANDIDAT,
                txtNom.getText(),
                txtPrenom.getText(),
                txtEmail.getText(),
                txtTel.getText(),
                txtVille.getText(),
                txtBio.getText(),
                currentImage
        );

        candidatService.modifier(c);

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Info");
        alert.setHeaderText(null);
        alert.setContentText("Informations sauvegardées !");
        alert.show();
    }

    @FXML
    void ajouterExperience() {
        Dialog<Experience> dialog = new Dialog<>();
        dialog.setTitle("Expérience");
        dialog.setHeaderText("Ajouter une expérience");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        GridPane grid = new GridPane(); grid.setHgap(10); grid.setVgap(10); grid.setPadding(new Insets(20));

        TextField poste = new TextField(); poste.setPromptText("Poste");
        TextField ent = new TextField(); ent.setPromptText("Entreprise");
        DatePicker dd = new DatePicker();
        DatePicker df = new DatePicker();
        TextArea desc = new TextArea(); desc.setPromptText("Description"); desc.setPrefHeight(60);

        grid.add(new Label("Poste:"), 0, 0); grid.add(poste, 1, 0);
        grid.add(new Label("Entreprise:"), 0, 1); grid.add(ent, 1, 1);
        grid.add(new Label("Début:"), 0, 2); grid.add(dd, 1, 2);
        grid.add(new Label("Fin:"), 0, 3); grid.add(df, 1, 3);
        grid.add(new Label("Desc:"), 0, 4); grid.add(desc, 1, 4);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(b -> {
            if (b == ButtonType.OK) {
                Date d1 = (dd.getValue() != null) ? Date.valueOf(dd.getValue()) : null;
                Date d2 = (df.getValue() != null) ? Date.valueOf(df.getValue()) : null;
                return new Experience(ID_CANDIDAT, poste.getText(), ent.getText(), d1, d2, desc.getText());
            }
            return null;
        });

        dialog.showAndWait().ifPresent(res -> {
            experienceService.ajouter(res);
            chargerToutesLesListes();
        });
    }

    @FXML
    void ajouterFormation() {
        Dialog<Formation> dialog = new Dialog<>();
        dialog.setTitle("Formation");
        dialog.setHeaderText("Ajouter une formation");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        GridPane grid = new GridPane(); grid.setHgap(10); grid.setVgap(10); grid.setPadding(new Insets(20));

        TextField dip = new TextField();
        TextField ecole = new TextField();
        TextField ad = new TextField();
        TextField af = new TextField();

        grid.add(new Label("Diplôme:"), 0, 0); grid.add(dip, 1, 0);
        grid.add(new Label("Ecole:"), 0, 1); grid.add(ecole, 1, 1);
        grid.add(new Label("Année Début:"), 0, 2); grid.add(ad, 1, 2);
        grid.add(new Label("Année Fin:"), 0, 3); grid.add(af, 1, 3);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(b -> {
            if (b == ButtonType.OK) {
                try {
                    // Conversion explicite String vers int pour respecter le modèle
                    int anneeD = Integer.parseInt(ad.getText());
                    int anneeF = Integer.parseInt(af.getText());

                    return new Formation(ID_CANDIDAT, dip.getText(), ecole.getText(), anneeD, anneeF);
                } catch (NumberFormatException e) {
                    System.out.println("Erreur: Les années doivent être des nombres.");
                    return null;
                }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(f -> {
            formationService.ajouter(f);
            chargerToutesLesListes();
        });
    }

    @FXML
    void ajouterCompetence() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Compétence");
        dialog.setHeaderText("Nouvelle compétence");
        dialog.setContentText("Nom de la compétence :");

        dialog.showAndWait().ifPresent(nom -> {
            if (!nom.trim().isEmpty()) {
                // Constructeur corrigé : (id, id_candidat, nom)
                Competence c = new Competence(0, ID_CANDIDAT, nom);
                competenceService.ajouter(c);
                chargerToutesLesListes();
            }
        });
    }

    @FXML
    void ajouterLangue() {
        Dialog<Langue> dialog = new Dialog<>();
        dialog.setTitle("Langue");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        GridPane grid = new GridPane(); grid.setHgap(10); grid.setVgap(10); grid.setPadding(new Insets(20));
        TextField nom = new TextField();
        ComboBox<String> cb = new ComboBox<>();
        cb.getItems().addAll("A1", "A2", "B1", "B2", "C1", "C2", "Natif");
        cb.getSelectionModel().select("B2");

        grid.add(new Label("Langue:"), 0, 0); grid.add(nom, 1, 0);
        grid.add(new Label("Niveau:"), 0, 1); grid.add(cb, 1, 1);
        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(b -> (b == ButtonType.OK) ? new Langue(ID_CANDIDAT, nom.getText(), cb.getValue()) : null);

        dialog.showAndWait().ifPresent(l -> {
            langueService.ajouter(l);
            chargerToutesLesListes();
        });
    }

    // --- METHODES UTILITAIRES ---

    private void chargerInfoUtilisateur() {
        Candidat c = candidatService.getById(ID_CANDIDAT);
        if (c != null) {
            txtNom.setText(c.getNom());
            txtPrenom.setText(c.getPrenom());
            txtEmail.setText(c.getEmail());
            txtTel.setText(c.getTelephone());
            txtVille.setText(c.getVille());
            txtBio.setText(c.getBio());
        }
    }

    private void chargerToutesLesListes() {
        listExperiences.getItems().clear();
        listFormations.getItems().clear();
        listCompetences.getItems().clear();
        listLangues.getItems().clear();

        List<Experience> exps = experienceService.getByCandidat(ID_CANDIDAT);
        if(exps != null) exps.forEach(e -> listExperiences.getItems().add(e.getPoste() + " chez " + e.getEntreprise()));

        List<Formation> forms = formationService.getByCandidat(ID_CANDIDAT);
        if(forms != null) forms.forEach(f -> listFormations.getItems().add(f.getDiplome()));

        List<Competence> comps = competenceService.getByCandidat(ID_CANDIDAT);
        if(comps != null) comps.forEach(c -> listCompetences.getItems().add(c.getNom()));

        List<Langue> langs = langueService.getByCandidat(ID_CANDIDAT);
        if(langs != null) langs.forEach(l -> listLangues.getItems().add(l.getNom() + " (" + l.getNiveau() + ")"));
    }
}