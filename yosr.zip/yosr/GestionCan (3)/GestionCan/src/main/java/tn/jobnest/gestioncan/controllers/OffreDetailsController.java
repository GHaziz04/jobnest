package tn.jobnest.gestioncan.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import tn.jobnest.gestioncan.models.Offre;
import tn.jobnest.gestioncan.services.OffreService;

import java.io.IOException;
import java.util.List;

public class OffreDetailsController {

    @FXML private Label lblTypeContrat;
    @FXML private Label lblSalaire;
    @FXML private Label lblTitre;
    @FXML private Label lblEntreprise;
    @FXML private Label lblDescription;
    @FXML private FlowPane paneCompetences;
    @FXML private FlowPane paneExperiences;

    private Offre offreActuelle;

    // Le service pour récupérer les listes statiques
    private final OffreService offreService = new OffreService();

    public void setOffreDetails(Offre offre) {
        this.offreActuelle = offre;

        lblTitre.setText(offre.getTitre());
        lblTypeContrat.setText(offre.getTypeContrat() != null ? offre.getTypeContrat().toUpperCase() : "NON SPÉCIFIÉ");

        String niveau = offre.getNiveauExperience() != null ? offre.getNiveauExperience() : "Non spécifié";
        lblEntreprise.setText("🏢 " + offre.getEntreprise() + "  |  🎓 Niveau : " + niveau);

        lblDescription.setText(offre.getDescription() != null ? offre.getDescription() : "Aucune description fournie.");

        // CORRECTION ICI : Retrait des != null, on vérifie juste si c'est > 0
        if (offre.getSalaireMin() > 0 && offre.getSalaireMax() > 0) {
            lblSalaire.setText(offre.getSalaireMin() + " - " + offre.getSalaireMax() + " TND");
        } else {
            lblSalaire.setText("Salaire à négocier");
        }

        // Récupération des données simulées
        List<String> competences = offreService.getCompetencesPourOffre(offre.getIdOffre());
        List<String> experiences = offreService.getExperiencesPourOffre(offre.getIdOffre());

        afficherBadges(paneCompetences, competences, "#EEF2FF", "#4338CA");
        afficherBadges(paneExperiences, experiences, "#FFFBEB", "#B45309");
    }

    private void afficherBadges(FlowPane pane, List<String> items, String bgColor, String textColor) {
        pane.getChildren().clear();
        for (String item : items) {
            Label badge = new Label(item);
            badge.setStyle("-fx-background-color: " + bgColor + "; -fx-text-fill: " + textColor + "; -fx-padding: 5 12; -fx-background-radius: 15; -fx-font-size: 12px; -fx-font-weight: 600;");
            pane.getChildren().add(badge);
        }
    }

    @FXML
    private void ouvrirPostuler() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/PostulerModal.fxml"));
            Parent root = loader.load();

            PostulerController controller = loader.getController();
            controller.setOffrePourAjout(offreActuelle.getIdOffre(), offreActuelle.getTitre());

            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Postuler à : " + offreActuelle.getTitre());
            stage.setScene(new Scene(root));

            fermerFenetre();
            stage.showAndWait();

        } catch (IOException e) {
            System.err.println("Erreur de navigation : " + e.getMessage());
        }
    }

    @FXML
    private void fermerFenetre() {
        Stage stage = (Stage) lblTitre.getScene().getWindow();
        stage.close();
    }
}