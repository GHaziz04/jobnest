package tn.jobnest.gestioncan.services;

import tn.jobnest.gestioncan.models.Formations;
import tn.jobnest.gestioncan.utils.MyDatabase; // Import nécessaire
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ServicesFormations {

    // ✅ On définit les accès ici pour être indépendant du Singleton MyDatabase (pour l'affichage)
    private final String URL = "jdbc:mysql://localhost:3306/jobnest";
    private final String USER = "root";
    private final String PWD = "";

    // 1. RÉCUPÉRER TOUTES LES FORMATIONS
    public List<Formations> afficher() {
        List<Formations> formations = new ArrayList<>();
        String query = "SELECT f.*, fr.nom_formateur FROM formation f " +
                "LEFT JOIN formateur fr ON f.id_user = fr.id_user";

        try (Connection conn = DriverManager.getConnection(URL, USER, PWD);
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(query)) {
            while (rs.next()) {
                formations.add(mapperFormation(rs));
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur SQL (Afficher Front) : " + e.getMessage());
        }
        return formations;
    }

    // 2. RECHERCHER UNE FORMATION PAR TITRE
    public List<Formations> rechercherParTitre(String titre) {
        List<Formations> liste = new ArrayList<>();
        String query = "SELECT f.*, fr.nom_formateur FROM formation f " +
                "LEFT JOIN formateur fr ON f.id_user = fr.id_user " +
                "WHERE f.titre LIKE ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PWD);
             PreparedStatement pst = conn.prepareStatement(query)) {
            pst.setString(1, "%" + titre + "%");
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    liste.add(mapperFormation(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur SQL (Recherche) : " + e.getMessage());
        }
        return liste;
    }

    // --- LOGIQUE DE STATUT AUTOMATIQUE (Inchangée) ---
    private String calculerStatutAutomatique(Formations f) {
        LocalDate aujourdhui = LocalDate.now();
        if (f.getDate_fin() == null || f.getDate_debut() == null) return f.getStatut();

        LocalDate fin = f.getDate_fin().toLocalDate();
        if (fin.isBefore(aujourdhui)) {
            return "Terminé";
        }
        if (f.getNb_places_occupees() >= f.getNb_places() && f.getNb_places() > 0) {
            return "Complet";
        }
        return f.getStatut();
    }

    // MÉTHODE UTILITAIRE (Mapping ResultSet -> Objet)
    private Formations mapperFormation(ResultSet rs) throws SQLException {
        Formations f = new Formations();
        f.setId_formation(rs.getInt("id_formation"));
        f.setTitre(rs.getString("titre"));
        f.setDescription(rs.getString("description"));
        f.setPrix(rs.getDouble("prix"));
        f.setDuree_heures(rs.getInt("duree_heures"));
        f.setNb_places(rs.getInt("nb_places"));
        f.setNb_places_occupees(rs.getInt("nb_places_occupees"));
        f.setNiveau(rs.getString("niveau"));
        f.setLieu(rs.getString("lieu"));
        f.setUrl_image(rs.getString("url_image"));
        f.setObjectifs(rs.getString("objectifs"));
        f.setDate_debut(rs.getDate("date_debut"));
        f.setDate_fin(rs.getDate("date_fin"));
        f.setStatut(rs.getString("statut"));

        f.setStatut(calculerStatutAutomatique(f));

        try {
            String nomF = rs.getString("nom_formateur");
            f.setNomFormateur(nomF != null ? nomF : "Anonyme");
        } catch (SQLException e) {
            f.setNomFormateur("Non spécifié");
        }
        return f;
    }

    // ✅ Remplace ta méthode incrementerPlaces par celle-ci
    // ✅ COPIE CE CODE DANS ServicesFormations.java
    public boolean confirmerInscription(int idFormation, int idUser, double prixFormation) {
        // Requête 1 : Diminuer le solde du prix exact de la formation
        String sqlCandidat = "UPDATE candidat SET solde = solde - ? WHERE id_user = ? AND solde >= ?";

        // Requête 2 : Augmenter le nombre de participants
        String sqlFormation = "UPDATE formation SET nb_places_occupees = nb_places_occupees + 1 " +
                "WHERE id_formation = ? AND nb_places_occupees < nb_places";

        try {
            Connection cnx = MyDatabase.getInstance().getCnx();
            cnx.setAutoCommit(false); // 🔒 Début de la transaction sécurisée

            try (PreparedStatement pstC = cnx.prepareStatement(sqlCandidat);
                 PreparedStatement pstF = cnx.prepareStatement(sqlFormation)) {

                // Paramètres pour le débit du solde
                pstC.setDouble(1, prixFormation); // On soustrait le prix
                pstC.setInt(2, idUser);           // ID du candidat
                pstC.setDouble(3, prixFormation); // Vérification de sécurité (solde suffisant)
                int res1 = pstC.executeUpdate();

                // Paramètres pour la place de formation
                pstF.setInt(1, idFormation);
                int res2 = pstF.executeUpdate();

                if (res1 > 0 && res2 > 0) {
                    cnx.commit(); // ✅ Succès : l'argent est retiré et la place est prise
                    return true;
                } else {
                    cnx.rollback(); // ❌ Échec : on ne touche à rien
                    return false;
                }
            } catch (SQLException e) {
                cnx.rollback();
                throw e;
            } finally {
                cnx.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}