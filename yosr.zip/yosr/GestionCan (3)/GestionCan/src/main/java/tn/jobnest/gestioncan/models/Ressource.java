package tn.jobnest.gestioncan.models;

public class Ressource {
    private int idRessource;
    private int idModule;
    private String titre;
    private String type; // VIDEO, PDF, TEXTE, QUIZ
    private String valeurContenu;
    private int ordre;

    public Ressource(int idRessource, int idModule, String titre, String type, String valeurContenu, int ordre) {
        this.idRessource = idRessource;
        this.idModule = idModule;
        this.titre = titre;
        this.type = type;
        this.valeurContenu = valeurContenu;
        this.ordre = ordre;
    }

    // --- GETTERS (Indispensables pour le Contrôleur et le Service) ---

    public int getIdRessource() {
        return idRessource;
    }

    public int getIdModule() {
        return idModule;
    }

    public String getTitre() {
        return titre;
    }

    public String getType() {
        return type;
    }

    public String getValeurContenu() {
        return valeurContenu;
    }

    public int getOrdre() {
        return ordre;
    }

    // --- SETTERS (Optionnels mais recommandés) ---
    public void setIdRessource(int idRessource) { this.idRessource = idRessource; }
    public void setIdModule(int idModule) { this.idModule = idModule; }
    public void setTitre(String titre) { this.titre = titre; }
    public void setType(String type) { this.type = type; }
    public void setValeurContenu(String valeurContenu) { this.valeurContenu = valeurContenu; }
    public void setOrdre(int ordre) { this.ordre = ordre; }
}