package tn.jobnest.gestioncan.services;

import tn.jobnest.gestioncan.models.Module;
import tn.jobnest.gestioncan.utils.SessionManager; // ✅ Import pour l'ID statique

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ServiceModule {

    // On définit les accès ici pour ne pas dépendre du Singleton
    private final String URL = "jdbc:mysql://localhost:3306/jobnest";
    private final String USER = "root";
    private final String PWD = "";

    public List<Module> getModulesParFormation(int idFormation) {
        List<Module> liste = new ArrayList<>();

        // ✅ On récupère l'ID du candidat depuis le SessionManager
        int idCandidat = SessionManager.idCandidatConnecte;

        // ✅ REQUÊTE MODIFIÉE : On ajoute une sous-requête pour vérifier si le module est validé (score >= 66)
        String sql = "SELECT m.*, " +
                "(SELECT COUNT(*) FROM candidat_quizz cq " +
                " JOIN quizz q ON cq.id_quizz = q.id_quizz " +
                " JOIN ressource r ON q.id_ressource = r.id_ressource " +
                " WHERE r.id_module = m.id_module AND cq.id_candidat = ? AND cq.score >= 66) as est_valide " +
                "FROM module m WHERE m.id_formation = ? ORDER BY m.ordre ASC";

        // ✅ On ouvre une connexion NEUVE qui sera fermée automatiquement à la fin
        try (Connection cnx = DriverManager.getConnection(URL, USER, PWD);
             PreparedStatement ps = cnx.prepareStatement(sql)) {

            ps.setInt(1, idCandidat); // Premier paramètre (?) pour la sous-requête (id_candidat)
            ps.setInt(2, idFormation); // Deuxième paramètre (?) pour id_formation

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Module m = new Module(
                            rs.getInt("id_module"),
                            rs.getInt("id_formation"),
                            rs.getString("titre"),
                            rs.getInt("ordre"),
                            rs.getString("description"),
                            rs.getString("type")
                    );

                    // ✅ On marque le module comme terminé si la BDD confirme la réussite
                    boolean estValide = rs.getInt("est_valide") > 0;
                    m.setTermine(estValide);

                    liste.add(m);
                }
            }
            // Debug console pour vérifier si la BDD renvoie quelque chose
            System.out.println("✅ Modules chargés pour formation " + idFormation + " | Candidat: " + idCandidat + " | Total: " + liste.size());

        } catch (SQLException e) {
            System.err.println("❌ Erreur ServiceModule : " + e.getMessage());
        }
        return liste;
    }
}