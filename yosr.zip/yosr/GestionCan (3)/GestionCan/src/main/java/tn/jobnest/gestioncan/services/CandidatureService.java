package tn.jobnest.gestioncan.services;

import tn.jobnest.gestioncan.models.Candidature;
import tn.jobnest.gestioncan.models.DocumentCandidature;
import tn.jobnest.gestioncan.utils.MyDatabase;

import java.sql.*;
import java.util.*;

public class CandidatureService implements ICrud<Candidature> {

    private Connection cnx = MyDatabase.getInstance().getCnx();

    @Override
    public void ajouter(Candidature c) {
        String req = "INSERT INTO candidature (id_candidat, id_offre, message_complementaire, statut, date_candidature) VALUES (?, ?, ?, ?, NOW())";
        try (PreparedStatement ps = cnx.prepareStatement(req)) {
            ps.setInt(1, c.getIdCandidat());
            ps.setInt(2, c.getIdOffre());
            ps.setString(3, c.getMessageComplementaire());
            ps.setString(4, c.getStatut());
            ps.executeUpdate();
            System.out.println("✅ Candidature ajoutée !");
        } catch (SQLException e) {
            System.err.println("❌ Erreur ajout : " + e.getMessage());
        }
    }

    @Override
    public void modifier(Candidature c) {
        String req = "UPDATE candidature SET message_complementaire=?, statut=? WHERE id_candidature=?";
        try (PreparedStatement ps = cnx.prepareStatement(req)) {
            ps.setString(1, c.getMessageComplementaire());
            ps.setString(2, c.getStatut());
            ps.setInt(3, c.getIdCandidature());
            ps.executeUpdate();
            System.out.println("✅ Candidature modifiée !");
        } catch (SQLException e) {
            System.err.println("❌ Erreur modification : " + e.getMessage());
        }
    }

    @Override
    public void supprimer(int id) {
        String req = "DELETE FROM candidature WHERE id_candidature=?";
        try (PreparedStatement ps = cnx.prepareStatement(req)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("✅ Candidature supprimée !");
        } catch (SQLException e) {
            System.err.println("❌ Erreur suppression : " + e.getMessage());
        }
    }

    @Override
    public List<Candidature> afficher() {
        List<Candidature> list = new ArrayList<>();
        String req = "SELECT * FROM candidature";
        try (Statement st = cnx.createStatement(); ResultSet rs = st.executeQuery(req)) {
            while (rs.next()) {
                list.add(new Candidature(
                        rs.getInt("id_candidature"),
                        rs.getInt("id_candidat"),
                        rs.getInt("id_offre"),
                        rs.getString("message_complementaire"),
                        rs.getString("statut"),
                        rs.getTimestamp("date_candidature"),
                        rs.getInt("is_boosted")
                ));
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur affichage : " + e.getMessage());
        }
        return list;
    }

    @Override
    public Map<Integer, Candidature> getMap() {
        Map<Integer, Candidature> map = new HashMap<>();
        String req = "SELECT * FROM candidature";
        try (Statement st = cnx.createStatement(); ResultSet rs = st.executeQuery(req)) {
            while (rs.next()) {
                Candidature c = new Candidature(
                        rs.getInt("id_candidature"),
                        rs.getInt("id_candidat"),
                        rs.getInt("id_offre"),
                        rs.getString("message_complementaire"),
                        rs.getString("statut"),
                        rs.getTimestamp("date_candidature"),
                        rs.getInt("is_boosted")
                );
                map.put(c.getIdCandidature(), c);
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return map;
    }

    public List<Candidature> getHistoriqueCandidat(int idCandidat) {
        List<Candidature> list = new ArrayList<>();
        String req = "SELECT c.*, o.titre, o.entreprise FROM candidature c " +
                "JOIN offre_emploi o ON c.id_offre = o.id_offre WHERE c.id_candidat = ?";
        try (PreparedStatement ps = cnx.prepareStatement(req)) {
            ps.setInt(1, idCandidat);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Candidature c = new Candidature();
                c.setIdCandidature(rs.getInt("id_candidature"));
                c.setIdCandidat(rs.getInt("id_candidat"));
                c.setIdOffre(rs.getInt("id_offre"));
                c.setMessageComplementaire(rs.getString("message_complementaire"));
                c.setStatut(rs.getString("statut"));
                c.setDateCandidature(rs.getTimestamp("date_candidature"));
                c.setTitreOffre(rs.getString("titre"));
                c.setNomEntreprise(rs.getString("entreprise"));
                c.setIsBoosted(rs.getInt("is_boosted"));
                list.add(c);
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur historique : " + e.getMessage());
        }
        return list;
    }

    public boolean postuler(Candidature c, DocumentCandidature doc) {
        String reqCandidature = "INSERT INTO candidature (id_offre, id_candidat, message_complementaire, statut, date_candidature) VALUES (?, ?, ?, ?, NOW())";
        String reqDocument = "INSERT INTO document_candidature (id_candidature, nom_document, type_document, chemin_fichier) VALUES (?, ?, ?, ?)";
        try {
            cnx.setAutoCommit(false);
            PreparedStatement psC = cnx.prepareStatement(reqCandidature, Statement.RETURN_GENERATED_KEYS);
            psC.setInt(1, c.getIdOffre());
            psC.setInt(2, c.getIdCandidat());
            psC.setString(3, c.getMessageComplementaire());
            psC.setString(4, c.getStatut());
            psC.executeUpdate();

            ResultSet rs = psC.getGeneratedKeys();
            if (rs.next()) {
                int idGenere = rs.getInt(1);
                if (doc != null) {
                    PreparedStatement psD = cnx.prepareStatement(reqDocument);
                    psD.setInt(1, idGenere);
                    psD.setString(2, doc.getNomDocument());
                    psD.setString(3, doc.getTypeDocument());
                    psD.setString(4, doc.getCheminFichier());
                    psD.executeUpdate();
                }
            }
            cnx.commit();
            return true;
        } catch (SQLException e) {
            try { cnx.rollback(); } catch (SQLException ignored) {}
            return false;
        } finally {
            try { cnx.setAutoCommit(true); } catch (SQLException ignored) {}
        }
    }

    public Map<String, Integer> getEvolutionCandidatures(int userId) {
        Map<String, Integer> evolution = new LinkedHashMap<>();
        String req = "SELECT MONTHNAME(date_candidature) as mois, COUNT(*) as total FROM candidature " +
                "WHERE id_candidat = ? GROUP BY MONTH(date_candidature) ORDER BY date_candidature";
        try (PreparedStatement ps = cnx.prepareStatement(req)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                evolution.put(rs.getString("mois"), rs.getInt("total"));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return evolution;
    }
}