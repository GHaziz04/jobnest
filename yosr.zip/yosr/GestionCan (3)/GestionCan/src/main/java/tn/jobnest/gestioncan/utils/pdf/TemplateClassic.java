package tn.jobnest.gestioncan.utils.pdf;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.canvas.draw.SolidLine;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.*;
import com.itextpdf.layout.properties.TextAlignment;
import tn.jobnest.gestioncan.models.*;
import java.util.List;

public class TemplateClassic implements ICVGenerator {

    @Override
    public void generer(String dest, Candidat candidat, List<Experience> experiences,
                        List<Formation> formations, List<Competence> competences, List<Langue> langues) throws Exception {

        PdfWriter writer = new PdfWriter(dest);
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf); // Marges par défaut

        // 1. EN-TÊTE (Nom + Prénom)
        document.add(new Paragraph(candidat.getPrenom() + " " + candidat.getNom())
                .setTextAlignment(TextAlignment.CENTER)
                .setBold()
                .setFontSize(24)
                .setMarginBottom(5));

        // 2. CONTACT (Email | Tel | Ville)
        String contact = candidat.getEmail() + " | " + candidat.getTelephone();
        if (candidat.getVille() != null && !candidat.getVille().isEmpty()) {
            contact += " | " + candidat.getVille();
        }

        document.add(new Paragraph(contact)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontSize(10)
                .setMarginBottom(10));

        // Ligne de séparation
        document.add(new LineSeparator(new SolidLine(1f)).setMarginBottom(15));

        // 3. BIO (Si elle existe)
        if (candidat.getBio() != null && !candidat.getBio().isEmpty()) {
            document.add(new Paragraph("Profil").setBold().setFontSize(14));
            document.add(new Paragraph(candidat.getBio())
                    .setItalic()
                    .setMarginBottom(10));
        }

        // 4. EXPÉRIENCES PROFESSIONNELLES
        if (experiences != null && !experiences.isEmpty()) {
            document.add(new Paragraph("Expériences Professionnelles").setBold().setFontSize(14).setUnderline().setMarginTop(10));

            for (Experience exp : experiences) {
                // Formatage des dates (ex: 2020-01-01 - 2021-01-01)
                String dateStr = (exp.getDateDebut() != null ? exp.getDateDebut().toString() : "") +
                        " - " +
                        (exp.getDateFin() != null ? exp.getDateFin().toString() : "Présent");

                document.add(new Paragraph(exp.getPoste() + " chez " + exp.getEntreprise() + " (" + dateStr + ")")
                        .setBold()
                        .setFontSize(11));

                if (exp.getDescription() != null && !exp.getDescription().isEmpty()) {
                    document.add(new Paragraph(exp.getDescription())
                            .setItalic()
                            .setFontSize(10)
                            .setMarginLeft(15) // Petit retrait vers la droite
                            .setMarginBottom(5));
                }
            }
        }

        // 5. FORMATIONS
        if (formations != null && !formations.isEmpty()) {
            document.add(new Paragraph("Formations").setBold().setFontSize(14).setUnderline().setMarginTop(10));

            for (Formation form : formations) {
                document.add(new Paragraph(
                        form.getDiplome() + ", " + form.getEcole() +
                                " (" + form.getAnneeDebut() + " - " + form.getAnneeFin() + ")")
                        .setMarginBottom(2));
            }
        }

        // 6. COMPÉTENCES
        if (competences != null && !competences.isEmpty()) {
            document.add(new Paragraph("Compétences").setBold().setFontSize(14).setUnderline().setMarginTop(10));

            StringBuilder compStr = new StringBuilder();
            for (Competence c : competences) {
                compStr.append(c.getNom()).append(" • ");
            }
            // Enlever le dernier " • "
            String finalStr = compStr.length() > 3 ? compStr.substring(0, compStr.length() - 3) : compStr.toString();

            document.add(new Paragraph(finalStr).setMarginBottom(10));
        }

        // 7. LANGUES
        if (langues != null && !langues.isEmpty()) {
            document.add(new Paragraph("Langues").setBold().setFontSize(14).setUnderline().setMarginTop(10));

            for (Langue l : langues) {
                document.add(new Paragraph("• " + l.getNom() + " (" + l.getNiveau() + ")")
                        .setMarginLeft(10)
                        .setMarginBottom(0));
            }
        }

        document.close();
    }
}