package tn.jobnest.gestioncan.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;
import tn.jobnest.gestioncan.services.PaymentService;
import tn.jobnest.gestioncan.utils.MyDatabase;

import java.awt.Desktop;
import java.net.URI;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

public class WalletController {

    @FXML private Label lblSolde;
    @FXML private Button btnRecharger;

    private final PaymentService paymentService = new PaymentService();
    // ⚠️ ID Utilisateur : À récupérer dynamiquement plus tard
    private final int ID_USER = 1;
    private String currentSessionId;
    private double montantEnAttente;

    @FXML
    public void initialize() {
        rafraichirSolde();
    }

    @FXML
    private void onRechargerClicked() {
        TextInputDialog dialog = new TextInputDialog("50");
        dialog.setTitle("Recharger le compte");
        dialog.setHeaderText("Combien voulez-vous ajouter ?");
        dialog.setContentText("Montant (TND):");

        Optional<String> result = dialog.showAndWait();
        if (result.isPresent()) {
            try {
                double montant = Double.parseDouble(result.get());
                montantEnAttente = montant;

                // 1. Créer session Stripe
                String rawResponse = paymentService.creerSessionPaiement((long)(montant * 100), "client@email.com");
                String[] parts = rawResponse.split("###");
                String url = parts[0];
                currentSessionId = parts[1];

                // 2. Ouvrir navigateur
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().browse(new URI(url));
                }

                // 3. Attendre confirmation
                Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
                confirmAlert.setTitle("Paiement en cours");
                confirmAlert.setHeaderText("Action requise");
                confirmAlert.setContentText("Une fois le paiement terminé sur Stripe, cliquez sur OK.");

                confirmAlert.showAndWait().ifPresent(reponse -> verifierEtValider());

            } catch (Exception e) {
                afficherErreur("Erreur", "Impossible de lancer le paiement : " + e.getMessage());
            }
        }
    }

    private void verifierEtValider() {
        if (currentSessionId == null) return;

        if (paymentService.verifierPaiement(currentSessionId)) {
            // ✅ Mise à jour BDD (Table candidat)
            paymentService.ajouterSolde(ID_USER, montantEnAttente);

            afficherInfo("Succès", "Votre solde a été rechargé de " + montantEnAttente + " TND !");

            // ✅ CRUCIAL : On force l'interface à relire la BDD
            rafraichirSolde();
            currentSessionId = null;
        } else {
            afficherErreur("Échec", "Le paiement n'a pas été validé par Stripe.");
        }
    }

    /**
     * ✅ CORRECTION : Cette méthode va chercher la valeur réelle en BDD
     */
    private void rafraichirSolde() {
        String sql = "SELECT solde FROM candidat WHERE id_user = ?";
        try {
            Connection cnx = MyDatabase.getInstance().getCnx();
            try (PreparedStatement pst = cnx.prepareStatement(sql)) {
                pst.setInt(1, ID_USER);
                try (ResultSet rs = pst.executeQuery()) {
                    if (rs.next()) {
                        double soldeBDD = rs.getDouble("solde");
                        // Mise à jour du Label avec formatage
                        lblSolde.setText(String.format("%.2f TND", soldeBDD));
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur rafraîchirSolde : " + e.getMessage());
        }
    }

    private void afficherInfo(String titre, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.show();
    }

    private void afficherErreur(String titre, String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.show();
    }
}