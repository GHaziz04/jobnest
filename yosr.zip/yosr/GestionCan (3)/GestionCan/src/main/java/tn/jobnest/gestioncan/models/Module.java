package tn.jobnest.gestioncan.models;

import java.util.ArrayList;
import java.util.List;

public class Module {
    private int id_module;
    private int id_formation;
    private String titre;
    private int ordre;
    private String description;
    private String type;
    private List<Ressource> ressources;

    // ✅ État de progression (utilisé pour l'affichage des coches vertes)
    private boolean termine = false;

    // Constructeur complet
    public Module(int id_module, int id_formation, String titre, int ordre, String description, String type) {
        this.id_module = id_module;
        this.id_formation = id_formation;
        this.titre = titre;
        this.ordre = ordre;
        this.description = description;
        this.type = type;
        this.ressources = new ArrayList<>();
        this.termine = false;
    }

    // --- GETTERS ET SETTERS ---

    public int getId_module() { return id_module; }
    public void setId_module(int id_module) { this.id_module = id_module; }

    public int getId_formation() { return id_formation; }
    public void setId_formation(int id_formation) { this.id_formation = id_formation; }

    public String getTitre() { return titre; }
    public void setTitre(String titre) { this.titre = titre; }

    public int getOrdre() { return ordre; }
    public void setOrdre(int ordre) { this.ordre = ordre; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public List<Ressource> getRessources() { return ressources; }
    public void setRessources(List<Ressource> ressources) { this.ressources = ressources; }

    // ✅ Accesseurs pour la progression (Crucial pour ModulesFormationController)
    public boolean isTermine() {
        return termine;
    }

    public void setTermine(boolean termine) {
        this.termine = termine;
    }

    // Méthode utilitaire pour ajouter une ressource
    public void addRessource(Ressource r) {
        if (this.ressources == null) {
            this.ressources = new ArrayList<>();
        }
        this.ressources.add(r);
    }

    @Override
    public String toString() {
        return "Module{" +
                "id_module=" + id_module +
                ", titre='" + titre + '\'' +
                ", ordre=" + ordre +
                ", type='" + type + '\'' +
                ", termine=" + termine +
                '}';
    }
}