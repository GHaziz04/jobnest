package tn.jobnest.gestioncan.models;

public class Candidat {
    private int id;
    private String nom;
    private String prenom;
    private String email;
    private String telephone;
    private String ville;
    private String bio;

    // NOUVEL ATTRIBUT
    private String image;

    // Constructeur vide (Utile pour créer un objet vide puis utiliser les setters)
    public Candidat() {
    }

    // Constructeur complet (Lecture BDD)
    public Candidat(int id, String nom, String prenom, String email, String telephone, String ville, String bio, String image) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.telephone = telephone;
        this.ville = ville;
        this.bio = bio;
        this.image = image;
    }

    // --- GETTERS & SETTERS ---

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }

    public String getPrenom() { return prenom; }
    public void setPrenom(String prenom) { this.prenom = prenom; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getTelephone() { return telephone; }
    public void setTelephone(String telephone) { this.telephone = telephone; }

    public String getVille() { return ville; }
    public void setVille(String ville) { this.ville = ville; }

    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }

    // --- NOUVEAUX GETTER/SETTER POUR L'IMAGE ---
    public String getImage() { return image; }
    public void setImage(String image) { this.image = image; }

    @Override
    public String toString() {
        return nom + " " + prenom;
    }
}