package tn.jobnest.gestioncan.controllers;

import javafx.animation.*;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;
import tn.jobnest.gestioncan.models.Entretien;
import tn.jobnest.gestioncan.models.NotificationCandidat;
import tn.jobnest.gestioncan.services.EntretienCandidatService;
import tn.jobnest.gestioncan.services.NotificationCandidatService;
import tn.jobnest.gestioncan.utils.NavigationService;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class EntretienCandidatController {

    // ── FXML — vue principale ─────────────────────────────────────────
    @FXML private VBox       entretiensVBox;
    @FXML private TextField  searchField;
    @FXML private Label      totalCount;
    @FXML private Label      prochainCount;

    // ── FXML — cloche et badge ────────────────────────────────────────
    @FXML private Label  notifBadgeLabel;
    @FXML private Button btnNotifications;

    // ── fx:include — convention JavaFX : fx:id="notifInclude"
    //    → nœud   injecté sous @FXML Node notifInclude
    //    → ctrl   injecté sous @FXML NotificationCandidatPanelController notifIncludeController
    @FXML private Node                                 notifInclude;
    @FXML private NotificationCandidatPanelController  notifIncludeController;

    // ── Services ──────────────────────────────────────────────────────
    private final EntretienCandidatService    service      = new EntretienCandidatService();
    private final NotificationCandidatService notifService = NotificationCandidatService.getInstance();

    private List<Entretien> entretiensActifs;
    private final int currentCandidatId = 1; // ← ID candidat connecté
    private boolean   panelVisible      = false;

    // ════════════════════════════════════════════════════════════════
    //  INITIALISATION
    //  ORDRE CRITIQUE :
    //   1. Listeners UI
    //   2. Cacher panneau notifs
    //   3. Enregistrer callback AVANT le chargement des données
    //   4. Charger données (déclenche planification rappels)
    //   5. Mettre à jour badge initial
    // ════════════════════════════════════════════════════════════════
    @FXML
    public void initialize() {
        // 1. Listener recherche
        searchField.textProperty().addListener((obs, old, newVal) -> filterAndDisplay());

        // 2. Panneau caché au départ
        masquerPanneau();

        // 3. Callback notif — AVANT le chargement
        notifService.setOnNewNotification(notif -> {
            // Déjà sur le JavaFX thread (Platform.runLater dans le service)
            afficherToast(notif);
            updateBadge();
            if (panelVisible && notifIncludeController != null) {
                notifIncludeController.charger();
            }
        });

        // 4. Chargement asynchrone
        chargerDonneesAsync();

        // 5. Badge initial
        updateBadge();
    }

    // ════════════════════════════════════════════════════════════════
    //  CHARGEMENT ASYNCHRONE
    // ════════════════════════════════════════════════════════════════
    private void chargerDonneesAsync() {
        Thread loader = new Thread(() -> {
            try {
                // Annuler les entretiens expirés PUIS détecter les annulations
                verifierEtMettreAJourStatutsSync();
                notifService.detecterEtNotifierAnnulations(currentCandidatId, service);

                List<Entretien> actifs = service.getEntretiensActifs(currentCandidatId);

                // Planifier les rappels 24h et 1h
                notifService.planifierRappels(actifs);

                Platform.runLater(() -> {
                    entretiensActifs = actifs;
                    updateStats();
                    filterAndDisplay();
                    updateBadge();
                });

            } catch (SQLException ex) {
                Platform.runLater(() ->
                        showAlert(Alert.AlertType.ERROR, "Erreur",
                                "Impossible de charger vos entretiens : " + ex.getMessage()));
            }
        });
        loader.setDaemon(true);
        loader.setName("jobnest-candidat-loader");
        loader.start();
    }

    /** Version synchrone (appelée depuis le thread de fond) */
    private void verifierEtMettreAJourStatutsSync() {
        try {
            List<Entretien> tousLesEntretiens = service.getEntretiensByCandidat(currentCandidatId);
            LocalDate aujourdhui = LocalDate.now();
            for (Entretien e : tousLesEntretiens) {
                if ("proposé".equals(e.getStatut()) && e.getDateEntretien() != null) {
                    LocalDate dateEntretien = e.getDateEntretien().toLocalDate();
                    if (dateEntretien.isBefore(aujourdhui)) {
                        try {
                            service.mettreAJourStatut(e.getIdEntretien(), "annulé");
                        } catch (SQLException ex) {
                            System.err.println("❌ Erreur statut entretien #" + e.getIdEntretien());
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            System.err.println("❌ Erreur vérification statuts : " + ex.getMessage());
        }
    }

    @FXML
    private void rafraichirListe() {
        chargerDonneesAsync();
    }

    // ════════════════════════════════════════════════════════════════
    //  CLOCHE — TOGGLE PANNEAU NOTIFICATIONS
    // ════════════════════════════════════════════════════════════════
    @FXML
    private void toggleNotificationPanel() {
        if (notifInclude == null) {
            System.err.println("[NotifCandidat] notifInclude est null — vérifiez fx:id dans le FXML");
            return;
        }
        if (!panelVisible) ouvrirPanneau();
        else               fermerPanneau();
    }

    private void ouvrirPanneau() {
        notifInclude.setVisible(true);
        notifInclude.setManaged(true);
        panelVisible = true;

        notifInclude.setOpacity(0);
        notifInclude.setTranslateX(30);
        FadeTransition      fade  = new FadeTransition(Duration.millis(220), notifInclude);
        fade.setToValue(1);
        TranslateTransition slide = new TranslateTransition(Duration.millis(220), notifInclude);
        slide.setToX(0);
        new ParallelTransition(fade, slide).play();

        if (notifIncludeController != null) notifIncludeController.charger();
        updateBadge();
    }

    private void fermerPanneau() {
        FadeTransition      fade  = new FadeTransition(Duration.millis(180), notifInclude);
        fade.setToValue(0);
        TranslateTransition slide = new TranslateTransition(Duration.millis(180), notifInclude);
        slide.setToX(30);
        ParallelTransition anim = new ParallelTransition(fade, slide);
        anim.setOnFinished(e -> masquerPanneau());
        anim.play();
        panelVisible = false;
    }

    private void masquerPanneau() {
        if (notifInclude != null) {
            notifInclude.setVisible(false);
            notifInclude.setManaged(false);
        }
    }

    // ── Badge ─────────────────────────────────────────────────────────
    private void updateBadge() {
        if (notifBadgeLabel == null) return;
        Thread t = new Thread(() -> {
            try {
                int count = notifService.countNonLues(currentCandidatId);
                Platform.runLater(() -> {
                    if (count > 0) {
                        notifBadgeLabel.setText(count > 9 ? "9+" : String.valueOf(count));
                        notifBadgeLabel.setVisible(true);
                        notifBadgeLabel.setManaged(true);
                        ScaleTransition pulse = new ScaleTransition(Duration.millis(200), notifBadgeLabel);
                        pulse.setFromX(1); pulse.setFromY(1);
                        pulse.setToX(1.35); pulse.setToY(1.35);
                        pulse.setAutoReverse(true);
                        pulse.setCycleCount(2);
                        pulse.play();
                    } else {
                        notifBadgeLabel.setVisible(false);
                        notifBadgeLabel.setManaged(false);
                    }
                });
            } catch (SQLException e) {
                System.err.println("[BadgeCandidat] Erreur : " + e.getMessage());
            }
        });
        t.setDaemon(true);
        t.start();
    }

    // ── Toast ─────────────────────────────────────────────────────────
    private void afficherToast(NotificationCandidat notif) {
        try {
            if (entretiensVBox.getScene() != null) {
                Stage stage = (Stage) entretiensVBox.getScene().getWindow();
                NotificationCandidatToast.show(stage, notif);
            }
        } catch (Exception e) {
            System.err.println("[ToastCandidat] Impossible d'afficher : " + e.getMessage());
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  STATISTIQUES
    // ════════════════════════════════════════════════════════════════
    private void updateStats() {
        if (entretiensActifs == null) return;
        totalCount.setText(String.valueOf(entretiensActifs.size()));
        prochainCount.setText(String.valueOf(entretiensActifs.size()));
    }

    // ════════════════════════════════════════════════════════════════
    //  FILTRE + AFFICHAGE
    // ════════════════════════════════════════════════════════════════
    private void filterAndDisplay() {
        if (entretiensActifs == null || entretiensActifs.isEmpty()) {
            entretiensVBox.getChildren().clear();
            VBox emptyBox = new VBox(15);
            emptyBox.setAlignment(Pos.CENTER);
            emptyBox.setPadding(new Insets(50));
            Label emptyIcon  = new Label("📭");
            emptyIcon.setStyle("-fx-font-size: 64px;");
            Label emptyLabel = new Label("Aucun entretien à venir");
            emptyLabel.setStyle("-fx-font-size: 18px; -fx-text-fill: #64748B; -fx-font-weight: bold;");
            Label emptySub   = new Label("Vos prochains entretiens apparaîtront ici");
            emptySub.setStyle("-fx-font-size: 14px; -fx-text-fill: #94A3B8;");
            emptyBox.getChildren().addAll(emptyIcon, emptyLabel, emptySub);
            entretiensVBox.getChildren().add(emptyBox);
            return;
        }

        String search = searchField.getText().trim().toLowerCase();
        entretiensVBox.getChildren().clear();

        for (Entretien e : entretiensActifs) {
            try {
                String titreOffre   = service.getOffreTitre(e.getIdOffre()).toLowerCase();
                String recruteurNom = service.getRecruteurNom(e.getIdRecruteur()).toLowerCase();
                boolean match = search.isEmpty()
                        || titreOffre.contains(search)
                        || recruteurNom.contains(search);
                if (match) entretiensVBox.getChildren().add(createEntretienCard(e));
            } catch (SQLException ex) {
                System.err.println("Erreur entretien #" + e.getIdEntretien());
            }
        }

        if (entretiensVBox.getChildren().isEmpty()) {
            Label emptyLabel = new Label("🔍 Aucun entretien ne correspond à votre recherche");
            emptyLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #64748B; -fx-padding: 50;");
            entretiensVBox.getChildren().add(emptyLabel);
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  CARTE ENTRETIEN  (inchangée)
    // ════════════════════════════════════════════════════════════════
    private Node createEntretienCard(Entretien e) {
        HBox card = new HBox(15);
        card.getStyleClass().add("card");
        card.setPrefHeight(160);
        card.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-background-radius: 12; "
                + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 10, 0, 0, 3);");

        try {
            Circle avatar = new Circle(30);
            avatar.setStyle("-fx-fill: #f59e0b;");
            Label avatarLabel = new Label("⏳");
            avatarLabel.setStyle("-fx-font-size: 24px; -fx-text-fill: white;");
            StackPane avatarStack = new StackPane();
            avatarStack.getChildren().addAll(avatar, avatarLabel);
            VBox avatarBox = new VBox(avatarStack);
            avatarBox.setAlignment(Pos.CENTER);
            avatarBox.setPrefWidth(80);

            VBox details = new VBox(8);
            details.setPrefWidth(500);
            HBox.setHgrow(details, Priority.ALWAYS);

            String titreOffre = service.getOffreTitre(e.getIdOffre());
            Label offreLabel = new Label("💼 " + titreOffre);
            offreLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #1E293B;");

            String recruteurNom = service.getRecruteurNom(e.getIdRecruteur());
            Label recruteurLabel = new Label("👨‍💼 " + recruteurNom);
            recruteurLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #475569; -fx-font-weight: 500;");

            String dateStr = (e.getDateEntretien() != null)
                    ? e.getDateEntretien().toLocalDate()
                    .format(DateTimeFormatter.ofPattern("EEEE dd MMMM yyyy"))
                    : "Date non définie";
            String heureStr = (e.getHeureDebut() != null && e.getHeureFin() != null)
                    ? e.getHeureDebut().toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))
                    + " - " + e.getHeureFin().toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))
                    : "Horaire non défini";
            long duree = calculateDuration(e);
            String dureeTxt = (duree > 0) ? " (" + duree + " min)" : "";
            Label dateTimeLabel = new Label("📅 " + dateStr + " | 🕐 " + heureStr + dureeTxt);
            dateTimeLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: #64748B;");

            Label lieuVisioLabel;
            if ("présentiel".equals(e.getTypeEntretien())) {
                String lieu = (e.getLieu() != null && !e.getLieu().isEmpty()) ? e.getLieu() : "Lieu non défini";
                lieuVisioLabel = new Label("📍 " + lieu);
                lieuVisioLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: #1e2a78; -fx-font-weight: 500;");
            } else {
                String lien = (e.getLienVisio() != null && !e.getLienVisio().isEmpty()) ? e.getLienVisio() : "Lien non défini";
                if (lien.length() > 40) lien = lien.substring(0, 37) + "...";
                lieuVisioLabel = new Label("🔗 " + lien);
                lieuVisioLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: #3498db; -fx-font-weight: 500;");
            }

            Label statutBadge = new Label("📨 Proposé");
            statutBadge.setStyle("-fx-background-color: #f59e0b; -fx-text-fill: white; "
                    + "-fx-padding: 4 12; -fx-background-radius: 12; "
                    + "-fx-font-size: 12px; -fx-font-weight: bold;");

            details.getChildren().addAll(offreLabel, recruteurLabel, dateTimeLabel, lieuVisioLabel, statutBadge);

            VBox actionsBox = new VBox(10);
            actionsBox.setAlignment(Pos.CENTER_RIGHT);
            actionsBox.setPrefWidth(200);

            Button btnDetails = new Button("📋 Détails");
            btnDetails.setStyle("-fx-background-color: #1e2a78; -fx-text-fill: white; "
                    + "-fx-font-weight: bold; -fx-background-radius: 6; "
                    + "-fx-padding: 10 20; -fx-cursor: hand;");
            btnDetails.setPrefWidth(180);
            btnDetails.setOnAction(ev -> afficherDetails(e));

            Button btnAction = null;
            if ("visio".equals(e.getTypeEntretien())
                    && e.getLienVisio() != null && !e.getLienVisio().isBlank()) {
                btnAction = new Button("🎥 Rejoindre");
                btnAction.setStyle("-fx-background-color: #D69E7D; -fx-text-fill: white; "
                        + "-fx-font-weight: bold; -fx-background-radius: 6; "
                        + "-fx-padding: 10 20; -fx-cursor: hand;");
                btnAction.setPrefWidth(180);
                if (e.getDateEntretien() != null
                        && !e.getDateEntretien().toLocalDate().equals(LocalDate.now())) {
                    btnAction.setDisable(true);
                    btnAction.setText("⏳ Disponible le "
                            + e.getDateEntretien().toLocalDate()
                            .format(DateTimeFormatter.ofPattern("dd/MM")));
                    btnAction.setStyle("-fx-background-color: #94A3B8; -fx-text-fill: white; "
                            + "-fx-font-weight: bold; -fx-background-radius: 6; -fx-padding: 10 20;");
                }
                Button finalBtnAction = btnAction;
                btnAction.setOnAction(ev -> rejoindreVisio(e, finalBtnAction));

            } else if ("présentiel".equals(e.getTypeEntretien())) {
                btnAction = new Button("📍 Itinéraire");
                btnAction.setStyle("-fx-background-color: #10b981; -fx-text-fill: white; "
                        + "-fx-font-weight: bold; -fx-background-radius: 6; "
                        + "-fx-padding: 10 20; -fx-cursor: hand;");
                btnAction.setPrefWidth(180);
                if (e.getDateEntretien() != null
                        && !e.getDateEntretien().toLocalDate().equals(LocalDate.now())) {
                    btnAction.setDisable(true);
                    btnAction.setText("⏳ Disponible le "
                            + e.getDateEntretien().toLocalDate()
                            .format(DateTimeFormatter.ofPattern("dd/MM")));
                    btnAction.setStyle("-fx-background-color: #94A3B8; -fx-text-fill: white; "
                            + "-fx-font-weight: bold; -fx-background-radius: 6; -fx-padding: 10 20;");
                }
                btnAction.setOnAction(ev -> consulterItineraire(e));
            }

            actionsBox.getChildren().add(btnDetails);
            if (btnAction != null) actionsBox.getChildren().add(btnAction);

            card.getChildren().addAll(avatarBox, details, actionsBox);

        } catch (SQLException ex) {
            System.err.println("Erreur création card : " + ex.getMessage());
        }
        return card;
    }

    // ════════════════════════════════════════════════════════════════
    //  ACTIONS ENTRETIEN  (inchangées)
    // ════════════════════════════════════════════════════════════════
    private long calculateDuration(Entretien e) {
        if (e.getHeureDebut() == null || e.getHeureFin() == null) return 0;
        return TimeUnit.MILLISECONDS.toMinutes(
                e.getHeureFin().getTime() - e.getHeureDebut().getTime());
    }

    private void afficherDetails(Entretien e) {
        try {
            Dialog<ButtonType> dialog = new Dialog<>();
            dialog.setTitle("Détails de l'entretien");
            dialog.setHeaderText(null);
            DialogPane dialogPane = dialog.getDialogPane();

            VBox content = new VBox(20);
            content.setPadding(new Insets(20));

            HBox headerBox = new HBox(15);
            headerBox.setAlignment(Pos.CENTER_LEFT);
            Label iconLabel = new Label("⏳");
            iconLabel.setStyle("-fx-font-size: 32px;");

            VBox titleBox = new VBox(5);
            Label offreLabel = new Label(service.getOffreTitre(e.getIdOffre()));
            offreLabel.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: #1E293B;");
            offreLabel.setWrapText(true);
            Label statutLabel = new Label("📨 Proposé");
            statutLabel.setStyle("-fx-background-color: #f59e0b; -fx-text-fill: white; "
                    + "-fx-padding: 4 12; -fx-background-radius: 12; "
                    + "-fx-font-size: 12px; -fx-font-weight: bold;");
            titleBox.getChildren().addAll(offreLabel, statutLabel);
            headerBox.getChildren().addAll(iconLabel, titleBox);

            VBox infoBox = new VBox(15);
            infoBox.setStyle("-fx-background-color: #F8FAFC; -fx-padding: 20; -fx-background-radius: 8;");

            Label recruteurInfo = new Label("👨‍💼 Recruteur : " + service.getRecruteurNom(e.getIdRecruteur()));
            recruteurInfo.setStyle("-fx-font-size: 14px; -fx-text-fill: #475569;");

            String dateStr = (e.getDateEntretien() != null)
                    ? e.getDateEntretien().toLocalDate()
                    .format(DateTimeFormatter.ofPattern("EEEE dd MMMM yyyy"))
                    : "Non définie";
            Label dateInfo = new Label("📅 Date : " + dateStr);
            dateInfo.setStyle("-fx-font-size: 14px; -fx-text-fill: #475569;");

            String heureStr = (e.getHeureDebut() != null && e.getHeureFin() != null)
                    ? e.getHeureDebut().toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))
                    + " - " + e.getHeureFin().toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))
                    : "Non défini";
            Label heureInfo = new Label("🕐 Horaire : " + heureStr);
            heureInfo.setStyle("-fx-font-size: 14px; -fx-text-fill: #475569;");

            infoBox.getChildren().addAll(recruteurInfo, dateInfo, heureInfo);

            if ("présentiel".equals(e.getTypeEntretien())) {
                String lieu = (e.getLieu() != null && !e.getLieu().isEmpty()) ? e.getLieu() : "Non défini";
                Label lieuInfo = new Label("📍 Lieu : " + lieu);
                lieuInfo.setStyle("-fx-font-size: 14px; -fx-text-fill: #475569;");
                lieuInfo.setWrapText(true);
                infoBox.getChildren().add(lieuInfo);
            } else {
                String lien = (e.getLienVisio() != null && !e.getLienVisio().isEmpty())
                        ? e.getLienVisio() : "Non défini";
                Hyperlink lienInfo = new Hyperlink("🔗 Lien visio : " + lien);
                lienInfo.setStyle("-fx-font-size: 14px; -fx-text-fill: #3498db;");
                lienInfo.setWrapText(true);
                if (e.getLienVisio() != null && !e.getLienVisio().isEmpty()) {
                    lienInfo.setOnAction(ev -> {
                        try { Desktop.getDesktop().browse(new URI(e.getLienVisio())); }
                        catch (Exception ex) {
                            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible d'ouvrir le lien");
                        }
                    });
                }
                infoBox.getChildren().add(lienInfo);
            }

            if (e.getNoteRecruteur() != null && !e.getNoteRecruteur().isEmpty()) {
                VBox noteBox = new VBox(10);
                noteBox.setStyle("-fx-background-color: #FEF3C7; -fx-padding: 15; -fx-background-radius: 8;");
                Label noteTitle = new Label("📝 Note du recruteur");
                noteTitle.setStyle("-fx-font-weight: bold; -fx-text-fill: #854D0E;");
                Label noteContent = new Label(e.getNoteRecruteur());
                noteContent.setStyle("-fx-text-fill: #854D0E;");
                noteContent.setWrapText(true);
                noteBox.getChildren().addAll(noteTitle, noteContent);
                infoBox.getChildren().add(noteBox);
            }

            content.getChildren().addAll(headerBox, infoBox);
            dialogPane.setContent(content);
            dialogPane.getButtonTypes().add(
                    new ButtonType("Fermer", ButtonBar.ButtonData.CANCEL_CLOSE));
            dialog.showAndWait();

        } catch (SQLException ex) {
            showAlert(Alert.AlertType.ERROR, "Erreur",
                    "Impossible de charger les détails : " + ex.getMessage());
        }
    }

    private void rejoindreVisio(Entretien e, Button btn) {
        if (e.getDateEntretien() != null
                && !e.getDateEntretien().toLocalDate().equals(LocalDate.now())) {
            showAlert(Alert.AlertType.WARNING, "Accès refusé",
                    "Vous ne pouvez rejoindre la visioconférence que le jour de l'entretien.\n\n"
                            + "Date prévue : " + e.getDateEntretien().toLocalDate()
                            .format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
            return;
        }
        if (e.getLienVisio() != null && !e.getLienVisio().isBlank()) {
            try {
                Desktop.getDesktop().browse(new URI(e.getLienVisio()));
                marquerEntretienRealise(e);
            } catch (Exception ex) {
                showAlert(Alert.AlertType.ERROR, "Erreur",
                        "Impossible d'ouvrir le lien : " + ex.getMessage());
            }
        }
    }

    private void consulterItineraire(Entretien e) {
        if (e.getDateEntretien() != null
                && !e.getDateEntretien().toLocalDate().equals(LocalDate.now())) {
            showAlert(Alert.AlertType.WARNING, "Accès refusé",
                    "Vous ne pouvez consulter l'itinéraire que le jour de l'entretien.\n\n"
                            + "Date prévue : " + e.getDateEntretien().toLocalDate()
                            .format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
            return;
        }
        if (e.getLieu() == null || e.getLieu().isBlank()) {
            showAlert(Alert.AlertType.WARNING, "Adresse manquante",
                    "Aucune adresse n'est définie pour cet entretien présentiel.");
            return;
        }
        try {
            String titreOffre = service.getOffreTitre(e.getIdOffre());
            java.net.URL fxmlUrl = getClass().getResource("/View/map-candidat-view.fxml");
            if (fxmlUrl == null) {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Fichier FXML introuvable !");
                return;
            }
            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            javafx.scene.Parent root = loader.load();
            MapCandidatController mapCtrl = loader.getController();
            mapCtrl.setAdresse(e.getLieu(), "📅 " + titreOffre);
            javafx.stage.Stage mapStage = new javafx.stage.Stage();
            mapStage.setTitle("JobNest – Mon itinéraire : " + e.getLieu());
            mapStage.setScene(new javafx.scene.Scene(root));
            mapStage.setMinWidth(700);
            mapStage.setMinHeight(500);
            mapStage.setWidth(960);
            mapStage.setHeight(680);
            mapStage.centerOnScreen();
            mapStage.show();
            marquerEntretienRealise(e);
        } catch (Exception ex) {
            showAlert(Alert.AlertType.ERROR, "Erreur",
                    "Impossible d'ouvrir la carte : " + ex.getMessage());
        }
    }

    private void marquerEntretienRealise(Entretien e) {
        try {
            if (!"réalisé".equals(e.getStatut())) {
                service.mettreAJourStatut(e.getIdEntretien(), "réalisé");
                rafraichirListe();
                showAlert(Alert.AlertType.INFORMATION, "Succès",
                        "Félicitations ! Votre entretien a été marqué comme réalisé.");
            }
        } catch (SQLException ex) {
            showAlert(Alert.AlertType.ERROR, "Erreur",
                    "Impossible de mettre à jour le statut : " + ex.getMessage());
        }
    }

    @FXML
    private void ouvrirHistorique() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/View/HistoriqueEntretien.fxml"));
            Node node = loader.load();
            HistoriqueEntretienController controller = loader.getController();
            controller.setIdCandidat(currentCandidatId);
            NavigationService.loadContent(node);
        } catch (IOException ex) {
            showAlert(Alert.AlertType.ERROR, "Erreur",
                    "Impossible d'ouvrir l'historique : " + ex.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}