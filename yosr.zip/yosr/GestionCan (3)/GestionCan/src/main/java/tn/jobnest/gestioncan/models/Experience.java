package tn.jobnest.gestioncan.models;

import java.sql.Date;

public class Experience {
    private int id;
    private int idCandidat;
    private String poste;
    private String entreprise;
    private Date dateDebut;
    private Date dateFin;
    private String description;

    // Constructeur complet
    public Experience(int id, int idCandidat, String poste, String entreprise, Date dateDebut, Date dateFin, String description) {
        this.id = id;
        this.idCandidat = idCandidat;
        this.poste = poste;
        this.entreprise = entreprise;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
        this.description = description;
    }

    // Constructeur sans ID
    public Experience(int idCandidat, String poste, String entreprise, Date dateDebut, Date dateFin, String description) {
        this.idCandidat = idCandidat;
        this.poste = poste;
        this.entreprise = entreprise;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
        this.description = description;
    }

    public int getId() { return id; }
    public int getIdCandidat() { return idCandidat; }
    public String getPoste() { return poste; }
    public String getEntreprise() { return entreprise; }
    public Date getDateDebut() { return dateDebut; }
    public Date getDateFin() { return dateFin; }
    public String getDescription() { return description; }

    // IMPORTANT pour la ListView
    @Override
    public String toString() {
        return poste + " chez " + entreprise;
    }
}
