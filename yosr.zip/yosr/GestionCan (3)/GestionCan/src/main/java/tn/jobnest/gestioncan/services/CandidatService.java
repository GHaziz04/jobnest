package tn.jobnest.gestioncan.services;

import tn.jobnest.gestioncan.models.Candidat;
import tn.jobnest.gestioncan.utils.MyDatabase;

import java.sql.*;
import java.util.List;
import java.util.Map;

public class CandidatService implements ICrud<Candidat> {

    private Connection cnx = MyDatabase.getInstance().getCnx();

    // Récupérer un candidat par son ID (pour pré-remplir les champs)
    public Candidat getById(int id) {
        // Assure-toi que ta colonne ID s'appelle bien 'id_user' dans ta base
        String req = "SELECT * FROM candidat WHERE id_user = ?";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // On utilise le nouveau constructeur qui inclut l'image
                // ATTENTION : Vérifie que la colonne dans ta base s'appelle bien "image"
                return new Candidat(
                        rs.getInt("id_user"),
                        rs.getString("nom"),
                        rs.getString("prenom"),
                        rs.getString("email"),
                        rs.getString("telephone"),
                        rs.getString("ville"),
                        rs.getString("bio"),
                        rs.getString("image") // <--- AJOUT ICI (Récupération du chemin)
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void modifier(Candidat c) {
        // J'ai ajouté "image=?" dans la requête pour sauvegarder la photo si elle change
        String req = "UPDATE candidat SET nom=?, prenom=?, email=?, telephone=?, ville=?, bio=?, image=? WHERE id_user=?";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setString(1, c.getNom());
            ps.setString(2, c.getPrenom());
            ps.setString(3, c.getEmail());
            ps.setString(4, c.getTelephone());
            ps.setString(5, c.getVille());
            ps.setString(6, c.getBio());

            // Ajout de l'image (si null, on peut mettre null ou une chaine vide selon ta logique BDD)
            ps.setString(7, c.getImage());

            ps.setInt(8, c.getId()); // L'ID est maintenant le 8ème paramètre

            ps.executeUpdate();
            System.out.println("Candidat mis à jour avec succès !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void activerBoost(int idCandidat, int prix) {
        int jours = (prix == 50) ? 90 : (prix == 30) ? 45 : 28;
        String sql = "UPDATE candidat SET boost_expiration = DATE_ADD(NOW(), INTERVAL ? DAY) WHERE id_user = ?";

        try (Connection cnx = MyDatabase.getInstance().getCnx();
             PreparedStatement pst = cnx.prepareStatement(sql)) {
            pst.setInt(1, jours);
            pst.setInt(2, idCandidat);
            pst.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }public void modifierSoldeBoost(int idUser, int quantite) {
        // quantite peut être positive (achat) ou négative (utilisation)
        String sql = "UPDATE candidat SET nb_boosts_restants = nb_boosts_restants + ? WHERE id_user = ?";

        try (Connection cnx = MyDatabase.getInstance().getCnx();
             PreparedStatement pst = cnx.prepareStatement(sql)) {

            pst.setInt(1, quantite);
            pst.setInt(2, idUser);
            pst.executeUpdate();

            System.out.println("✅ Solde mis à jour : " + quantite);
        } catch (SQLException e) {
            System.err.println("❌ Erreur mise à jour solde : " + e.getMessage());
        }
    }
    public void debiterSolde(int idUser, double montant) {
        // On soustrait le montant du solde actuel
        String sql = "UPDATE candidat SET solde = solde - ? WHERE id_user = ?";

        try (Connection cnx = MyDatabase.getInstance().getCnx();
             PreparedStatement pst = cnx.prepareStatement(sql)) {

            pst.setDouble(1, montant);
            pst.setInt(2, idUser);
            pst.executeUpdate();

            System.out.println("✅ " + montant + " TND débités du solde.");
        } catch (SQLException e) {
            System.err.println("❌ Erreur débit solde : " + e.getMessage());
        }
    }

    // Méthodes non utilisées pour l'instant (laissées telles quelles)
    @Override public void ajouter(Candidat c) {}
    @Override public void supprimer(int id) {}
    @Override public List<Candidat> afficher() { return null; }
    @Override public Map<Integer, Candidat> getMap() { return null; }
}