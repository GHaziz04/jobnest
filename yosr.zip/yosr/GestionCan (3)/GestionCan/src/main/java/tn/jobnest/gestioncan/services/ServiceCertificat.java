package tn.jobnest.gestioncan.services;

import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;
import tn.jobnest.gestioncan.utils.MyDatabase;
import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.stream.Collectors;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServiceCertificat {

    public String getNomCandidat(int idUser) {
        String nomComplet = "Candidat";
        String sql = "SELECT nom, prenom FROM candidat WHERE id_user = ?";
        try {
            Connection cnx = MyDatabase.getInstance().getCnx();
            try (PreparedStatement ps = cnx.prepareStatement(sql)) {
                ps.setInt(1, idUser);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        String prenom = rs.getString("prenom");
                        String nom = rs.getString("nom");
                        nomComplet = (prenom != null ? prenom : "") + " " + (nom != null ? nom : "");
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur SQL Nom : " + e.getMessage());
        }
        return nomComplet.trim().isEmpty() ? "Candidat" : nomComplet.trim();
    }

    private int getScoreMoyenFormation(int idUser, int idFormation) {
        int moyenne = 0;
        String sql = "SELECT AVG(cq.score) as moyenne FROM candidat_quizz cq " +
                "JOIN quizz q ON cq.id_quizz = q.id_quizz " +
                "JOIN ressource r ON q.id_ressource = r.id_ressource " +
                "JOIN module m ON r.id_module = m.id_module " +
                "WHERE cq.id_candidat = ? AND m.id_formation = ?";
        try {
            Connection cnx = MyDatabase.getInstance().getCnx();
            try (PreparedStatement ps = cnx.prepareStatement(sql)) {
                ps.setInt(1, idUser);
                ps.setInt(2, idFormation);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) moyenne = rs.getInt("moyenne");
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur SQL Score : " + e.getMessage());
        }
        return moyenne;
    }

    private String escapeXml(String input) {
        if (input == null) return "";
        return input.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }

    public void genererPDF(int idUser, int idFormation, String titreFormation, String destinationPath) {
        // ✅ C'EST ICI : On désactive les messages INFO pour nettoyer la console
        Logger.getLogger("com.openhtmltopdf").setLevel(Level.WARNING);

        File file = new File(destinationPath);
        if (file.getParentFile() != null) {
            file.getParentFile().mkdirs();
        }

        try (OutputStream os = new FileOutputStream(file)) {
            String nomCandidat = getNomCandidat(idUser);
            int scoreMoyen = getScoreMoyenFormation(idUser, idFormation);

            String content;
            try (InputStream is = getClass().getClassLoader().getResourceAsStream("certificat.html")) {
                if (is == null) throw new IOException("Template introuvable");
                content = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))
                        .lines().collect(Collectors.joining("\n"));
            }

            content = content.replace("{{NOM_CANDIDAT}}", escapeXml(nomCandidat))
                    .replace("{{TITRE_FORMATION}}", escapeXml(titreFormation))
                    .replace("{{SCORE}}", String.valueOf(scoreMoyen))
                    .replace("{{DATE}}", java.time.LocalDate.now().toString());

            PdfRendererBuilder builder = new PdfRendererBuilder();
            builder.useFastMode();

            // On utilise l'URL du dossier resources pour les images/styles
            URL resourceFolder = getClass().getClassLoader().getResource("");
            String baseUri = (resourceFolder != null) ? resourceFolder.toExternalForm() : file.getParentFile().toURI().toString();

            builder.withHtmlContent(content, baseUri);
            builder.toStream(os);
            builder.run();

            os.flush();
            System.out.println("✅ Certificat généré avec succès : " + file.getAbsolutePath());
        } catch (Exception e) {
            System.err.println("❌ Erreur de génération PDF : " + e.getMessage());
            e.printStackTrace();
        }
    }
}