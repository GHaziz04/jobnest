package tn.jobnest.gestioncan.controllers;

import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.layout.*;
import tn.jobnest.gestioncan.models.Candidature;
import tn.jobnest.gestioncan.services.CandidatureService;
import tn.jobnest.gestioncan.utils.MyDatabase;
import javafx.event.ActionEvent;
import tn.jobnest.gestioncan.utils.NavigationService;

import java.sql.*;
import java.util.List;

public class DashboardCandidatController {

    // --- CONFIGURATION ---
    private final int ID_USER = 1;
    private final String COLONNE_ID = "id_user";

    // --- ÉLÉMENTS FXML ---
    @FXML private Label lblTotalCandidatures;
    @FXML private LineChart<String, Number> chartEvolution;
    @FXML private VBox vboxCandidaturesRecentes;
    @FXML private Label lblProfilPourcentage;
    @FXML private ProgressIndicator indicatorProfil;
    @FXML private Label lblProfilSuggestion;
    @FXML private Label lblBoostStatus;

    // NOUVEAU : Label pour afficher le solde en TND
    @FXML private Label lblSoldeTND;

    private final CandidatureService service = new CandidatureService();

    @FXML
    public void initialize() {
        // Chargement initial
        chargerStatistiques();
        chargerGraphique();
        chargerDernieresCandidatures();
        calculerCompletudeProfil(); // Cette méthode gère aussi l'affichage du solde et des boosts
    }

    /**
     * Analyse le profil et synchronise l'UI avec la DB (Solde, Boosts, Score)
     */
    public void calculerCompletudeProfil() {
        double scoreInfosPerso = 0;
        double scoreCV = 0;

        Connection cnx = MyDatabase.getInstance().getCnx();
        String query = "SELECT * FROM candidat WHERE " + COLONNE_ID + " = ?";

        try (PreparedStatement pst = cnx.prepareStatement(query)) {
            pst.setInt(1, ID_USER);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    // 1. Mise à jour du Solde Financier (TND)
                    double solde = rs.getDouble("solde");
                    if (lblSoldeTND != null) {
                        lblSoldeTND.setText(String.format("%.2f TND", solde));
                    }

                    // 2. Gestion des jetons de Boost
                    int nbBoosts = rs.getInt("nb_boosts_restants");
                    actualiserLabelBoost(nbBoosts);

                    // 3. Calcul de complétude (Infos Perso)
                    String[] colonnes = {"nom", "prenom", "email", "num_tel", "adresse", "image", "ville", "titre_pro", "bio"};
                    double valeurUnitaire = 50.0 / colonnes.length;

                    for (String col : colonnes) {
                        if (isValid(getSafeString(rs, col))) {
                            scoreInfosPerso += valeurUnitaire;
                        }
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur lors de la synchronisation : " + e.getMessage());
        }

        // 4. Vérification du CV (Expériences, Formations, Compétences)
        boolean exp = verifierPresenceDonnees(cnx, "cv_experience");
        boolean form = verifierPresenceDonnees(cnx, "cv_formation");
        boolean comp = verifierPresenceDonnees(cnx, "cv_competence");

        if (exp)  scoreCV += 17;
        if (form) scoreCV += 17;
        if (comp) scoreCV += 16;

        int scoreTotal = (int) Math.round(scoreInfosPerso + scoreCV);
        if (scoreTotal > 100) scoreTotal = 100;

        // Mise à jour UI Profil
        lblProfilPourcentage.setText(scoreTotal + "%");
        indicatorProfil.setProgress(scoreTotal / 100.0);
        actualiserSuggestion(scoreInfosPerso, exp, form, comp);
    }

    private void actualiserLabelBoost(int nbBoosts) {
        if (lblBoostStatus == null) return;

        if (nbBoosts > 0) {
            lblBoostStatus.setText("🚀 " + nbBoosts + " Boost(s) disponible(s)");
            lblBoostStatus.setStyle("-fx-text-fill: #8B5CF6; -fx-font-weight: bold; -fx-cursor: hand;");
        } else {
            lblBoostStatus.setText("💎 Devenir Prioritaire");
            lblBoostStatus.setStyle("-fx-text-fill: #64748B; -fx-font-weight: bold; -fx-cursor: hand;");
        }

        // Clic sur le texte ou l'icône de boost -> Boutique
        lblBoostStatus.setOnMouseClicked(e -> NavigationService.charger("/View/PacksBoost.fxml"));
    }

    private void actualiserSuggestion(double scorePerso, boolean exp, boolean form, boolean comp) {
        if (scorePerso < 50) {
            lblProfilSuggestion.setText("👤 Complétez vos informations de base.");
            lblProfilSuggestion.setStyle("-fx-text-fill: #EF4444;");
        } else if (!exp) {
            lblProfilSuggestion.setText("⚠️ Ajoutez une expérience pour être plus visible.");
            lblProfilSuggestion.setStyle("-fx-text-fill: #F59E0B;");
        } else if (!form) {
            lblProfilSuggestion.setText("🎓 Détaillez votre formation académique.");
            lblProfilSuggestion.setStyle("-fx-text-fill: #3B82F6;");
        } else {
            lblProfilSuggestion.setText("✅ Votre profil est prêt !");
            lblProfilSuggestion.setStyle("-fx-text-fill: #10B981; -fx-font-weight: bold;");
        }
    }

    private boolean verifierPresenceDonnees(Connection cnx, String table) {
        String sql = "SELECT COUNT(*) FROM " + table + " WHERE id_candidat = ?";
        try (PreparedStatement pst = cnx.prepareStatement(sql)) {
            pst.setInt(1, ID_USER);
            try (ResultSet rs = pst.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        } catch (SQLException e) { return false; }
    }

    private void chargerStatistiques() {
        List<Candidature> list = service.getHistoriqueCandidat(ID_USER);
        lblTotalCandidatures.setText(String.valueOf(list.size()));
    }

    private void chargerGraphique() {
        chartEvolution.getData().clear();
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Candidatures " + java.time.Year.now().getValue());

        String query = "SELECT MONTHNAME(date_candidature) as mois, COUNT(*) as total FROM candidature " +
                "WHERE id_candidat = ? GROUP BY MONTH(date_candidature) ORDER BY MONTH(date_candidature) ASC";

        try (PreparedStatement pst = MyDatabase.getInstance().getCnx().prepareStatement(query)) {
            pst.setInt(1, ID_USER);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                series.getData().add(new XYChart.Data<>(rs.getString("mois"), rs.getInt("total")));
            }
            chartEvolution.getData().add(series);
        } catch (SQLException e) { e.printStackTrace(); }
    }

    private void chargerDernieresCandidatures() {
        vboxCandidaturesRecentes.getChildren().clear();
        List<Candidature> recentes = service.getHistoriqueCandidat(ID_USER);
        recentes.stream().limit(4).forEach(c -> vboxCandidaturesRecentes.getChildren().add(creerCarteCandidature(c)));
    }

    private HBox creerCarteCandidature(Candidature c) {
        HBox card = new HBox(15);
        card.setAlignment(Pos.CENTER_LEFT);
        card.setPadding(new Insets(15, 20, 15, 20));
        card.setStyle("-fx-background-color: white; -fx-background-radius: 10; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.05), 10, 0, 0, 3);");

        VBox info = new VBox(5);
        Label title = new Label(c.getTitreOffre());
        title.setStyle("-fx-font-weight: bold; -fx-text-fill: #1E293B;");
        info.getChildren().add(title);

        Pane spacer = new Pane();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label status = new Label(c.getStatut());
        status.setStyle(getStylePourStatut(c.getStatut()));

        card.getChildren().addAll(info, spacer, status);
        return card;
    }

    private String getStylePourStatut(String s) {
        String base = "-fx-background-radius: 15; -fx-padding: 5 10; ";
        if (s == null) return base;
        switch (s.toLowerCase()) {
            case "en attente": return base + "-fx-background-color: #FFF7ED; -fx-text-fill: #C2410C;";
            case "accepté":    return base + "-fx-background-color: #ECFCCB; -fx-text-fill: #4D7C0F;";
            case "refusé":     return base + "-fx-background-color: #FEF2F2; -fx-text-fill: #B91C1C;";
            default:           return base + "-fx-background-color: #F1F5F9; -fx-text-fill: #475569;";
        }
    }

    @FXML private void allerVersOffres(ActionEvent event) { NavigationService.charger("/View/OffresView.fxml"); }
    @FXML private void allerVersCreerCV(ActionEvent event) { NavigationService.charger("/View/CreerCV.fxml"); }

    private String getSafeString(ResultSet rs, String colName) {
        try { return rs.getString(colName); } catch (SQLException e) { return null; }
    }
    private boolean isValid(String str) { return str != null && !str.trim().isEmpty(); }
}