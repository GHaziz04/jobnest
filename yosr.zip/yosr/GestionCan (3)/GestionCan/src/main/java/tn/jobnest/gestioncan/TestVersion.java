package tn.jobnest.gestioncan;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class TestVersion {
    public static void main(String[] args) {
        // 🔴 METS TA CLÉ ICI
        String API_KEY = "AIzaSyBuCN7Nt5RH0Jga6LJ62DTCgsiegTSG9TQ";

        // Cette URL sert uniquement à lister les modèles (pas de generateContent)
        String url = "https://generativelanguage.googleapis.com/v1beta/models?key=" + API_KEY;

        try {
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .GET() // On fait un GET pour lire l'info
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            System.out.println("--- LISTE DES VERSIONS DISPONIBLES ---");
            System.out.println(response.body());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}