package tn.jobnest.gestioncan;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import tn.jobnest.gestioncan.utils.MyDatabase;

public class HelloApplication extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        // 1. Test de connexion base de données
        verifierConnexionBaseDeDonnees();

        // 2. Chargement de la vue principale
        FXMLLoader fxmlLoader = new FXMLLoader(
                HelloApplication.class.getResource("/View/MainLayout.fxml")
        );

        Scene scene = new Scene(fxmlLoader.load(), 1200, 800);

        stage.setTitle("JobNest - Plateforme de Recrutement");
        stage.setScene(scene);
        stage.show();
    }

    private void verifierConnexionBaseDeDonnees() {
        try {
            Connection conn = MyDatabase.getInstance().getCnx();
            if (conn != null && !conn.isClosed()) {
                System.out.println("✅ SUCCÈS : Connecté à la base 'jobnest' avec succès !");
            } else {
                System.err.println("❌ ERREUR : La connexion à la base est fermée ou nulle.");
            }
        } catch (SQLException e) {
            System.err.println("❌ ERREUR CRITIQUE : Impossible de se connecter à MySQL.");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch();
    }
}