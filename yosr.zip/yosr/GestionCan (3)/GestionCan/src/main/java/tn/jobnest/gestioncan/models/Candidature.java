package tn.jobnest.gestioncan.models;

import java.sql.Timestamp;

public class Candidature {

    private int idCandidature;
    private int idOffre;
    private int idCandidat;
    private String messageComplementaire;
    private String statut;
    private Timestamp dateCandidature;

    // --- NOUVEAU : Attribut pour le système de boost ---
    private int isBoosted; // 0 = Non boosté, 1 = Boosté

    // Pour affichage historique (Jointures)
    private String titreOffre;
    private String nomEntreprise;

    // Constructeur vide (Indispensable pour certaines bibliothèques et réflexivité)
    public Candidature() {
    }

    // Constructeur utilisé pour INSERT
    public Candidature(int idOffre, int idCandidat, String messageComplementaire) {
        this.idOffre = idOffre;
        this.idCandidat = idCandidat;
        this.messageComplementaire = messageComplementaire;
        this.statut = "en_attente";
        this.isBoosted = 0;
    }

    // Constructeur complet utilisé pour SELECT
    public Candidature(int idCandidature, int idCandidat, int idOffre,
                       String messageComplementaire, String statut, Timestamp dateCandidature, int isBoosted) {
        this.idCandidature = idCandidature;
        this.idCandidat = idCandidat;
        this.idOffre = idOffre;
        this.messageComplementaire = messageComplementaire;
        this.statut = statut;
        this.dateCandidature = dateCandidature;
        this.isBoosted = isBoosted;
    }

    // --- GETTERS ---
    public int getIdCandidature() { return idCandidature; }
    public int getIdOffre() { return idOffre; }
    public int getIdCandidat() { return idCandidat; }
    public String getMessageComplementaire() { return messageComplementaire; }
    public String getStatut() { return statut; }
    public Timestamp getDateCandidature() { return dateCandidature; }
    public String getTitreOffre() { return titreOffre; }
    public String getNomEntreprise() { return nomEntreprise; }
    public int getIsBoosted() { return isBoosted; } // Utilisé par le contrôleur

    // --- SETTERS ---
    public void setIdCandidature(int idCandidature) { this.idCandidature = idCandidature; }
    public void setStatut(String statut) { this.statut = statut; }
    public void setTitreOffre(String titreOffre) { this.titreOffre = titreOffre; }
    public void setNomEntreprise(String nomEntreprise) { this.nomEntreprise = nomEntreprise; }
    public void setIdOffre(int idOffre) { this.idOffre = idOffre; }
    public void setIdCandidat(int idCandidat) { this.idCandidat = idCandidat; }
    public void setMessageComplementaire(String messageComplementaire) { this.messageComplementaire = messageComplementaire; }
    public void setDateCandidature(Timestamp dateCandidature) { this.dateCandidature = dateCandidature; }
    public void setIsBoosted(int isBoosted) { this.isBoosted = isBoosted; }
}