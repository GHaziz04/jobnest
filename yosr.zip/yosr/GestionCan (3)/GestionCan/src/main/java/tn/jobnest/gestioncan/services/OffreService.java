package tn.jobnest.gestioncan.services;

import tn.jobnest.gestioncan.models.Offre;
import java.util.ArrayList;
import java.util.List;

public class OffreService {

    // 1. Retourne une liste d'offres simulées (Maintenant très lisible !)
    public List<Offre> afficherToutesLesOffres() {
        List<Offre> offres = new ArrayList<>();

        offres.add(creerOffreDev());
        offres.add(creerOffreDataAnalyst());
        offres.add(creerOffreChefDeProjet());

        return offres;
    }

    // --- MÉTHODES EXTRAITES POUR CHAQUE OFFRE ---

    private Offre creerOffreDev() {
        Offre o1 = new Offre();
        o1.setIdOffre(1);
        o1.setTitre("Développeur Java Full Stack");
        o1.setEntreprise("TechSolutions");
        o1.setTypeContrat("CDI");
        o1.setSalaireMin(2500.0);
        o1.setSalaireMax(4000.0);
        o1.setNiveauExperience("Intermédiaire");
        o1.setLieu("Tunis");
        o1.setDescription("Nous recherchons un développeur passionné par JavaFX et Spring Boot pour rejoindre notre équipe dynamique. Vous travaillerez sur des projets innovants de bout en bout.");
        return o1;
    }

    private Offre creerOffreDataAnalyst() {
        Offre o2 = new Offre();
        o2.setIdOffre(2);
        o2.setTitre("Data Analyst");
        o2.setEntreprise("DataCorp");
        o2.setTypeContrat("Freelance");
        o2.setSalaireMin(0.0); // Pour tester l'affichage "Salaire à négocier"
        o2.setSalaireMax(0.0);
        o2.setNiveauExperience("Expert");
        o2.setLieu("Sousse");
        o2.setDescription("Mission de 6 mois pour analyser des bases de données clients complexes et créer des dashboards interactifs.");
        return o2;
    }

    private Offre creerOffreChefDeProjet() {
        Offre o3 = new Offre();
        o3.setIdOffre(3);
        o3.setTitre("Chef de Projet IT");
        o3.setEntreprise("Innovatech");
        o3.setTypeContrat("CDI");
        o3.setSalaireMin(3000.0);
        o3.setSalaireMax(5000.0);
        o3.setNiveauExperience("Avancé");
        o3.setLieu("Sfax");
        o3.setDescription("Gestion d'équipes agiles (Scrum), suivi de KPIs et communication directe avec les clients internationaux.");
        return o3;
    }

    // ---------------------------------------------

    // 2. Retourne des compétences simulées selon l'ID de l'offre
    public List<String> getCompetencesPourOffre(int idOffre) {
        List<String> competences = new ArrayList<>();

        if (idOffre == 1) {
            competences.addAll(List.of("Java", "JavaFX", "Spring Boot", "MySQL"));
        } else if (idOffre == 2) {
            competences.addAll(List.of("Python", "SQL", "PowerBI", "Machine Learning"));
        } else if (idOffre == 3) {
            competences.addAll(List.of("Gestion de projet", "Jira", "Communication", "Scrum"));
        } else {
            competences.add("Adaptabilité");
        }
        return competences;
    }

    // 3. Retourne des expériences simulées selon l'ID de l'offre
    public List<String> getExperiencesPourOffre(int idOffre) {
        List<String> experiences = new ArrayList<>();

        if (idOffre == 1) {
            experiences.addAll(List.of("2 ans Développement Web", "Projet Universitaire Java"));
        } else if (idOffre == 2) {
            experiences.addAll(List.of("5 ans Analyse de données", "Mission Big Data"));
        } else if (idOffre == 3) {
            experiences.addAll(List.of("3 ans Management", "Certification Agile"));
        } else {
            experiences.add("Expérience associative");
        }
        return experiences;
    }
}