package tn.jobnest.gestioncan.services;


import tn.jobnest.gestioncan.models.Competence;
import tn.jobnest.gestioncan.services.ICrud;
import tn.jobnest.gestioncan.utils.MyDatabase;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CompetenceService implements ICrud<Competence> {

    private Connection cnx = MyDatabase.getInstance().getCnx();

    @Override
    public void ajouter(Competence c) {
        String req = "INSERT INTO cv_competence (id_candidat, nom_competence) VALUES (?, ?)";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, c.getIdCandidat());
            ps.setString(2, c.getNom());
            ps.executeUpdate();
            System.out.println("Compétence ajoutée !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Competence> getByCandidat(int idCandidat) {
        List<Competence> list = new ArrayList<>();
        String req = "SELECT * FROM cv_competence WHERE id_candidat = ?";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, idCandidat);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Competence(
                        rs.getInt("id"),
                        rs.getInt("id_candidat"),
                        rs.getString("nom_competence")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public void supprimer(int id) {
        try {
            String req = "DELETE FROM cv_competence WHERE id = ?";
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override public void modifier(Competence c) {}
    @Override public List<Competence> afficher() { return null; }
    @Override public Map<Integer, Competence> getMap() { return null; }
}
